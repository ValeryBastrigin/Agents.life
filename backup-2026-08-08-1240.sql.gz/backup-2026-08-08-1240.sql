--
-- PostgreSQL database dump
--

\restrict iDJw9mqb5Jg9xgt1btWzU8zsfGOhcY5RU9JCLG3hNdwLgjfzSxAX271a24hsomK

-- Dumped from database version 16.14 (Debian 16.14-1.pgdg12+1)
-- Dumped by pg_dump version 16.14 (Debian 16.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.user_knowledge_facts DROP CONSTRAINT IF EXISTS user_knowledge_facts_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_identities DROP CONSTRAINT IF EXISTS user_identities_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_diet_profiles DROP CONSTRAINT IF EXISTS user_diet_profiles_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_context_profiles DROP CONSTRAINT IF EXISTS user_context_profiles_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_agent_settings DROP CONSTRAINT IF EXISTS user_agent_settings_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_statement_id_fkey;
ALTER TABLE IF EXISTS ONLY public.token_transactions DROP CONSTRAINT IF EXISTS token_transactions_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.therapy_sessions DROP CONSTRAINT IF EXISTS therapy_sessions_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.therapy_sessions DROP CONSTRAINT IF EXISTS therapy_sessions_chat_id_fkey;
ALTER TABLE IF EXISTS ONLY public.schedule_analyses DROP CONSTRAINT IF EXISTS schedule_analyses_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.reminders DROP CONSTRAINT IF EXISTS reminders_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.portfolio_analyses DROP CONSTRAINT IF EXISTS portfolio_analyses_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.notes DROP CONSTRAINT IF EXISTS notes_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.mood_entries DROP CONSTRAINT IF EXISTS mood_entries_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.messages DROP CONSTRAINT IF EXISTS messages_chat_id_fkey;
ALTER TABLE IF EXISTS ONLY public.knowledge_events DROP CONSTRAINT IF EXISTS knowledge_events_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.food_consumptions DROP CONSTRAINT IF EXISTS food_consumptions_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.financial_obligations DROP CONSTRAINT IF EXISTS financial_obligations_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.dream_goals DROP CONSTRAINT IF EXISTS dream_goals_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.dream_goals DROP CONSTRAINT IF EXISTS dream_goals_chat_id_fkey;
ALTER TABLE IF EXISTS ONLY public.dream_analyses DROP CONSTRAINT IF EXISTS dream_analyses_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.diet_plans DROP CONSTRAINT IF EXISTS diet_plans_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.diary_entries DROP CONSTRAINT IF EXISTS diary_entries_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.daily_food_analyses DROP CONSTRAINT IF EXISTS daily_food_analyses_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.chats DROP CONSTRAINT IF EXISTS chats_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.chats DROP CONSTRAINT IF EXISTS chats_agent_id_fkey;
ALTER TABLE IF EXISTS ONLY public.calendar_events DROP CONSTRAINT IF EXISTS calendar_events_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.bank_statements DROP CONSTRAINT IF EXISTS bank_statements_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.agent_communications DROP CONSTRAINT IF EXISTS agent_communications_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.active_goals DROP CONSTRAINT IF EXISTS active_goals_user_id_fkey;
DROP TRIGGER IF EXISTS update_users_updated_at ON public.users;
DROP TRIGGER IF EXISTS update_reminders_updated_at ON public.reminders;
DROP TRIGGER IF EXISTS update_chats_updated_at ON public.chats;
DROP TRIGGER IF EXISTS update_calendar_events_updated_at ON public.calendar_events;
DROP INDEX IF EXISTS public.ix_user_identities_id;
DROP INDEX IF EXISTS public.ix_user_agent_settings_id;
DROP INDEX IF EXISTS public.ix_schedule_analyses_user_id;
DROP INDEX IF EXISTS public.ix_schedule_analyses_id;
DROP INDEX IF EXISTS public.ix_otp_challenges_id;
DROP INDEX IF EXISTS public.ix_otp_challenges_email;
DROP INDEX IF EXISTS public.ix_food_consumptions_id;
DROP INDEX IF EXISTS public.ix_financial_obligations_id;
DROP INDEX IF EXISTS public.ix_dream_goals_id;
DROP INDEX IF EXISTS public.ix_dream_analyses_id;
DROP INDEX IF EXISTS public.ix_diet_plans_id;
DROP INDEX IF EXISTS public.ix_daily_food_analyses_user_id;
DROP INDEX IF EXISTS public.ix_daily_food_analyses_id;
DROP INDEX IF EXISTS public.ix_daily_food_analyses_analysis_date;
DROP INDEX IF EXISTS public.ix_active_goals_id;
DROP INDEX IF EXISTS public.idx_transactions_user_id;
DROP INDEX IF EXISTS public.idx_transactions_statement_id;
DROP INDEX IF EXISTS public.idx_transactions_category;
DROP INDEX IF EXISTS public.idx_token_transactions_user_id;
DROP INDEX IF EXISTS public.idx_reminders_user_id;
DROP INDEX IF EXISTS public.idx_reminders_date;
DROP INDEX IF EXISTS public.idx_portfolio_analyses_user_id;
DROP INDEX IF EXISTS public.idx_portfolio_analyses_created_at;
DROP INDEX IF EXISTS public.idx_mood_entries_user_id;
DROP INDEX IF EXISTS public.idx_mood_entries_created_at;
DROP INDEX IF EXISTS public.idx_messages_created_at;
DROP INDEX IF EXISTS public.idx_messages_chat_id;
DROP INDEX IF EXISTS public.idx_knowledge_user_id;
DROP INDEX IF EXISTS public.idx_knowledge_tier;
DROP INDEX IF EXISTS public.idx_knowledge_source;
DROP INDEX IF EXISTS public.idx_knowledge_agent;
DROP INDEX IF EXISTS public.idx_events_user_status;
DROP INDEX IF EXISTS public.idx_events_type;
DROP INDEX IF EXISTS public.idx_context_profiles_user_id;
DROP INDEX IF EXISTS public.idx_chats_user_id;
DROP INDEX IF EXISTS public.idx_chats_agent_id;
DROP INDEX IF EXISTS public.idx_calendar_events_user_id;
DROP INDEX IF EXISTS public.idx_calendar_events_start_time;
DROP INDEX IF EXISTS public.idx_bank_statements_user_id;
DROP INDEX IF EXISTS public.idx_agent_comms_user_id;
DROP INDEX IF EXISTS public.idx_agent_comms_target;
DROP INDEX IF EXISTS public.idx_agent_comms_requester;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_google_id_key;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_email_key;
ALTER TABLE IF EXISTS ONLY public.user_knowledge_facts DROP CONSTRAINT IF EXISTS user_knowledge_facts_pkey;
ALTER TABLE IF EXISTS ONLY public.user_identities DROP CONSTRAINT IF EXISTS user_identities_pkey;
ALTER TABLE IF EXISTS ONLY public.user_diet_profiles DROP CONSTRAINT IF EXISTS user_diet_profiles_user_id_key;
ALTER TABLE IF EXISTS ONLY public.user_diet_profiles DROP CONSTRAINT IF EXISTS user_diet_profiles_pkey;
ALTER TABLE IF EXISTS ONLY public.user_context_profiles DROP CONSTRAINT IF EXISTS user_context_profiles_user_id_key;
ALTER TABLE IF EXISTS ONLY public.user_context_profiles DROP CONSTRAINT IF EXISTS user_context_profiles_pkey;
ALTER TABLE IF EXISTS ONLY public.user_agent_settings DROP CONSTRAINT IF EXISTS user_agent_settings_pkey;
ALTER TABLE IF EXISTS ONLY public.user_identities DROP CONSTRAINT IF EXISTS uq_provider_identity;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_pkey;
ALTER TABLE IF EXISTS ONLY public.token_transactions DROP CONSTRAINT IF EXISTS token_transactions_pkey;
ALTER TABLE IF EXISTS ONLY public.therapy_sessions DROP CONSTRAINT IF EXISTS therapy_sessions_pkey;
ALTER TABLE IF EXISTS ONLY public.schedule_analyses DROP CONSTRAINT IF EXISTS schedule_analyses_pkey;
ALTER TABLE IF EXISTS ONLY public.reminders DROP CONSTRAINT IF EXISTS reminders_pkey;
ALTER TABLE IF EXISTS ONLY public.portfolio_analyses DROP CONSTRAINT IF EXISTS portfolio_analyses_pkey;
ALTER TABLE IF EXISTS ONLY public.otp_challenges DROP CONSTRAINT IF EXISTS otp_challenges_pkey;
ALTER TABLE IF EXISTS ONLY public.notes DROP CONSTRAINT IF EXISTS notes_pkey;
ALTER TABLE IF EXISTS ONLY public.mood_entries DROP CONSTRAINT IF EXISTS mood_entries_pkey;
ALTER TABLE IF EXISTS ONLY public.messages DROP CONSTRAINT IF EXISTS messages_pkey;
ALTER TABLE IF EXISTS ONLY public.knowledge_events DROP CONSTRAINT IF EXISTS knowledge_events_pkey;
ALTER TABLE IF EXISTS ONLY public.food_consumptions DROP CONSTRAINT IF EXISTS food_consumptions_pkey;
ALTER TABLE IF EXISTS ONLY public.financial_obligations DROP CONSTRAINT IF EXISTS financial_obligations_pkey;
ALTER TABLE IF EXISTS ONLY public.dream_goals DROP CONSTRAINT IF EXISTS dream_goals_pkey;
ALTER TABLE IF EXISTS ONLY public.dream_analyses DROP CONSTRAINT IF EXISTS dream_analyses_pkey;
ALTER TABLE IF EXISTS ONLY public.diet_plans DROP CONSTRAINT IF EXISTS diet_plans_user_id_key;
ALTER TABLE IF EXISTS ONLY public.diet_plans DROP CONSTRAINT IF EXISTS diet_plans_pkey;
ALTER TABLE IF EXISTS ONLY public.diary_entries DROP CONSTRAINT IF EXISTS diary_entries_pkey;
ALTER TABLE IF EXISTS ONLY public.daily_food_analyses DROP CONSTRAINT IF EXISTS daily_food_analyses_pkey;
ALTER TABLE IF EXISTS ONLY public.chats DROP CONSTRAINT IF EXISTS chats_pkey;
ALTER TABLE IF EXISTS ONLY public.calendar_events DROP CONSTRAINT IF EXISTS calendar_events_pkey;
ALTER TABLE IF EXISTS ONLY public.bank_statements DROP CONSTRAINT IF EXISTS bank_statements_pkey;
ALTER TABLE IF EXISTS ONLY public.agents DROP CONSTRAINT IF EXISTS agents_pkey;
ALTER TABLE IF EXISTS ONLY public.agents DROP CONSTRAINT IF EXISTS agents_name_key;
ALTER TABLE IF EXISTS ONLY public.agent_communications DROP CONSTRAINT IF EXISTS agent_communications_pkey;
ALTER TABLE IF EXISTS ONLY public.active_goals DROP CONSTRAINT IF EXISTS active_goals_pkey;
ALTER TABLE IF EXISTS public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.user_knowledge_facts ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.user_identities ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.user_diet_profiles ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.user_context_profiles ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.user_agent_settings ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.transactions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.token_transactions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.therapy_sessions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.schedule_analyses ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.reminders ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.portfolio_analyses ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.otp_challenges ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.notes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.mood_entries ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.messages ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.knowledge_events ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.food_consumptions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.financial_obligations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.dream_goals ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.dream_analyses ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.diet_plans ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.diary_entries ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.daily_food_analyses ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.chats ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.calendar_events ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.bank_statements ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.agents ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.agent_communications ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.active_goals ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.users_id_seq;
DROP TABLE IF EXISTS public.users;
DROP SEQUENCE IF EXISTS public.user_knowledge_facts_id_seq;
DROP TABLE IF EXISTS public.user_knowledge_facts;
DROP SEQUENCE IF EXISTS public.user_identities_id_seq;
DROP TABLE IF EXISTS public.user_identities;
DROP SEQUENCE IF EXISTS public.user_diet_profiles_id_seq;
DROP TABLE IF EXISTS public.user_diet_profiles;
DROP SEQUENCE IF EXISTS public.user_context_profiles_id_seq;
DROP TABLE IF EXISTS public.user_context_profiles;
DROP SEQUENCE IF EXISTS public.user_agent_settings_id_seq;
DROP TABLE IF EXISTS public.user_agent_settings;
DROP SEQUENCE IF EXISTS public.transactions_id_seq;
DROP TABLE IF EXISTS public.transactions;
DROP SEQUENCE IF EXISTS public.token_transactions_id_seq;
DROP TABLE IF EXISTS public.token_transactions;
DROP SEQUENCE IF EXISTS public.therapy_sessions_id_seq;
DROP TABLE IF EXISTS public.therapy_sessions;
DROP SEQUENCE IF EXISTS public.schedule_analyses_id_seq;
DROP TABLE IF EXISTS public.schedule_analyses;
DROP SEQUENCE IF EXISTS public.reminders_id_seq;
DROP TABLE IF EXISTS public.reminders;
DROP SEQUENCE IF EXISTS public.portfolio_analyses_id_seq;
DROP TABLE IF EXISTS public.portfolio_analyses;
DROP SEQUENCE IF EXISTS public.otp_challenges_id_seq;
DROP TABLE IF EXISTS public.otp_challenges;
DROP SEQUENCE IF EXISTS public.notes_id_seq;
DROP TABLE IF EXISTS public.notes;
DROP SEQUENCE IF EXISTS public.mood_entries_id_seq;
DROP TABLE IF EXISTS public.mood_entries;
DROP SEQUENCE IF EXISTS public.messages_id_seq;
DROP TABLE IF EXISTS public.messages;
DROP SEQUENCE IF EXISTS public.knowledge_events_id_seq;
DROP TABLE IF EXISTS public.knowledge_events;
DROP SEQUENCE IF EXISTS public.food_consumptions_id_seq;
DROP TABLE IF EXISTS public.food_consumptions;
DROP SEQUENCE IF EXISTS public.financial_obligations_id_seq;
DROP TABLE IF EXISTS public.financial_obligations;
DROP SEQUENCE IF EXISTS public.dream_goals_id_seq;
DROP TABLE IF EXISTS public.dream_goals;
DROP SEQUENCE IF EXISTS public.dream_analyses_id_seq;
DROP TABLE IF EXISTS public.dream_analyses;
DROP SEQUENCE IF EXISTS public.diet_plans_id_seq;
DROP TABLE IF EXISTS public.diet_plans;
DROP SEQUENCE IF EXISTS public.diary_entries_id_seq;
DROP TABLE IF EXISTS public.diary_entries;
DROP SEQUENCE IF EXISTS public.daily_food_analyses_id_seq;
DROP TABLE IF EXISTS public.daily_food_analyses;
DROP SEQUENCE IF EXISTS public.chats_id_seq;
DROP TABLE IF EXISTS public.chats;
DROP SEQUENCE IF EXISTS public.calendar_events_id_seq;
DROP TABLE IF EXISTS public.calendar_events;
DROP SEQUENCE IF EXISTS public.bank_statements_id_seq;
DROP TABLE IF EXISTS public.bank_statements;
DROP SEQUENCE IF EXISTS public.agents_id_seq;
DROP TABLE IF EXISTS public.agents;
DROP SEQUENCE IF EXISTS public.agent_communications_id_seq;
DROP TABLE IF EXISTS public.agent_communications;
DROP SEQUENCE IF EXISTS public.active_goals_id_seq;
DROP TABLE IF EXISTS public.active_goals;
DROP FUNCTION IF EXISTS public.update_updated_at_column();
DROP EXTENSION IF EXISTS vector;
--
-- Name: vector; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS vector WITH SCHEMA public;


--
-- Name: EXTENSION vector; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION vector IS 'vector data type and ivfflat and hnsw access methods';


--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: lifeagent
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO lifeagent;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: active_goals; Type: TABLE; Schema: public; Owner: lifeagent
--

CREATE TABLE public.active_goals (
    id integer NOT NULL,
    user_id integer NOT NULL,
    title character varying(255) NOT NULL,
    branch_type character varying(50),
    resources text,
    status character varying(20),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.active_goals OWNER TO lifeagent;

--
-- Name: active_goals_id_seq; Type: SEQUENCE; Schema: public; Owner: lifeagent
--

CREATE SEQUENCE public.active_goals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.active_goals_id_seq OWNER TO lifeagent;

--
-- Name: active_goals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lifeagent
--

ALTER SEQUENCE public.active_goals_id_seq OWNED BY public.active_goals.id;


--
-- Name: agent_communications; Type: TABLE; Schema: public; Owner: lifeagent
--

CREATE TABLE public.agent_communications (
    id integer NOT NULL,
    user_id integer NOT NULL,
    requester_agent character varying(50) NOT NULL,
    target_agent character varying(50) NOT NULL,
    query_text text NOT NULL,
    response_text text,
    response_embedding public.vector(384),
    status character varying(20) DEFAULT 'pending'::character varying,
    tokens_used integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now(),
    responded_at timestamp with time zone
);


ALTER TABLE public.agent_communications OWNER TO lifeagent;

--
-- Name: agent_communications_id_seq; Type: SEQUENCE; Schema: public; Owner: lifeagent
--

CREATE SEQUENCE public.agent_communications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.agent_communications_id_seq OWNER TO lifeagent;

--
-- Name: agent_communications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lifeagent
--

ALTER SEQUENCE public.agent_communications_id_seq OWNED BY public.agent_communications.id;


--
-- Name: agents; Type: TABLE; Schema: public; Owner: lifeagent
--

CREATE TABLE public.agents (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    description text,
    system_prompt text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.agents OWNER TO lifeagent;

--
-- Name: agents_id_seq; Type: SEQUENCE; Schema: public; Owner: lifeagent
--

CREATE SEQUENCE public.agents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.agents_id_seq OWNER TO lifeagent;

--
-- Name: agents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lifeagent
--

ALTER SEQUENCE public.agents_id_seq OWNED BY public.agents.id;


--
-- Name: bank_statements; Type: TABLE; Schema: public; Owner: lifeagent
--

CREATE TABLE public.bank_statements (
    id integer NOT NULL,
    user_id integer,
    filename character varying(255) NOT NULL,
    bank_name character varying(100) DEFAULT ''::character varying,
    period_start date,
    period_end date,
    total_income double precision DEFAULT 0,
    total_expense double precision DEFAULT 0,
    categories_data text DEFAULT '{}'::text,
    analysis_text text DEFAULT ''::text,
    raw_content text DEFAULT ''::text,
    status character varying(20) DEFAULT 'processing'::character varying,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.bank_statements OWNER TO lifeagent;

--
-- Name: bank_statements_id_seq; Type: SEQUENCE; Schema: public; Owner: lifeagent
--

CREATE SEQUENCE public.bank_statements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.bank_statements_id_seq OWNER TO lifeagent;

--
-- Name: bank_statements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lifeagent
--

ALTER SEQUENCE public.bank_statements_id_seq OWNED BY public.bank_statements.id;


--
-- Name: calendar_events; Type: TABLE; Schema: public; Owner: lifeagent
--

CREATE TABLE public.calendar_events (
    id integer NOT NULL,
    user_id integer,
    title character varying(255) NOT NULL,
    start_time timestamp without time zone NOT NULL,
    end_time timestamp without time zone NOT NULL,
    color character varying(7) DEFAULT '#3B82F6'::character varying,
    description text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    completed boolean DEFAULT false,
    push_enabled boolean DEFAULT false
);


ALTER TABLE public.calendar_events OWNER TO lifeagent;

--
-- Name: calendar_events_id_seq; Type: SEQUENCE; Schema: public; Owner: lifeagent
--

CREATE SEQUENCE public.calendar_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.calendar_events_id_seq OWNER TO lifeagent;

--
-- Name: calendar_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lifeagent
--

ALTER SEQUENCE public.calendar_events_id_seq OWNED BY public.calendar_events.id;


--
-- Name: chats; Type: TABLE; Schema: public; Owner: lifeagent
--

CREATE TABLE public.chats (
    id integer NOT NULL,
    user_id integer,
    agent_id integer,
    title character varying(255),
    is_pinned boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.chats OWNER TO lifeagent;

--
-- Name: chats_id_seq; Type: SEQUENCE; Schema: public; Owner: lifeagent
--

CREATE SEQUENCE public.chats_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.chats_id_seq OWNER TO lifeagent;

--
-- Name: chats_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lifeagent
--

ALTER SEQUENCE public.chats_id_seq OWNED BY public.chats.id;


--
-- Name: daily_food_analyses; Type: TABLE; Schema: public; Owner: lifeagent
--

CREATE TABLE public.daily_food_analyses (
    id integer NOT NULL,
    user_id integer NOT NULL,
    analysis_date date NOT NULL,
    analysis_text text NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.daily_food_analyses OWNER TO lifeagent;

--
-- Name: daily_food_analyses_id_seq; Type: SEQUENCE; Schema: public; Owner: lifeagent
--

CREATE SEQUENCE public.daily_food_analyses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.daily_food_analyses_id_seq OWNER TO lifeagent;

--
-- Name: daily_food_analyses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lifeagent
--

ALTER SEQUENCE public.daily_food_analyses_id_seq OWNED BY public.daily_food_analyses.id;


--
-- Name: diary_entries; Type: TABLE; Schema: public; Owner: lifeagent
--

CREATE TABLE public.diary_entries (
    id integer NOT NULL,
    user_id integer,
    title character varying(255) DEFAULT ''::character varying,
    content text NOT NULL,
    mood integer,
    mood_emoji character varying(10),
    tags character varying(500) DEFAULT ''::character varying,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.diary_entries OWNER TO lifeagent;

--
-- Name: diary_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: lifeagent
--

CREATE SEQUENCE public.diary_entries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.diary_entries_id_seq OWNER TO lifeagent;

--
-- Name: diary_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lifeagent
--

ALTER SEQUENCE public.diary_entries_id_seq OWNED BY public.diary_entries.id;


--
-- Name: diet_plans; Type: TABLE; Schema: public; Owner: lifeagent
--

CREATE TABLE public.diet_plans (
    id integer NOT NULL,
    user_id integer NOT NULL,
    plan_data text NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.diet_plans OWNER TO lifeagent;

--
-- Name: diet_plans_id_seq; Type: SEQUENCE; Schema: public; Owner: lifeagent
--

CREATE SEQUENCE public.diet_plans_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.diet_plans_id_seq OWNER TO lifeagent;

--
-- Name: diet_plans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lifeagent
--

ALTER SEQUENCE public.diet_plans_id_seq OWNED BY public.diet_plans.id;


--
-- Name: dream_analyses; Type: TABLE; Schema: public; Owner: lifeagent
--

CREATE TABLE public.dream_analyses (
    id integer NOT NULL,
    user_id integer NOT NULL,
    dream_text text NOT NULL,
    branches_data text,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.dream_analyses OWNER TO lifeagent;

--
-- Name: dream_analyses_id_seq; Type: SEQUENCE; Schema: public; Owner: lifeagent
--

CREATE SEQUENCE public.dream_analyses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.dream_analyses_id_seq OWNER TO lifeagent;

--
-- Name: dream_analyses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lifeagent
--

ALTER SEQUENCE public.dream_analyses_id_seq OWNED BY public.dream_analyses.id;


--
-- Name: dream_goals; Type: TABLE; Schema: public; Owner: lifeagent
--

CREATE TABLE public.dream_goals (
    id integer NOT NULL,
    user_id integer NOT NULL,
    dream_text text NOT NULL,
    category character varying(50) NOT NULL,
    goal_summary character varying(255) NOT NULL,
    analysis text,
    steps_data text,
    selected_step_ids text,
    chat_id integer,
    status character varying(20),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.dream_goals OWNER TO lifeagent;

--
-- Name: dream_goals_id_seq; Type: SEQUENCE; Schema: public; Owner: lifeagent
--

CREATE SEQUENCE public.dream_goals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.dream_goals_id_seq OWNER TO lifeagent;

--
-- Name: dream_goals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lifeagent
--

ALTER SEQUENCE public.dream_goals_id_seq OWNED BY public.dream_goals.id;


--
-- Name: financial_obligations; Type: TABLE; Schema: public; Owner: lifeagent
--

CREATE TABLE public.financial_obligations (
    id integer NOT NULL,
    user_id integer NOT NULL,
    date integer NOT NULL,
    title character varying(255) NOT NULL,
    amount integer NOT NULL,
    type character varying(20) NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.financial_obligations OWNER TO lifeagent;

--
-- Name: financial_obligations_id_seq; Type: SEQUENCE; Schema: public; Owner: lifeagent
--

CREATE SEQUENCE public.financial_obligations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.financial_obligations_id_seq OWNER TO lifeagent;

--
-- Name: financial_obligations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lifeagent
--

ALTER SEQUENCE public.financial_obligations_id_seq OWNED BY public.financial_obligations.id;


--
-- Name: food_consumptions; Type: TABLE; Schema: public; Owner: lifeagent
--

CREATE TABLE public.food_consumptions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    product_name character varying(255) NOT NULL,
    grams integer NOT NULL,
    calories integer NOT NULL,
    protein integer NOT NULL,
    fats integer NOT NULL,
    carbs integer NOT NULL,
    meal_type character varying(50),
    notes text,
    consumed_at timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.food_consumptions OWNER TO lifeagent;

--
-- Name: food_consumptions_id_seq; Type: SEQUENCE; Schema: public; Owner: lifeagent
--

CREATE SEQUENCE public.food_consumptions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.food_consumptions_id_seq OWNER TO lifeagent;

--
-- Name: food_consumptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lifeagent
--

ALTER SEQUENCE public.food_consumptions_id_seq OWNED BY public.food_consumptions.id;


--
-- Name: knowledge_events; Type: TABLE; Schema: public; Owner: lifeagent
--

CREATE TABLE public.knowledge_events (
    id integer NOT NULL,
    user_id integer NOT NULL,
    event_type character varying(50) NOT NULL,
    agent_name character varying(50) NOT NULL,
    payload text NOT NULL,
    status character varying(20) DEFAULT 'new'::character varying,
    processed_at timestamp with time zone,
    error_message text,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.knowledge_events OWNER TO lifeagent;

--
-- Name: knowledge_events_id_seq; Type: SEQUENCE; Schema: public; Owner: lifeagent
--

CREATE SEQUENCE public.knowledge_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.knowledge_events_id_seq OWNER TO lifeagent;

--
-- Name: knowledge_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lifeagent
--

ALTER SEQUENCE public.knowledge_events_id_seq OWNED BY public.knowledge_events.id;


--
-- Name: messages; Type: TABLE; Schema: public; Owner: lifeagent
--

CREATE TABLE public.messages (
    id integer NOT NULL,
    chat_id integer,
    role character varying(20) NOT NULL,
    content text NOT NULL,
    tokens_used integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.messages OWNER TO lifeagent;

--
-- Name: messages_id_seq; Type: SEQUENCE; Schema: public; Owner: lifeagent
--

CREATE SEQUENCE public.messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.messages_id_seq OWNER TO lifeagent;

--
-- Name: messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lifeagent
--

ALTER SEQUENCE public.messages_id_seq OWNED BY public.messages.id;


--
-- Name: mood_entries; Type: TABLE; Schema: public; Owner: lifeagent
--

CREATE TABLE public.mood_entries (
    id integer NOT NULL,
    user_id integer,
    mood integer NOT NULL,
    emoji character varying(10) NOT NULL,
    label character varying(50) NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.mood_entries OWNER TO lifeagent;

--
-- Name: mood_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: lifeagent
--

CREATE SEQUENCE public.mood_entries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.mood_entries_id_seq OWNER TO lifeagent;

--
-- Name: mood_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lifeagent
--

ALTER SEQUENCE public.mood_entries_id_seq OWNED BY public.mood_entries.id;


--
-- Name: notes; Type: TABLE; Schema: public; Owner: lifeagent
--

CREATE TABLE public.notes (
    id integer NOT NULL,
    user_id integer,
    title character varying(255) NOT NULL,
    content text DEFAULT ''::text,
    is_pinned boolean DEFAULT false,
    color character varying(7) DEFAULT '#8B5CF6'::character varying,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.notes OWNER TO lifeagent;

--
-- Name: notes_id_seq; Type: SEQUENCE; Schema: public; Owner: lifeagent
--

CREATE SEQUENCE public.notes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.notes_id_seq OWNER TO lifeagent;

--
-- Name: notes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lifeagent
--

ALTER SEQUENCE public.notes_id_seq OWNED BY public.notes.id;


--
-- Name: otp_challenges; Type: TABLE; Schema: public; Owner: lifeagent
--

CREATE TABLE public.otp_challenges (
    id integer NOT NULL,
    email character varying(100) NOT NULL,
    code_hash character varying(64) NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    attempts integer,
    last_sent_at timestamp with time zone NOT NULL,
    blocked_until timestamp with time zone,
    verified boolean,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.otp_challenges OWNER TO lifeagent;

--
-- Name: otp_challenges_id_seq; Type: SEQUENCE; Schema: public; Owner: lifeagent
--

CREATE SEQUENCE public.otp_challenges_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.otp_challenges_id_seq OWNER TO lifeagent;

--
-- Name: otp_challenges_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lifeagent
--

ALTER SEQUENCE public.otp_challenges_id_seq OWNED BY public.otp_challenges.id;


--
-- Name: portfolio_analyses; Type: TABLE; Schema: public; Owner: lifeagent
--

CREATE TABLE public.portfolio_analyses (
    id integer NOT NULL,
    user_id integer,
    overall_score integer DEFAULT 5 NOT NULL,
    strengths text DEFAULT '[]'::text,
    weaknesses text DEFAULT '[]'::text,
    recommendations text DEFAULT '[]'::text,
    asset_allocation text DEFAULT '{}'::text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.portfolio_analyses OWNER TO lifeagent;

--
-- Name: portfolio_analyses_id_seq; Type: SEQUENCE; Schema: public; Owner: lifeagent
--

CREATE SEQUENCE public.portfolio_analyses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.portfolio_analyses_id_seq OWNER TO lifeagent;

--
-- Name: portfolio_analyses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lifeagent
--

ALTER SEQUENCE public.portfolio_analyses_id_seq OWNED BY public.portfolio_analyses.id;


--
-- Name: reminders; Type: TABLE; Schema: public; Owner: lifeagent
--

CREATE TABLE public.reminders (
    id integer NOT NULL,
    user_id integer,
    text text NOT NULL,
    title character varying(255),
    "time" time without time zone NOT NULL,
    date date,
    completed boolean DEFAULT false,
    color character varying(7) DEFAULT '#3B82F6'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    push_enabled boolean DEFAULT false
);


ALTER TABLE public.reminders OWNER TO lifeagent;

--
-- Name: reminders_id_seq; Type: SEQUENCE; Schema: public; Owner: lifeagent
--

CREATE SEQUENCE public.reminders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.reminders_id_seq OWNER TO lifeagent;

--
-- Name: reminders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lifeagent
--

ALTER SEQUENCE public.reminders_id_seq OWNED BY public.reminders.id;


--
-- Name: schedule_analyses; Type: TABLE; Schema: public; Owner: lifeagent
--

CREATE TABLE public.schedule_analyses (
    id integer NOT NULL,
    user_id integer NOT NULL,
    analysis_data text NOT NULL,
    start_date character varying(20),
    end_date character varying(20),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.schedule_analyses OWNER TO lifeagent;

--
-- Name: schedule_analyses_id_seq; Type: SEQUENCE; Schema: public; Owner: lifeagent
--

CREATE SEQUENCE public.schedule_analyses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.schedule_analyses_id_seq OWNER TO lifeagent;

--
-- Name: schedule_analyses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lifeagent
--

ALTER SEQUENCE public.schedule_analyses_id_seq OWNED BY public.schedule_analyses.id;


--
-- Name: therapy_sessions; Type: TABLE; Schema: public; Owner: lifeagent
--

CREATE TABLE public.therapy_sessions (
    id integer NOT NULL,
    user_id integer,
    chat_id integer,
    summary text DEFAULT ''::text,
    status character varying(20) DEFAULT 'active'::character varying,
    started_at timestamp with time zone DEFAULT now(),
    ended_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.therapy_sessions OWNER TO lifeagent;

--
-- Name: therapy_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: lifeagent
--

CREATE SEQUENCE public.therapy_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.therapy_sessions_id_seq OWNER TO lifeagent;

--
-- Name: therapy_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lifeagent
--

ALTER SEQUENCE public.therapy_sessions_id_seq OWNED BY public.therapy_sessions.id;


--
-- Name: token_transactions; Type: TABLE; Schema: public; Owner: lifeagent
--

CREATE TABLE public.token_transactions (
    id integer NOT NULL,
    user_id integer,
    amount integer NOT NULL,
    transaction_type character varying(20) NOT NULL,
    description text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.token_transactions OWNER TO lifeagent;

--
-- Name: token_transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: lifeagent
--

CREATE SEQUENCE public.token_transactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.token_transactions_id_seq OWNER TO lifeagent;

--
-- Name: token_transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lifeagent
--

ALTER SEQUENCE public.token_transactions_id_seq OWNED BY public.token_transactions.id;


--
-- Name: transactions; Type: TABLE; Schema: public; Owner: lifeagent
--

CREATE TABLE public.transactions (
    id integer NOT NULL,
    statement_id integer,
    user_id integer,
    date date,
    description character varying(500) DEFAULT ''::character varying,
    amount double precision NOT NULL,
    type character varying(10) NOT NULL,
    category character varying(100) DEFAULT 'other'::character varying,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.transactions OWNER TO lifeagent;

--
-- Name: transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: lifeagent
--

CREATE SEQUENCE public.transactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.transactions_id_seq OWNER TO lifeagent;

--
-- Name: transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lifeagent
--

ALTER SEQUENCE public.transactions_id_seq OWNED BY public.transactions.id;


--
-- Name: user_agent_settings; Type: TABLE; Schema: public; Owner: lifeagent
--

CREATE TABLE public.user_agent_settings (
    id integer NOT NULL,
    user_id integer NOT NULL,
    agent_name character varying(50) NOT NULL,
    is_enabled boolean,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.user_agent_settings OWNER TO lifeagent;

--
-- Name: user_agent_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: lifeagent
--

CREATE SEQUENCE public.user_agent_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_agent_settings_id_seq OWNER TO lifeagent;

--
-- Name: user_agent_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lifeagent
--

ALTER SEQUENCE public.user_agent_settings_id_seq OWNED BY public.user_agent_settings.id;


--
-- Name: user_context_profiles; Type: TABLE; Schema: public; Owner: lifeagent
--

CREATE TABLE public.user_context_profiles (
    id integer NOT NULL,
    user_id integer NOT NULL,
    profile_text text DEFAULT ''::text NOT NULL,
    key_goals text DEFAULT '[]'::text,
    health_snapshot text DEFAULT '{}'::text,
    finance_snapshot text DEFAULT '{}'::text,
    schedule_snapshot text DEFAULT '{}'::text,
    personality_traits text DEFAULT '[]'::text,
    profile_embedding public.vector(384),
    version integer DEFAULT 1,
    last_generated_at timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.user_context_profiles OWNER TO lifeagent;

--
-- Name: user_context_profiles_id_seq; Type: SEQUENCE; Schema: public; Owner: lifeagent
--

CREATE SEQUENCE public.user_context_profiles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_context_profiles_id_seq OWNER TO lifeagent;

--
-- Name: user_context_profiles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lifeagent
--

ALTER SEQUENCE public.user_context_profiles_id_seq OWNED BY public.user_context_profiles.id;


--
-- Name: user_diet_profiles; Type: TABLE; Schema: public; Owner: lifeagent
--

CREATE TABLE public.user_diet_profiles (
    id integer NOT NULL,
    user_id integer,
    height integer,
    weight integer,
    age integer,
    gender character varying(10),
    goal character varying(20),
    activity_level character varying(20),
    calorie_target integer,
    protein_target integer,
    fats_target integer,
    carbs_target integer,
    water_target integer,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.user_diet_profiles OWNER TO lifeagent;

--
-- Name: user_diet_profiles_id_seq; Type: SEQUENCE; Schema: public; Owner: lifeagent
--

CREATE SEQUENCE public.user_diet_profiles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_diet_profiles_id_seq OWNER TO lifeagent;

--
-- Name: user_diet_profiles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lifeagent
--

ALTER SEQUENCE public.user_diet_profiles_id_seq OWNED BY public.user_diet_profiles.id;


--
-- Name: user_identities; Type: TABLE; Schema: public; Owner: lifeagent
--

CREATE TABLE public.user_identities (
    id integer NOT NULL,
    user_id integer NOT NULL,
    provider character varying(50) NOT NULL,
    provider_id character varying(255) NOT NULL,
    provider_data text,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.user_identities OWNER TO lifeagent;

--
-- Name: user_identities_id_seq; Type: SEQUENCE; Schema: public; Owner: lifeagent
--

CREATE SEQUENCE public.user_identities_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_identities_id_seq OWNER TO lifeagent;

--
-- Name: user_identities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lifeagent
--

ALTER SEQUENCE public.user_identities_id_seq OWNED BY public.user_identities.id;


--
-- Name: user_knowledge_facts; Type: TABLE; Schema: public; Owner: lifeagent
--

CREATE TABLE public.user_knowledge_facts (
    id integer NOT NULL,
    user_id integer NOT NULL,
    content text NOT NULL,
    embedding public.vector(384),
    source_type character varying(50) DEFAULT 'chat'::character varying NOT NULL,
    agent_name character varying(50) DEFAULT 'system'::character varying NOT NULL,
    memory_tier character varying(20) DEFAULT 'episodic'::character varying NOT NULL,
    importance double precision DEFAULT 0.5,
    access_count integer DEFAULT 0,
    graph_links text DEFAULT '[]'::text,
    source_timestamp timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    expires_at timestamp with time zone
);


ALTER TABLE public.user_knowledge_facts OWNER TO lifeagent;

--
-- Name: user_knowledge_facts_id_seq; Type: SEQUENCE; Schema: public; Owner: lifeagent
--

CREATE SEQUENCE public.user_knowledge_facts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_knowledge_facts_id_seq OWNER TO lifeagent;

--
-- Name: user_knowledge_facts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lifeagent
--

ALTER SEQUENCE public.user_knowledge_facts_id_seq OWNED BY public.user_knowledge_facts.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: lifeagent
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(50) NOT NULL,
    email character varying(100) NOT NULL,
    password_hash character varying(255) NOT NULL,
    google_id character varying(255),
    avatar_url character varying(255),
    age integer,
    token_balance integer DEFAULT 1000,
    plan character varying(20) DEFAULT 'FREE'::character varying,
    credits_used integer DEFAULT 0,
    last_credit_reset date,
    theme_preference character varying(10) DEFAULT 'light'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    onboarding_completed boolean DEFAULT false NOT NULL,
    agents_selected boolean DEFAULT false,
    profile_completed boolean DEFAULT false,
    birth_date date,
    display_name character varying(100),
    offer_accepted_at timestamp with time zone,
    privacy_accepted_at timestamp with time zone
);


ALTER TABLE public.users OWNER TO lifeagent;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: lifeagent
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO lifeagent;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lifeagent
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: active_goals id; Type: DEFAULT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.active_goals ALTER COLUMN id SET DEFAULT nextval('public.active_goals_id_seq'::regclass);


--
-- Name: agent_communications id; Type: DEFAULT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.agent_communications ALTER COLUMN id SET DEFAULT nextval('public.agent_communications_id_seq'::regclass);


--
-- Name: agents id; Type: DEFAULT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.agents ALTER COLUMN id SET DEFAULT nextval('public.agents_id_seq'::regclass);


--
-- Name: bank_statements id; Type: DEFAULT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.bank_statements ALTER COLUMN id SET DEFAULT nextval('public.bank_statements_id_seq'::regclass);


--
-- Name: calendar_events id; Type: DEFAULT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.calendar_events ALTER COLUMN id SET DEFAULT nextval('public.calendar_events_id_seq'::regclass);


--
-- Name: chats id; Type: DEFAULT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.chats ALTER COLUMN id SET DEFAULT nextval('public.chats_id_seq'::regclass);


--
-- Name: daily_food_analyses id; Type: DEFAULT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.daily_food_analyses ALTER COLUMN id SET DEFAULT nextval('public.daily_food_analyses_id_seq'::regclass);


--
-- Name: diary_entries id; Type: DEFAULT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.diary_entries ALTER COLUMN id SET DEFAULT nextval('public.diary_entries_id_seq'::regclass);


--
-- Name: diet_plans id; Type: DEFAULT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.diet_plans ALTER COLUMN id SET DEFAULT nextval('public.diet_plans_id_seq'::regclass);


--
-- Name: dream_analyses id; Type: DEFAULT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.dream_analyses ALTER COLUMN id SET DEFAULT nextval('public.dream_analyses_id_seq'::regclass);


--
-- Name: dream_goals id; Type: DEFAULT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.dream_goals ALTER COLUMN id SET DEFAULT nextval('public.dream_goals_id_seq'::regclass);


--
-- Name: financial_obligations id; Type: DEFAULT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.financial_obligations ALTER COLUMN id SET DEFAULT nextval('public.financial_obligations_id_seq'::regclass);


--
-- Name: food_consumptions id; Type: DEFAULT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.food_consumptions ALTER COLUMN id SET DEFAULT nextval('public.food_consumptions_id_seq'::regclass);


--
-- Name: knowledge_events id; Type: DEFAULT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.knowledge_events ALTER COLUMN id SET DEFAULT nextval('public.knowledge_events_id_seq'::regclass);


--
-- Name: messages id; Type: DEFAULT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.messages ALTER COLUMN id SET DEFAULT nextval('public.messages_id_seq'::regclass);


--
-- Name: mood_entries id; Type: DEFAULT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.mood_entries ALTER COLUMN id SET DEFAULT nextval('public.mood_entries_id_seq'::regclass);


--
-- Name: notes id; Type: DEFAULT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.notes ALTER COLUMN id SET DEFAULT nextval('public.notes_id_seq'::regclass);


--
-- Name: otp_challenges id; Type: DEFAULT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.otp_challenges ALTER COLUMN id SET DEFAULT nextval('public.otp_challenges_id_seq'::regclass);


--
-- Name: portfolio_analyses id; Type: DEFAULT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.portfolio_analyses ALTER COLUMN id SET DEFAULT nextval('public.portfolio_analyses_id_seq'::regclass);


--
-- Name: reminders id; Type: DEFAULT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.reminders ALTER COLUMN id SET DEFAULT nextval('public.reminders_id_seq'::regclass);


--
-- Name: schedule_analyses id; Type: DEFAULT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.schedule_analyses ALTER COLUMN id SET DEFAULT nextval('public.schedule_analyses_id_seq'::regclass);


--
-- Name: therapy_sessions id; Type: DEFAULT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.therapy_sessions ALTER COLUMN id SET DEFAULT nextval('public.therapy_sessions_id_seq'::regclass);


--
-- Name: token_transactions id; Type: DEFAULT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.token_transactions ALTER COLUMN id SET DEFAULT nextval('public.token_transactions_id_seq'::regclass);


--
-- Name: transactions id; Type: DEFAULT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.transactions ALTER COLUMN id SET DEFAULT nextval('public.transactions_id_seq'::regclass);


--
-- Name: user_agent_settings id; Type: DEFAULT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.user_agent_settings ALTER COLUMN id SET DEFAULT nextval('public.user_agent_settings_id_seq'::regclass);


--
-- Name: user_context_profiles id; Type: DEFAULT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.user_context_profiles ALTER COLUMN id SET DEFAULT nextval('public.user_context_profiles_id_seq'::regclass);


--
-- Name: user_diet_profiles id; Type: DEFAULT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.user_diet_profiles ALTER COLUMN id SET DEFAULT nextval('public.user_diet_profiles_id_seq'::regclass);


--
-- Name: user_identities id; Type: DEFAULT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.user_identities ALTER COLUMN id SET DEFAULT nextval('public.user_identities_id_seq'::regclass);


--
-- Name: user_knowledge_facts id; Type: DEFAULT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.user_knowledge_facts ALTER COLUMN id SET DEFAULT nextval('public.user_knowledge_facts_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: active_goals; Type: TABLE DATA; Schema: public; Owner: lifeagent
--

COPY public.active_goals (id, user_id, title, branch_type, resources, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: agent_communications; Type: TABLE DATA; Schema: public; Owner: lifeagent
--

COPY public.agent_communications (id, user_id, requester_agent, target_agent, query_text, response_text, response_embedding, status, tokens_used, created_at, responded_at) FROM stdin;
\.


--
-- Data for Name: agents; Type: TABLE DATA; Schema: public; Owner: lifeagent
--

COPY public.agents (id, name, description, system_prompt, is_active, created_at) FROM stdin;
1	Secretary	Personal assistant for scheduling, reminders, and organization	You are a helpful secretary assistant. Help users with scheduling, reminders, note-taking, and general organization tasks.	t	2026-07-16 11:53:45.815818
2	Accountant	Financial assistant for budgeting and expense tracking	You are a helpful accountant assistant. Help users with budgeting, expense tracking, financial planning, and basic accounting questions.	t	2026-07-16 11:53:45.815818
3	Ментор	Career mentor and dream strategist	Ты — опытный ментор и стратег. Помогаешь пользователю достигать целей.	t	2026-07-16 11:53:56.937474
4	agents	Main AI orchestrator and personal assistant	Ты — Ixteria, ИИ-управляющий. Отвечай по существу, без лишних формальностей и пустых фраз. Длина ответа должна соответствовать сложности и объёму вопроса пользователя: на простые вопросы отвечай кратко, на сложные — развёрнуто и детально. Не задавай встречных вопросов вроде «Как проходит день?». Используй приветствие только если пользователь поздоровался. Никакой воды.	t	2026-07-16 11:59:08.784844
5	dietitian	Dietitian agent	Ты — dietitian, специализированный ИИ-агент.	t	2026-07-16 12:17:57.722379
6	mentor	Mentor agent	Ты — mentor, специализированный ИИ-агент.	t	2026-07-16 13:32:58.847246
7	secretary	Secretary agent	Ты — secretary, специализированный ИИ-агент.	t	2026-07-20 18:42:55.576036
8	psychologist	Psychologist agent	Ты — psychologist, специализированный ИИ-агент.	t	2026-08-02 09:41:03.697243
9	accountant	Accountant agent	Ты — accountant, специализированный ИИ-агент.	t	2026-08-03 08:56:54.513648
\.


--
-- Data for Name: bank_statements; Type: TABLE DATA; Schema: public; Owner: lifeagent
--

COPY public.bank_statements (id, user_id, filename, bank_name, period_start, period_end, total_income, total_expense, categories_data, analysis_text, raw_content, status, created_at) FROM stdin;
8	4	Выписка по договору от 11 июля 2026.pdf	АО «Яндекс Банк»	2026-06-10	2026-07-10	108046.62999999999	97376.51	{"Доход (оплата по договору)": {"description": "Поступления по договорам", "income": 25494.24, "expense": 0.0, "count": 7}, "Переводы между счетами": {"description": "Переводы между собственными счетами", "income": 3000.0, "expense": 0.0, "count": 3}, "Переводы (исходящие)": {"description": "Исходящие переводы другим лицам", "income": 0.0, "expense": 10270.0, "count": 6}, "Продукты": {"description": "Покупки в продуктовых магазинах", "income": 0.0, "expense": 11676.98, "count": 51}, "Развлечения": {"description": "Оплата развлекательных услуг и сервисов", "income": 0.0, "expense": 7589.0, "count": 16}, "Транспорт": {"description": "Оплата транспортных услуг", "income": 0.0, "expense": 941.0, "count": 25}, "Прочее": {"description": "Прочие расходы, не классифицированные", "income": 0.0, "expense": 9426.310000000001, "count": 19}, "Доход (оплата по договорам)": {"description": "Поступление средств по договорам", "income": 30543.940000000002, "expense": 0.0, "count": 9}, "Переводы": {"description": "Входящие и исходящие переводы средств", "income": 45059.92, "expense": 45974.0, "count": 34}, "Онлайн-сервисы": {"description": "Оплата услуг онлайн-сервисов, например, Yandex", "income": 0.0, "expense": 337.0, "count": 1}, "Доставка": {"description": "Оплата услуг доставки, например, Samokat", "income": 0.0, "expense": 1915.0, "count": 5}, "Доход (прочее)": {"description": "Прочие доходы, не классифицированные иначе", "income": 6872.95, "expense": 0.0, "count": 2}, "Покупки": {"description": "Оплата товаров и услуг (кроме продуктов и транспорта)", "income": 0.0, "expense": 3777.63, "count": 10}, "Оплата услуг": {"description": "Оплата различных услуг через СБП QR", "income": 0.0, "expense": 1079.4, "count": 7}}	В течение отчетного периода наблюдается баланс между доходами и расходами, однако значительная часть трат приходится на переводы и покупки в продуктовых магазинах. Рекомендуется более детально проанализировать структуру исходящих переводов и рассмотреть возможности оптимизации расходов на продукты питания. За период с 12 по 22 июня 2026 года наблюдается значительный приток средств по договорам, что покрывает основные расходы. Основные траты приходятся на переводы, продукты питания и оплату услуг доставки. Рекомендуется более детально проанализировать структуру переводов и рассмотреть возможности оптимизации расходов на продукты и доставку. За период наблюдается значительное количество трат на продукты питания и развлечения (онлайн-сервисы, маркетплейсы). Также присутствуют регулярные переводы между счетами, что может указывать на управление личными финансами или накопления. Рекомендуется проанализировать структуру расходов на продукты и развлечения для возможной оптимизации. За период наблюдается значительный объем расходов на продукты питания и прочие покупки, что может указывать на необходимость оптимизации бюджета. Также присутствуют существенные переводы между счетами, что требует дополнительного анализа. Рекомендуется более детально изучить структуру расходов и рассмотреть возможности для их сокращения. В данном периоде наблюдается значительный объем переводов между счетами и другим лицам, что может указывать на активное управление личными финансами или инвестиционную деятельность. Основные расходы приходятся на продукты питания и оплату услуг через СБП. Рекомендуется более детально проанализировать структуру расходов на продукты и услуги для возможной оптимизации.	Выписка по договору\nИсх. № 202607113533059\nДата 11.07.2026\nАО «Яндекс Банк», лицензия Банка России № 3027 (далее — «Банк»),\nсообщает, что между Вами и Банком заключён договор\n№ В20251211309616072 от 11.12.2025 в рамках продукта\n«Банковский счёт Про» (далее — «Договор»).\nБастригин Валерий Евгеньевич\nДата рождения 16.07.2000\nПаспорт РФ № 9220 822033\nВ рамках Договора открыт счёт\n40817810020001016225\nНомер счёта\nВыписка по Договору за период с 10.06.2026 по 10.07.2026\nОписание операции\nДата и время\nоперации\nМСК\nДата\nобработки\nМСК\nКарта\nСумма в валюте\nоперации\nСумма в валюте\nДоговора\nОпл.по Дог.ОФ-26561424 17693.96\nруб\n10.06.2026\nв 09:34\n10.06.2026\n+17 693,96 ₽\n+17 693,96 ₽\nОпл.по Дог.26658326/25 1286.78\nруб\n10.06.2026\nв 09:35\n10.06.2026\n+1 286,78 ₽\n+1 286,78 ₽\nПеревод между счетами одного\nклиента\n10.06.2026\nв 10:31\n10.06.2026\n–3 412,00 ₽\n–3 412,00 ₽\nИсходящий перевод СБП, Валерий\nЕвгеньевич Б., +7 950 328-85-89, Т-\nБанк\n10.06.2026\nв 10:33\n10.06.2026\n–2 200,00 ₽\n–2 200,00 ₽\nИсходящий перевод СБП, Валерий\nЕвгеньевич Б., +7 950 328-85-89, Т-\nБанк\n10.06.2026\nв 10:33\n10.06.2026\n–3 000,00 ₽\n–3 000,00 ₽\nИсходящий перевод СБП, Надежда\nПетровна П., +7 911 269-21-08, ВТБ\n10.06.2026\nв 10:35\n10.06.2026\n–3 000,00 ₽\n–3 000,00 ₽\nПеревод между счетами одного\nклиента\n10.06.2026\nв 10:37\n10.06.2026\n–3 000,00 ₽\n–3 000,00 ₽\nОплата СБП QR (Додо Пицца,\nШушары-1)\n10.06.2026\nв 12:18\n10.06.2026\n–1 030,00 ₽\n–1 030,00 ₽\nОплата товаров и услуг DIXY-\n78336D\n08.06.2026\nв 14:32\n10.06.2026\n*1848\n–339,78 ₽\n–339,78 ₽\nВходящий остаток на 10.06.2026\n1 487,07 ₽\nСтраница 1 из 15\nПродолжение на следующей странице\n\nОписание операции\nДата и время\nоперации\nМСК\nДата\nобработки\nМСК\nКарта\nСумма в валюте\nоперации\nСумма в валюте\nДоговора\nОплата СБП QR (OZON)\n10.06.2026\nв 14:54\n10.06.2026\n–531,00 ₽\n–531,00 ₽\nОплата товаров и услуг DIXY-\n78336D\n08.06.2026\nв 20:48\n10.06.2026\n*1848\n–103,79 ₽\n–103,79 ₽\nОплата товаров и услуг\nPYATEROCHKA 7149\n08.06.2026\nв 08:05\n10.06.2026\n*1848\n–119,98 ₽\n–119,98 ₽\nОплата товаров и услуг\nYANDEX*7999*BIKE\n08.06.2026\nв 07:36\n10.06.2026\n*1848\n–1,00 ₽\n–1,00 ₽\nОплата СБП QR (Sota Connect)\n10.06.2026\nв 17:18\n10.06.2026\n–349,00 ₽\n–349,00 ₽\nОплата товаров и услуг\nPYATEROCHKA 7149\n08.06.2026\nв 11:56\n10.06.2026\n*1848\n–194,07 ₽\n–194,07 ₽\nОплата товаров и услуг\nYANDEX*5815*PLUS\n10.06.2026\nв 23:44\n11.06.2026\n*1848\n–449,00 ₽\n–449,00 ₽\nПеревод между счетами одного\nклиента\n11.06.2026\nв 14:53\n11.06.2026\n+1 000,00 ₽\n+1 000,00 ₽\nОплата СБП QR (ТОО "ОнлиПэй")\n11.06.2026\nв 15:02\n11.06.2026\n–109,89 ₽\n–109,89 ₽\nОплата товаров и услуг DIXY-\n78336D\n09.06.2026\nв 14:26\n11.06.2026\n*1848\n–513,32 ₽\n–513,32 ₽\nОплата товаров и услуг\nYANDEX*7999*BIKE\n09.06.2026\nв 08:16\n11.06.2026\n*1848\n–1,00 ₽\n–1,00 ₽\nОплата товаров и услуг\nPYATEROCHKA 6\n09.06.2026\nв 07:24\n11.06.2026\n*1848\n–59,98 ₽\n–59,98 ₽\nОплата товаров и услуг\nPYATEROCHKA 6\n09.06.2026\nв 10:34\n11.06.2026\n*1848\n–136,98 ₽\n–136,98 ₽\nОплата СБП QR (ТОО "ОнлиПэй")\n11.06.2026\nв 19:20\n11.06.2026\n–109,89 ₽\n–109,89 ₽\nОплата СБП QR\n(podorozhnik.spb.ru_SBP)\n12.06.2026\nв 06:53\n12.06.2026\n–130,00 ₽\n–130,00 ₽\nИсходящий перевод СБП, Эмилия\nРатхановна К., +7 952 242-16-98,\nСбербанк\n12.06.2026\nв 07:08\n12.06.2026\n–70,00 ₽\n–70,00 ₽\nСтраница 2 из 15\nПродолжение на следующей странице\n\nОписание операции\nДата и время\nоперации\nМСК\nДата\nобработки\nМСК\nКарта\nСумма в валюте\nоперации\nСумма в валюте\nДоговора\nПеревод между счетами одного\nклиента\n12.06.2026\nв 16:01\n12.06.2026\n+2 000,00 ₽\n+2 000,00 ₽\nВнутрибанковский перевод на +7\n996 903-73-17, Алина К.\n12.06.2026\nв 16:02\n12.06.2026\n–1 000,00 ₽\n–1 000,00 ₽\nОплата товаров и услуг DIXY-\n78336D\n10.06.2026\nв 12:31\n12.06.2026\n*1848\n–756,58 ₽\n–756,58 ₽\nОплата товаров и услуг APTEKA 78-\n2020\n10.06.2026\nв 15:03\n12.06.2026\n*1848\n–220,00 ₽\n–220,00 ₽\nОплата товаров и услуг\nPYATEROCHKA 6\n11.06.2026\nв 10:44\n12.06.2026\n*1848\n–189,97 ₽\n–189,97 ₽\nОплата СБП QR\n(podorozhnik.spb.ru_SBP)\n13.06.2026\nв 07:03\n13.06.2026\n–130,00 ₽\n–130,00 ₽\nОплата товаров и услуг\nYANDEX*7999*BIKE\n11.06.2026\nв 08:14\n13.06.2026\n*1848\n–1,00 ₽\n–1,00 ₽\nОплата товаров и услуг\nSBER*5411*SAMOKAT\n11.06.2026\nв 20:11\n13.06.2026\n*1848\n–463,00 ₽\n–463,00 ₽\nОплата товаров и услуг DIXY-\n78336D\n11.06.2026\nв 12:12\n13.06.2026\n*1848\n–148,98 ₽\n–148,98 ₽\nОплата товаров и услуг\nPYATEROCHKA 6\n11.06.2026\nв 11:18\n13.06.2026\n*1848\n–199,98 ₽\n–199,98 ₽\nОплата товаров и услуг\nPYATEROCHKA 6\n11.06.2026\nв 07:16\n13.06.2026\n*1848\n–59,98 ₽\n–59,98 ₽\nОплата СБП QR\n(podorozhnik.spb.ru_SBP)\n14.06.2026\nв 07:03\n14.06.2026\n–130,00 ₽\n–130,00 ₽\nОплата товаров и услуг MAGNIT\nMM ANDROMAKHA\n12.06.2026\nв 08:00\n14.06.2026\n*1848\n–114,98 ₽\n–114,98 ₽\nОплата товаров и услуг MAGNIT\nMM ANDROMAKHA\n12.06.2026\nв 14:00\n14.06.2026\n*1848\n–99,98 ₽\n–99,98 ₽\nОплата товаров и услуг\nYANDEX*7999*BIKE\n12.06.2026\nв 12:38\n14.06.2026\n*1848\n–1,00 ₽\n–1,00 ₽\nОплата товаров и услуг DIXY-\n78336D\n12.06.2026\nв 18:08\n14.06.2026\n*1848\n–258,91 ₽\n–258,91 ₽\nСтраница 3 из 15\nПродолжение на следующей странице\n\nОписание операции\nДата и время\nоперации\nМСК\nДата\nобработки\nМСК\nКарта\nСумма в валюте\nоперации\nСумма в валюте\nДоговора\nОплата товаров и услуг\nYANDEX*7999*BIKE\n12.06.2026\nв 08:34\n14.06.2026\n*1848\n–1,00 ₽\n–1,00 ₽\nОплата товаров и услуг\nPYATEROCHKA 6812\n12.06.2026\nв 10:54\n14.06.2026\n*1848\n–89,98 ₽\n–89,98 ₽\nОпл.по Дог.26658326/25 4176.52\nруб\n15.06.2026\nв 11:08\n15.06.2026\n+4 176,52 ₽\n+4 176,52 ₽\nОплата СБП QR (FUNPAY)\n15.06.2026\nв 12:23\n15.06.2026\n–683,76 ₽\n–683,76 ₽\nОплата товаров и услуг DIXY-\n78336D\n13.06.2026\nв 16:00\n15.06.2026\n*1848\n–300,86 ₽\n–300,86 ₽\nОплата товаров и услуг MAGNIT\nMM ANDROMAKHA\n13.06.2026\nв 08:00\n15.06.2026\n*1848\n–96,98 ₽\n–96,98 ₽\nОплата товаров и услуг\nYANDEX*7999*BIKE\n13.06.2026\nв 08:29\n15.06.2026\n*1848\n–1,00 ₽\n–1,00 ₽\nОплата товаров и услуг\nPYATEROCHKA 6812\n13.06.2026\nв 13:00\n15.06.2026\n*1848\n–69,99 ₽\n–69,99 ₽\nВнутрибанковский перевод на +7\n996 903-73-17, Алина К.\n15.06.2026\nв 16:47\n15.06.2026\n–2 000,00 ₽\n–2 000,00 ₽\nОплата товаров и услуг\nYANDEX*7999*BIKE\n14.06.2026\nв 07:41\n16.06.2026\n*1848\n–1,00 ₽\n–1,00 ₽\nОплата товаров и услуг MAGNIT\nMM ANDROMAKHA\n14.06.2026\nв 08:03\n16.06.2026\n*1848\n–104,98 ₽\n–104,98 ₽\nОплата товаров и услуг\nYANDEX*5411*LAVKA\n16.06.2026\nв 17:43\n16.06.2026\n*1848\n–337,00 ₽\n–337,00 ₽\nОпл.по Дог.ОФ-26561424 10126.57\nруб\n17.06.2026\nв 11:06\n17.06.2026\n+10 126,57 ₽\n+10 126,57 ₽\nВнутрибанковский перевод на +7\n996 903-73-17, Алина К.\n17.06.2026\nв 11:24\n17.06.2026\n–2 000,00 ₽\n–2 000,00 ₽\nОплата товаров и услуг DIXY-\n78336D\n15.06.2026\nв 11:39\n17.06.2026\n*1848\n–229,95 ₽\n–229,95 ₽\nОплата товаров и услуг\nSBER*5411*SAMOKAT\n15.06.2026\nв 19:44\n17.06.2026\n*1848\n–444,00 ₽\n–444,00 ₽\nСтраница 4 из 15\nПродолжение на следующей странице\n\nОписание операции\nДата и время\nоперации\nМСК\nДата\nобработки\nМСК\nКарта\nСумма в валюте\nоперации\nСумма в валюте\nДоговора\nИсходящий перевод СБП, Валерий\nЕвгеньевич Б., +7 950 328-85-89, Т-\nБанк\n17.06.2026\nв 17:50\n17.06.2026\n–5 000,00 ₽\n–5 000,00 ₽\nОплата товаров и услуг\nSBER*5411*SAMOKAT\n15.06.2026\nв 19:16\n17.06.2026\n*1848\n–472,00 ₽\n–472,00 ₽\nОпл.по Дог.26658326/25 673.06 руб\n18.06.2026\nв 10:36\n18.06.2026\n+673,06 ₽\n+673,06 ₽\nВходящий перевод по номеру\nкарты (Tribute)\n18.06.2026\nв 13:00\n18.06.2026\n*1848\n+4 860,00 ₽\n+4 860,00 ₽\nПеревод между счетами одного\nклиента\n18.06.2026\nв 15:00\n18.06.2026\n–5 000,00 ₽\n–5 000,00 ₽\nОплата СБП QR (Озон)\n18.06.2026\nв 16:34\n18.06.2026\n–629,00 ₽\n–629,00 ₽\nОплата СБП QR (OZON)\n18.06.2026\nв 18:14\n18.06.2026\n–509,00 ₽\n–509,00 ₽\nОплата СБП QR\n(podorozhnik.spb.ru_SBP)\n19.06.2026\nв 07:03\n19.06.2026\n–130,00 ₽\n–130,00 ₽\nВходящий перевод СБП, Тимур\nРафкатович Г., +7 991 002-59-41,\nОзон Банк (Ozon)\n19.06.2026\nв 11:51\n19.06.2026\n+1 579,00 ₽\n+1 579,00 ₽\nВходящий перевод СБП, Алина\nАлександровна К., +7 996 903-73-17,\nТ-Банк\n19.06.2026\nв 12:31\n19.06.2026\n+5 000,00 ₽\n+5 000,00 ₽\nОплата СБП QR (Озон)\n19.06.2026\nв 17:25\n19.06.2026\n–520,00 ₽\n–520,00 ₽\nОплата товаров и услуг\nSBER*5411*SAMOKAT\n17.06.2026\nв 20:03\n19.06.2026\n*1848\n–450,00 ₽\n–450,00 ₽\nОплата товаров и услуг DIXY-\n78336D\n17.06.2026\nв 13:12\n19.06.2026\n*1848\n–659,58 ₽\n–659,58 ₽\nОплата товаров и услуг MAGNIT\nMM ANDROMAKHA\n17.06.2026\nв 08:02\n19.06.2026\n*1848\n–104,98 ₽\n–104,98 ₽\nОплата товаров и услуг\nYANDEX*7999*BIKE\n17.06.2026\nв 08:34\n19.06.2026\n*1848\n–1,00 ₽\n–1,00 ₽\nОплата СБП QR\n(podorozhnik.spb.ru_SBP)\n20.06.2026\nв 07:03\n20.06.2026\n–130,00 ₽\n–130,00 ₽\nСтраница 5 из 15\nПродолжение на следующей странице\n\nОписание операции\nДата и время\nоперации\nМСК\nДата\nобработки\nМСК\nКарта\nСумма в валюте\nоперации\nСумма в валюте\nДоговора\nОплата товаров и услуг DIXY-\n78336D\n18.06.2026\nв 11:09\n20.06.2026\n*1848\n–279,95 ₽\n–279,95 ₽\nОплата СБП QR\n(podorozhnik.spb.ru_SBP)\n21.06.2026\nв 07:05\n21.06.2026\n–130,00 ₽\n–130,00 ₽\nОплата товаров и услуг DIXY-\n78336D\n19.06.2026\nв 14:04\n21.06.2026\n*1848\n–269,88 ₽\n–269,88 ₽\nИсходящий перевод СБП, Валерий\nЕвгеньевич Б., +7 950 328-85-89,\nОзон Банк (Ozon)\n21.06.2026\nв 16:11\n21.06.2026\n–1 460,00 ₽\n–1 460,00 ₽\nОплата СБП QR\n(podorozhnik.spb.ru_SBP)\n21.06.2026\nв 16:21\n21.06.2026\n–130,00 ₽\n–130,00 ₽\nОплата товаров и услуг\nYANDEX*7999*BIKE\n19.06.2026\nв 08:47\n21.06.2026\n*1848\n–1,00 ₽\n–1,00 ₽\nОплата товаров и услуг AU3402\n19.06.2026\nв 11:04\n21.06.2026\n*1848\n–220,00 ₽\n–220,00 ₽\nОплата товаров и услуг MAGNIT\nMM ANDROMAKHA\n19.06.2026\nв 08:04\n21.06.2026\n*1848\n–169,98 ₽\n–169,98 ₽\nОплата товаров и услуг\nPYATEROCHKA 6812\n19.06.2026\nв 12:22\n21.06.2026\n*1848\n–69,99 ₽\n–69,99 ₽\nОплата товаров и услуг\nSBER*5411*SAMOKAT\n19.06.2026\nв 20:46\n21.06.2026\n*1848\n–499,00 ₽\n–499,00 ₽\nОпл.по Дог.26658326/25 3594.49\nруб\n22.06.2026\nв 10:40\n22.06.2026\n+3 594,49 ₽\n+3 594,49 ₽\nОплата СБП QR\n(podorozhnik.spb.ru_SBP)\n22.06.2026\nв 12:21\n22.06.2026\n–130,00 ₽\n–130,00 ₽\nИсходящий перевод СБП, Надежда\nПетровна П., +7 911 269-21-08, ВТБ\n22.06.2026\nв 13:45\n22.06.2026\n–3 851,00 ₽\n–3 851,00 ₽\nОплата товаров и услуг\nPYATEROCHKA 6812\n20.06.2026\nв 08:07\n22.06.2026\n*1848\n–119,98 ₽\n–119,98 ₽\nОплата товаров и услуг\nSBER*5411*SAMOKAT\n20.06.2026\nв 20:54\n22.06.2026\n*1848\n–542,00 ₽\n–542,00 ₽\nОплата товаров и услуг\nPYATEROCHKA 6812\n20.06.2026\nв 13:59\n22.06.2026\n*1848\n–115,98 ₽\n–115,98 ₽\nСтраница 6 из 15\nПродолжение на следующей странице\n\nОписание операции\nДата и время\nоперации\nМСК\nДата\nобработки\nМСК\nКарта\nСумма в валюте\nоперации\nСумма в валюте\nДоговора\nОплата товаров и услуг AU3402\n20.06.2026\nв 15:13\n22.06.2026\n*1848\n–350,00 ₽\n–350,00 ₽\nОплата товаров и услуг\nYANDEX*7999*BIKE\n20.06.2026\nв 08:58\n22.06.2026\n*1848\n–1,00 ₽\n–1,00 ₽\nОплата товаров и услуг\nPYATEROCHKA 6812\n20.06.2026\nв 11:07\n22.06.2026\n*1848\n–119,98 ₽\n–119,98 ₽\nОплата товаров и услуг\nUNIVERSAM VMESTE 24 CH\n20.06.2026\nв 17:30\n22.06.2026\n*1848\n–171,33 ₽\n–171,33 ₽\nОплата СБП QR (Озон)\n22.06.2026\nв 19:32\n22.06.2026\n–519,00 ₽\n–519,00 ₽\nПеревод между счетами одного\nклиента\n23.06.2026\nв 12:11\n23.06.2026\n+500,00 ₽\n+500,00 ₽\nОпл.по Дог.26658326/25 877.31 руб\n23.06.2026\nв 12:37\n23.06.2026\n+877,31 ₽\n+877,31 ₽\nПеревод между счетами одного\nклиента\n23.06.2026\nв 13:30\n23.06.2026\n–600,00 ₽\n–600,00 ₽\nОплата товаров и услуг\nPYATEROCHKA 6812\n21.06.2026\nв 13:20\n23.06.2026\n*1848\n–109,98 ₽\n–109,98 ₽\nОплата товаров и услуг MAGNIT\nMM ANDROMAKHA\n21.06.2026\nв 08:02\n23.06.2026\n*1848\n–109,98 ₽\n–109,98 ₽\nОплата товаров и услуг\nPYATEROCHKA 6812\n21.06.2026\nв 10:31\n23.06.2026\n*1848\n–119,98 ₽\n–119,98 ₽\nОплата СБП QR\n(podorozhnik.spb.ru_SBP)\n23.06.2026\nв 17:26\n23.06.2026\n–130,00 ₽\n–130,00 ₽\nОплата товаров и услуг DIXY-\n78336D\n21.06.2026\nв 16:58\n23.06.2026\n*1848\n–346,47 ₽\n–346,47 ₽\nОплата СБП QR (Дикси 78336)\n23.06.2026\nв 18:05\n23.06.2026\n–279,88 ₽\n–279,88 ₽\nОплата товаров и услуг\nYANDEX*7999*BIKE\n21.06.2026\nв 07:45\n23.06.2026\n*1848\n–1,00 ₽\n–1,00 ₽\nПеревод между счетами одного\nклиента\n23.06.2026\nв 19:00\n23.06.2026\n+600,00 ₽\n+600,00 ₽\nОплата СБП QR (Озон)\n23.06.2026\nв 19:00\n23.06.2026\n–737,00 ₽\n–737,00 ₽\nСтраница 7 из 15\nПродолжение на следующей странице\n\nОписание операции\nДата и время\nоперации\nМСК\nДата\nобработки\nМСК\nКарта\nСумма в валюте\nоперации\nСумма в валюте\nДоговора\nОпл.по Дог.ОФ-26561424 5995.65\nруб\n24.06.2026\nв 09:37\n24.06.2026\n+5 995,65 ₽\n+5 995,65 ₽\nОпл.по Дог.26658326/25 1290.39\nруб\n24.06.2026\nв 09:37\n24.06.2026\n+1 290,39 ₽\n+1 290,39 ₽\nПеревод между счетами одного\nклиента\n24.06.2026\nв 11:30\n24.06.2026\n–1 500,00 ₽\n–1 500,00 ₽\nОплата товаров и услуг DIXY-\n78336D\n22.06.2026\nв 12:59\n24.06.2026\n*1848\n–59,99 ₽\n–59,99 ₽\nОплата товаров и услуг\nYANDEX*7999*BIKE\n22.06.2026\nв 07:43\n24.06.2026\n*1848\n–1,00 ₽\n–1,00 ₽\nОплата товаров и услуг MAGNIT\nMM ANDROMAKHA\n22.06.2026\nв 08:04\n24.06.2026\n*1848\n–169,97 ₽\n–169,97 ₽\nОплата товаров и услуг DIXY-\n78336D\n22.06.2026\nв 12:58\n24.06.2026\n*1848\n–359,86 ₽\n–359,86 ₽\nОплата СБП QR (Озон)\n24.06.2026\nв 17:36\n24.06.2026\n–554,00 ₽\n–554,00 ₽\nОплата СБП QR (t2_SBP)\n24.06.2026\nв 20:59\n24.06.2026\n–650,00 ₽\n–650,00 ₽\nОплата СБП QR (t2)\n25.06.2026\nв 10:36\n25.06.2026\n–100,00 ₽\n–100,00 ₽\nОпл.по Дог.26658326/25 37.00 руб\n25.06.2026\nв 11:07\n25.06.2026\n+37,00 ₽\n+37,00 ₽\nОплата СБП QR (OZON)\n25.06.2026\nв 16:53\n25.06.2026\n–520,00 ₽\n–520,00 ₽\nОплата товаров и услуг\nPYATEROCHKA 6812\n23.06.2026\nв 08:01\n25.06.2026\n*1848\n–189,97 ₽\n–189,97 ₽\nОплата товаров и услуг\nYANDEX*7999*BIKE\n23.06.2026\nв 09:29\n25.06.2026\n*1848\n–1,00 ₽\n–1,00 ₽\nОплата товаров и услуг\nPYATEROCHKA 6812\n23.06.2026\nв 12:12\n25.06.2026\n*1848\n–59,99 ₽\n–59,99 ₽\nОплата товаров и услуг\nPYATEROCHKA 6812\n23.06.2026\nв 12:12\n25.06.2026\n*1848\n–95,98 ₽\n–95,98 ₽\nОплата СБП QR (FUNPAY)\n25.06.2026\nв 20:30\n25.06.2026\n–291,60 ₽\n–291,60 ₽\nСтраница 8 из 15\nПродолжение на следующей странице\n\nОписание операции\nДата и время\nоперации\nМСК\nДата\nобработки\nМСК\nКарта\nСумма в валюте\nоперации\nСумма в валюте\nДоговора\nОплата СБП QR (Озон)\n25.06.2026\nв 21:31\n25.06.2026\n–609,00 ₽\n–609,00 ₽\nОплата товаров и услуг DIXY-\n78336D\n24.06.2026\nв 11:51\n26.06.2026\n*1848\n–19,99 ₽\n–19,99 ₽\nОплата товаров и услуг DIXY-\n78336D\n24.06.2026\nв 11:50\n26.06.2026\n*1848\n–479,82 ₽\n–479,82 ₽\nОплата товаров и услуг\nPYATEROCHKA 22266\n25.06.2026\nв 10:46\n27.06.2026\n*1848\n–124,98 ₽\n–124,98 ₽\nОплата товаров и услуг DIXY-\n78336D\n25.06.2026\nв 10:53\n27.06.2026\n*1848\n–119,90 ₽\n–119,90 ₽\nОплата товаров и услуг DIXY-\n78336D\n25.06.2026\nв 10:52\n27.06.2026\n*1848\n–289,87 ₽\n–289,87 ₽\nОплата товаров и услуг\nSBER*5411*SAMOKAT\n25.06.2026\nв 17:48\n27.06.2026\n*1848\n–536,00 ₽\n–536,00 ₽\nОплата СБП QR\n(podorozhnik.spb.ru_SBP)\n27.06.2026\nв 16:15\n27.06.2026\n–130,00 ₽\n–130,00 ₽\nПеревод между счетами одного\nклиента\n27.06.2026\nв 18:07\n27.06.2026\n+1 000,00 ₽\n+1 000,00 ₽\nОплата СБП QR (Озон)\n27.06.2026\nв 18:08\n27.06.2026\n–554,00 ₽\n–554,00 ₽\nОплата СБП QR\n(podorozhnik.spb.ru_SBP)\n28.06.2026\nв 12:09\n28.06.2026\n–130,00 ₽\n–130,00 ₽\nПеревод между счетами одного\nклиента\n28.06.2026\nв 12:49\n28.06.2026\n+1 000,00 ₽\n+1 000,00 ₽\nОплата СБП QR (ООО "ИНТЕР")\n28.06.2026\nв 14:33\n28.06.2026\n–200,00 ₽\n–200,00 ₽\nОплата товаров и услуг\nSBER*5411*SAMOKAT\n26.06.2026\nв 16:34\n28.06.2026\n*1848\n–476,00 ₽\n–476,00 ₽\nОплата СБП QR (Озон)\n28.06.2026\nв 15:38\n28.06.2026\n–534,00 ₽\n–534,00 ₽\nОплата товаров и услуг\nPYATEROCHKA 22266\n26.06.2026\nв 12:18\n28.06.2026\n*1848\n–245,96 ₽\n–245,96 ₽\nПеревод между счетами одного\nклиента\n28.06.2026\nв 16:32\n28.06.2026\n+1 000,00 ₽\n+1 000,00 ₽\nСтраница 9 из 15\nПродолжение на следующей странице\n\nОписание операции\nДата и время\nоперации\nМСК\nДата\nобработки\nМСК\nКарта\nСумма в валюте\nоперации\nСумма в валюте\nДоговора\nОплата товаров и услуг IP\nMITCHENKO D.YU.\n27.06.2026\nв 11:05\n28.06.2026\n*1848\n–290,00 ₽\n–290,00 ₽\nОпл.по Дог.26658326/25 1203.84\nруб\n29.06.2026\nв 10:46\n29.06.2026\n+1 203,84 ₽\n+1 203,84 ₽\nОплата СБП QR\n(podorozhnik.spb.ru_SBP)\n29.06.2026\nв 12:18\n29.06.2026\n–130,00 ₽\n–130,00 ₽\nОплата товаров и услуг\nKRASNOE&BELOE\n27.06.2026\nв 11:06\n29.06.2026\n*1848\n–59,99 ₽\n–59,99 ₽\nОплата товаров и услуг\nPYATEROCHKA 6812\n27.06.2026\nв 08:00\n29.06.2026\n*1848\n–109,98 ₽\n–109,98 ₽\nОплата товаров и услуг\nPYATEROCHKA 6812\n27.06.2026\nв 13:08\n29.06.2026\n*1848\n–189,97 ₽\n–189,97 ₽\nОплата товаров и услуг\nYANDEX*7999*BIKE\n27.06.2026\nв 08:58\n29.06.2026\n*1848\n–1,00 ₽\n–1,00 ₽\nОплата СБП QR (ООО "ИНТЕР")\n29.06.2026\nв 17:13\n29.06.2026\n–100,00 ₽\n–100,00 ₽\nОплата СБП QR (Озон)\n29.06.2026\nв 18:00\n29.06.2026\n–531,00 ₽\n–531,00 ₽\nОпл.по Дог.26658326/25 574.29 руб\n30.06.2026\nв 11:12\n30.06.2026\n+574,29 ₽\n+574,29 ₽\nОплата СБП QR\n(podorozhnik.spb.ru_SBP)\n30.06.2026\nв 14:12\n30.06.2026\n–130,00 ₽\n–130,00 ₽\nОплата СБП QR (ООО "ИНТЕР")\n30.06.2026\nв 15:18\n30.06.2026\n–100,00 ₽\n–100,00 ₽\nОплата товаров и услуг\nPYATEROCHKA 22266\n28.06.2026\nв 12:50\n30.06.2026\n*1848\n–222,77 ₽\n–222,77 ₽\nОплата СБП QR (ООО "ИНТЕР")\n30.06.2026\nв 16:30\n30.06.2026\n–100,00 ₽\n–100,00 ₽\nОплата товаров и услуг\nSBER*5411*SAMOKAT\n28.06.2026\nв 16:32\n30.06.2026\n*1848\n–507,00 ₽\n–507,00 ₽\nОплата товаров и услуг\nYANDEX*7999*BIKE\n28.06.2026\nв 07:46\n30.06.2026\n*1848\n–1,00 ₽\n–1,00 ₽\nОплата товаров и услуг\nPYATEROCHKA 6812\n28.06.2026\nв 08:02\n30.06.2026\n*1848\n–109,98 ₽\n–109,98 ₽\nСтраница 10 из 15\nПродолжение на следующей странице\n\nОписание операции\nДата и время\nоперации\nМСК\nДата\nобработки\nМСК\nКарта\nСумма в валюте\nоперации\nСумма в валюте\nДоговора\nОплата СБП QR (ООО "ИНТЕР")\n30.06.2026\nв 18:04\n30.06.2026\n–100,00 ₽\n–100,00 ₽\nОплата товаров и услуг DIXY-\n78336D\n28.06.2026\nв 12:45\n30.06.2026\n*1848\n–447,56 ₽\n–447,56 ₽\nОплата СБП QR (ООО "ИНТЕР")\n30.06.2026\nв 19:44\n30.06.2026\n–100,00 ₽\n–100,00 ₽\nВходящий перевод по номеру\nкарты (IPKAMBULATOVAZN)\n01.07.2026\nв 09:41\n01.07.2026\n*1848\n+1 080,00 ₽\n+1 080,00 ₽\nПеревод между счетами одного\nклиента\n01.07.2026\nв 10:00\n01.07.2026\n–800,00 ₽\n–800,00 ₽\nОпл.по Дог.ОФ-26561424 5281.90\nруб\n01.07.2026\nв 11:07\n01.07.2026\n+5 281,90 ₽\n+5 281,90 ₽\nОпл.по Дог.26658326/25 637.56 руб\n01.07.2026\nв 11:07\n01.07.2026\n+637,56 ₽\n+637,56 ₽\nПеревод между счетами одного\nклиента\n01.07.2026\nв 13:37\n01.07.2026\n–5 200,00 ₽\n–5 200,00 ₽\nОплата товаров и услуг\nYANDEX*7999*BIKE\n29.06.2026\nв 07:40\n01.07.2026\n*1848\n–1,00 ₽\n–1,00 ₽\nОплата товаров и услуг DIXY-\n78336D\n29.06.2026\nв 12:55\n01.07.2026\n*1848\n–409,77 ₽\n–409,77 ₽\nВходящий перевод по номеру\nкарты (Tribute)\n01.07.2026\nв 15:50\n01.07.2026\n*1848\n+3 240,00 ₽\n+3 240,00 ₽\nПеревод между счетами одного\nклиента\n01.07.2026\nв 15:52\n01.07.2026\n–3 000,00 ₽\n–3 000,00 ₽\nОплата товаров и услуг\nPYATEROCHKA 6812\n29.06.2026\nв 08:01\n01.07.2026\n*1848\n–109,98 ₽\n–109,98 ₽\nОплата СБП QR\n(podorozhnik.spb.ru_SBP)\n01.07.2026\nв 16:19\n01.07.2026\n–130,00 ₽\n–130,00 ₽\nОплата товаров и услуг\nYANDEX*5411*LAVKA\n01.07.2026\nв 14:02\n01.07.2026\n*1848\n–178,00 ₽\n–178,00 ₽\nПеревод между счетами одного\nклиента\n02.07.2026\nв 10:06\n02.07.2026\n+1 000,00 ₽\n+1 000,00 ₽\nОпл.по Дог.26658326/25 599.94 руб\n02.07.2026\nв 10:37\n02.07.2026\n+599,94 ₽\n+599,94 ₽\nСтраница 11 из 15\nПродолжение на следующей странице\n\nОписание операции\nДата и время\nоперации\nМСК\nДата\nобработки\nМСК\nКарта\nСумма в валюте\nоперации\nСумма в валюте\nДоговора\nОплата СБП QR (RouterAI)\n02.07.2026\nв 12:14\n02.07.2026\n–100,00 ₽\n–100,00 ₽\nОплата товаров и услуг\nPYATEROCHKA 6812\n30.06.2026\nв 08:01\n02.07.2026\n*1848\n–169,97 ₽\n–169,97 ₽\nОплата товаров и услуг\nPYATEROCHKA 6812\n30.06.2026\nв 11:51\n02.07.2026\n*1848\n–109,98 ₽\n–109,98 ₽\nОплата товаров и услуг DIXY-\n78336D\n30.06.2026\nв 14:45\n02.07.2026\n*1848\n–178,67 ₽\n–178,67 ₽\nОплата товаров и услуг\nYANDEX*7999*BIKE\n30.06.2026\nв 08:34\n02.07.2026\n*1848\n–1,00 ₽\n–1,00 ₽\nОплата СБП QR (Озон)\n02.07.2026\nв 18:37\n02.07.2026\n–534,00 ₽\n–534,00 ₽\nОплата товаров и услуг B090\n01.07.2026\nв 10:04\n03.07.2026\n*1848\n–211,00 ₽\n–211,00 ₽\nОплата товаров и услуг\nUNIVERSAM VMESTE 24 CH\n01.07.2026\nв 19:22\n03.07.2026\n*1848\n–114,90 ₽\n–114,90 ₽\nОплата товаров и услуг\nUNIVERSAM VMESTE 24 CH\n01.07.2026\nв 21:21\n03.07.2026\n*1848\n–185,80 ₽\n–185,80 ₽\nОплата товаров и услуг\nYANDEX*7999*BIKE\n01.07.2026\nв 07:48\n03.07.2026\n*1848\n–1,00 ₽\n–1,00 ₽\nОплата СБП QR\n(podorozhnik.spb.ru_SBP)\n03.07.2026\nв 16:24\n03.07.2026\n–130,00 ₽\n–130,00 ₽\nОплата товаров и услуг DIXY-\n78336D\n01.07.2026\nв 17:21\n03.07.2026\n*1848\n–349,78 ₽\n–349,78 ₽\nПеревод между счетами одного\nклиента\n03.07.2026\nв 17:21\n03.07.2026\n+1 000,00 ₽\n+1 000,00 ₽\nОплата товаров и услуг\nPYATEROCHKA 22266\n02.07.2026\nв 10:26\n04.07.2026\n*1848\n–394,96 ₽\n–394,96 ₽\nОплата товаров и услуг B036\n03.07.2026\nв 08:28\n05.07.2026\n*1848\n–211,00 ₽\n–211,00 ₽\nОплата товаров и услуг\nYANDEX*7999*BIKE\n03.07.2026\nв 07:45\n05.07.2026\n*1848\n–1,00 ₽\n–1,00 ₽\nОплата товаров и услуг DIXY-\n78336D\n03.07.2026\nв 17:29\n05.07.2026\n*1848\n–451,55 ₽\n–451,55 ₽\nСтраница 12 из 15\nПродолжение на следующей странице\n\nОписание операции\nДата и время\nоперации\nМСК\nДата\nобработки\nМСК\nКарта\nСумма в валюте\nоперации\nСумма в валюте\nДоговора\nОплата товаров и услуг MAGNIT\nMM TIGIL\n03.07.2026\nв 12:40\n05.07.2026\n*1848\n–224,98 ₽\n–224,98 ₽\nОплата товаров и услуг\nPYATEROCHKA 6812\n04.07.2026\nв 07:59\n05.07.2026\n*1848\n–169,97 ₽\n–169,97 ₽\nОплата товаров и услуг\nPYATEROCHKA 6812\n04.07.2026\nв 12:36\n05.07.2026\n*1848\n–109,98 ₽\n–109,98 ₽\nОплата товаров и услуг\nPYATEROCHKA 6812\n04.07.2026\nв 11:57\n05.07.2026\n*1848\n–109,98 ₽\n–109,98 ₽\nОплата СБП QR (RouterAI)\n05.07.2026\nв 20:25\n05.07.2026\n–100,00 ₽\n–100,00 ₽\nОпл.по Дог.26658326/25 3467.94\nруб\n06.07.2026\nв 10:07\n06.07.2026\n+3 467,94 ₽\n+3 467,94 ₽\nПеревод между счетами одного\nклиента\n06.07.2026\nв 10:53\n06.07.2026\n–3 500,00 ₽\n–3 500,00 ₽\nОплата СБП QR (RouterAI)\n06.07.2026\nв 10:53\n06.07.2026\n–100,00 ₽\n–100,00 ₽\nОплата товаров и услуг\nYANDEX*7999*BIKE\n04.07.2026\nв 08:32\n06.07.2026\n*1848\n–1,00 ₽\n–1,00 ₽\nОплата товаров и услуг\nYANDEX*7999*BIKE\n05.07.2026\nв 08:07\n07.07.2026\n*1848\n–1,00 ₽\n–1,00 ₽\nПеревод между счетами одного\nклиента\n07.07.2026\nв 15:07\n07.07.2026\n+540,92 ₽\n+540,92 ₽\nОплата товаров и услуг\nYANDEX*7999*BIKE\n05.07.2026\nв 07:44\n07.07.2026\n*1848\n–1,00 ₽\n–1,00 ₽\nПеревод между счетами одного\nклиента\n07.07.2026\nв 17:16\n07.07.2026\n+1 000,00 ₽\n+1 000,00 ₽\nИсходящий перевод СБП, Валерий\nЕвгеньевич Б., +7 950 328-85-89,\nОзон Банк (Ozon)\n07.07.2026\nв 17:20\n07.07.2026\n–523,00 ₽\n–523,00 ₽\nОплата СБП QR (RouterAI)\n07.07.2026\nв 20:16\n07.07.2026\n–100,00 ₽\n–100,00 ₽\nПеревод между счетами одного\nклиента\n08.07.2026\nв 06:46\n08.07.2026\n+1 000,00 ₽\n+1 000,00 ₽\nСтраница 13 из 15\nПродолжение на следующей странице\n\nОписание операции\nДата и время\nоперации\nМСК\nДата\nобработки\nМСК\nКарта\nСумма в валюте\nоперации\nСумма в валюте\nДоговора\nОплата СБП QR (ТОО "ОнлиПэй")\n08.07.2026\nв 06:47\n08.07.2026\n–939,40 ₽\n–939,40 ₽\nПеревод между счетами одного\nклиента\n08.07.2026\nв 09:22\n08.07.2026\n+11 000,00 ₽\n+11 000,00 ₽\nОпл.по Дог.ОФ-26561424 8174.23\nруб\n08.07.2026\nв 10:39\n08.07.2026\n+8 174,23 ₽\n+8 174,23 ₽\nОпл.по Дог.26658326/25 669.24 руб\n08.07.2026\nв 10:39\n08.07.2026\n+669,24 ₽\n+669,24 ₽\nИсходящий перевод СБП, Надежда\nПетровна П., +7 911 269-21-08,\nАльфа-Банк\n08.07.2026\nв 12:33\n08.07.2026\n–10 000,00 ₽\n–10 000,00 ₽\nИсходящий перевод СБП,\nАлександр Викторович П., +7 911\n263-29-95, Альфа-Банк\n08.07.2026\nв 12:35\n08.07.2026\n–10 000,00 ₽\n–10 000,00 ₽\nОпл.по Дог.26658326/25 836.33 руб\n09.07.2026\nв 10:39\n09.07.2026\n+836,33 ₽\n+836,33 ₽\nОплата товаров и услуг\nYANDEX*5411*LAVKA\n09.07.2026\nв 08:00\n09.07.2026\n*1848\n–94,00 ₽\n–94,00 ₽\nОплата товаров и услуг\nYANDEX*5411*LAVKA\n09.07.2026\nв 15:32\n09.07.2026\n*1848\n–110,00 ₽\n–110,00 ₽\nОплата СБП QR\n(podorozhnik.spb.ru_SBP)\n09.07.2026\nв 15:52\n09.07.2026\n–130,00 ₽\n–130,00 ₽\nОплата товаров и услуг\nYANDEX*7999*BIKE\n07.07.2026\nв 08:57\n09.07.2026\n*1848\n–1,00 ₽\n–1,00 ₽\nОплата товаров и услуг DIXY-\n78336D\n07.07.2026\nв 15:07\n09.07.2026\n*1848\n–291,88 ₽\n–291,88 ₽\nВходящий перевод СБП, Илья\nАлексеевич Л., +7 992 028-51-42,\nАльфа-Банк\n09.07.2026\nв 21:07\n09.07.2026\n+2 000,00 ₽\n+2 000,00 ₽\nОплата СБП QR (RouterAI)\n09.07.2026\nв 21:16\n09.07.2026\n–100,00 ₽\n–100,00 ₽\nОпл.по Дог.26658326/25 775.70 руб\n10.07.2026\nв 11:09\n10.07.2026\n+775,70 ₽\n+775,70 ₽\nОплата товаров и услуг DIXY-\n78336D\n08.07.2026\nв 14:40\n10.07.2026\n*1848\n–356,78 ₽\n–356,78 ₽\nСтраница 14 из 15\nПродолжение на следующей странице\n\nОписание операции\nДата и время\nоперации\nМСК\nДата\nобработки\nМСК\nКарта\nСумма в валюте\nоперации\nСумма в валюте\nДоговора\nОплата СБП QR\n(podorozhnik.spb.ru_SBP)\n10.07.2026\nв 14:59\n10.07.2026\n–130,00 ₽\n–130,00 ₽\nОплата товаров и услуг\nYANDEX*7999*BIKE\n08.07.2026\nв 08:07\n10.07.2026\n*1848\n–1,00 ₽\n–1,00 ₽\nОплата товаров и услуг DIXY-\n78336D\n08.07.2026\nв 14:41\n10.07.2026\n*1848\n–39,98 ₽\n–39,98 ₽\nОплата товаров и услуг\nUNIVERSAM VMESTE 24 CH\n08.07.2026\nв 20:08\n10.07.2026\n*1848\n–159,90 ₽\n–159,90 ₽\nОплата СБП QR (Sota Connect)\n10.07.2026\nв 17:18\n10.07.2026\n–349,00 ₽\n–349,00 ₽\nОплата СБП QR (OZON)\n10.07.2026\nв 18:38\n10.07.2026\n–83,00 ₽\n–83,00 ₽\nОплата СБП QR (RouterAI)\n10.07.2026\nв 20:57\n10.07.2026\n–100,00 ₽\n–100,00 ₽\nОплата СБП QR (RouterAI)\n10.07.2026\nв 22:51\n10.07.2026\n–100,00 ₽\n–100,00 ₽\nИсходящий остаток за 10.07.2026\n2 540,89 ₽\n+108 372,62 ₽\n–107 318,80 ₽\nВсего расходных операций\nВсего приходных операций\nСтраница 15 из 15\n	completed	2026-08-03 12:49:44.965921+00
9	4	Выписка по договору от 11 июля 2026.pdf	АО «Яндекс Банк»	2026-06-10	2026-07-10	115908.08	101516.20999999999	{"Доход (оплата по договору)": {"description": "Поступления по договорам", "income": 18980.74, "expense": 0.0, "count": 2}, "Переводы между счетами": {"description": "Переводы между собственными счетами", "income": 3000.0, "expense": 0.0, "count": 1}, "Переводы (исходящие)": {"description": "Исходящие переводы другим лицам", "income": 0.0, "expense": 10470.0, "count": 6}, "Развлечения": {"description": "Оплата развлекательных услуг", "income": 0.0, "expense": 6139.0, "count": 19}, "Продукты": {"description": "Покупка продуктов питания", "income": 0.0, "expense": 11814.759999999998, "count": 54}, "Транспорт": {"description": "Оплата транспортных услуг", "income": 0.0, "expense": 2227.0, "count": 30}, "Прочее": {"description": "Прочие расходы, не подпадающие под другие категории", "income": 0.0, "expense": 32355.45, "count": 42}, "Переводы": {"description": "Входящие и исходящие переводы между счетами и пользователями", "income": 17479.92, "expense": 53974.0, "count": 31}, "Доход (оплата по договорам)": {"description": "Поступления по договорам", "income": 46487.55, "expense": 0.0, "count": 14}, "Доход (прочее)": {"description": "Прочие поступления денежных средств", "income": 14199.95, "expense": 0.0, "count": 3}, "Доход (переводы)": {"description": "Входящие переводы на счет", "income": 5320.0, "expense": 0.0, "count": 3}}	В течение отчетного периода наблюдается значительный объем расходов на переводы, как между своими счетами, так и исходящие. Основные траты приходятся на продукты питания и прочие расходы, включая оплату услуг. Рекомендуется проанализировать необходимость столь частых переводов и оптимизировать расходы на продукты. За период наблюдается значительный объем расходов на переводы и оплату товаров/услуг, в частности, на продукты и транспорт. Доходы представлены в основном поступлениями по договорам. Рекомендуется более детально проанализировать структуру расходов на переводы и рассмотреть возможности оптимизации трат на повседневные нужды, такие как продукты и транспорт. За период наблюдается значительное количество трат на продукты питания и развлечения, что может указывать на возможность оптимизации расходов. Стоит рассмотреть более детальный анализ трат на развлечения и поиск более бюджетных альтернатив. Общий баланс доходов и расходов положительный, но стоит следить за регулярностью поступлений и их соответствием тратам. За период наблюдается значительный объем поступлений по договорам и переводов, что свидетельствует о наличии активной финансовой деятельности. Основные расходы приходятся на продукты питания и переводы между счетами, что может указывать на необходимость более детального планирования бюджета для оптимизации трат. Рекомендуется проанализировать структуру расходов на продукты и рассмотреть возможности сокращения трат на переводы, если они не являются критически важными. В данном периоде наблюдается значительный объем операций по оплате товаров и услуг, в основном в продуктовых магазинах и сервисах доставки. Также присутствуют крупные переводы, как исходящие, так и входящие, что может указывать на личные или инвестиционные операции. Рекомендуется более детально проанализировать природу крупных переводов и платежей по договорам для лучшего контроля над финансовыми потоками.	Выписка по договору\nИсх. № 202607113533059\nДата 11.07.2026\nАО «Яндекс Банк», лицензия Банка России № 3027 (далее — «Банк»),\nсообщает, что между Вами и Банком заключён договор\n№ В20251211309616072 от 11.12.2025 в рамках продукта\n«Банковский счёт Про» (далее — «Договор»).\nБастригин Валерий Евгеньевич\nДата рождения 16.07.2000\nПаспорт РФ № 9220 822033\nВ рамках Договора открыт счёт\n40817810020001016225\nНомер счёта\nВыписка по Договору за период с 10.06.2026 по 10.07.2026\nОписание операции\nДата и время\nоперации\nМСК\nДата\nобработки\nМСК\nКарта\nСумма в валюте\nоперации\nСумма в валюте\nДоговора\nОпл.по Дог.ОФ-26561424 17693.96\nруб\n10.06.2026\nв 09:34\n10.06.2026\n+17 693,96 ₽\n+17 693,96 ₽\nОпл.по Дог.26658326/25 1286.78\nруб\n10.06.2026\nв 09:35\n10.06.2026\n+1 286,78 ₽\n+1 286,78 ₽\nПеревод между счетами одного\nклиента\n10.06.2026\nв 10:31\n10.06.2026\n–3 412,00 ₽\n–3 412,00 ₽\nИсходящий перевод СБП, Валерий\nЕвгеньевич Б., +7 950 328-85-89, Т-\nБанк\n10.06.2026\nв 10:33\n10.06.2026\n–2 200,00 ₽\n–2 200,00 ₽\nИсходящий перевод СБП, Валерий\nЕвгеньевич Б., +7 950 328-85-89, Т-\nБанк\n10.06.2026\nв 10:33\n10.06.2026\n–3 000,00 ₽\n–3 000,00 ₽\nИсходящий перевод СБП, Надежда\nПетровна П., +7 911 269-21-08, ВТБ\n10.06.2026\nв 10:35\n10.06.2026\n–3 000,00 ₽\n–3 000,00 ₽\nПеревод между счетами одного\nклиента\n10.06.2026\nв 10:37\n10.06.2026\n–3 000,00 ₽\n–3 000,00 ₽\nОплата СБП QR (Додо Пицца,\nШушары-1)\n10.06.2026\nв 12:18\n10.06.2026\n–1 030,00 ₽\n–1 030,00 ₽\nОплата товаров и услуг DIXY-\n78336D\n08.06.2026\nв 14:32\n10.06.2026\n*1848\n–339,78 ₽\n–339,78 ₽\nВходящий остаток на 10.06.2026\n1 487,07 ₽\nСтраница 1 из 15\nПродолжение на следующей странице\n\nОписание операции\nДата и время\nоперации\nМСК\nДата\nобработки\nМСК\nКарта\nСумма в валюте\nоперации\nСумма в валюте\nДоговора\nОплата СБП QR (OZON)\n10.06.2026\nв 14:54\n10.06.2026\n–531,00 ₽\n–531,00 ₽\nОплата товаров и услуг DIXY-\n78336D\n08.06.2026\nв 20:48\n10.06.2026\n*1848\n–103,79 ₽\n–103,79 ₽\nОплата товаров и услуг\nPYATEROCHKA 7149\n08.06.2026\nв 08:05\n10.06.2026\n*1848\n–119,98 ₽\n–119,98 ₽\nОплата товаров и услуг\nYANDEX*7999*BIKE\n08.06.2026\nв 07:36\n10.06.2026\n*1848\n–1,00 ₽\n–1,00 ₽\nОплата СБП QR (Sota Connect)\n10.06.2026\nв 17:18\n10.06.2026\n–349,00 ₽\n–349,00 ₽\nОплата товаров и услуг\nPYATEROCHKA 7149\n08.06.2026\nв 11:56\n10.06.2026\n*1848\n–194,07 ₽\n–194,07 ₽\nОплата товаров и услуг\nYANDEX*5815*PLUS\n10.06.2026\nв 23:44\n11.06.2026\n*1848\n–449,00 ₽\n–449,00 ₽\nПеревод между счетами одного\nклиента\n11.06.2026\nв 14:53\n11.06.2026\n+1 000,00 ₽\n+1 000,00 ₽\nОплата СБП QR (ТОО "ОнлиПэй")\n11.06.2026\nв 15:02\n11.06.2026\n–109,89 ₽\n–109,89 ₽\nОплата товаров и услуг DIXY-\n78336D\n09.06.2026\nв 14:26\n11.06.2026\n*1848\n–513,32 ₽\n–513,32 ₽\nОплата товаров и услуг\nYANDEX*7999*BIKE\n09.06.2026\nв 08:16\n11.06.2026\n*1848\n–1,00 ₽\n–1,00 ₽\nОплата товаров и услуг\nPYATEROCHKA 6\n09.06.2026\nв 07:24\n11.06.2026\n*1848\n–59,98 ₽\n–59,98 ₽\nОплата товаров и услуг\nPYATEROCHKA 6\n09.06.2026\nв 10:34\n11.06.2026\n*1848\n–136,98 ₽\n–136,98 ₽\nОплата СБП QR (ТОО "ОнлиПэй")\n11.06.2026\nв 19:20\n11.06.2026\n–109,89 ₽\n–109,89 ₽\nОплата СБП QR\n(podorozhnik.spb.ru_SBP)\n12.06.2026\nв 06:53\n12.06.2026\n–130,00 ₽\n–130,00 ₽\nИсходящий перевод СБП, Эмилия\nРатхановна К., +7 952 242-16-98,\nСбербанк\n12.06.2026\nв 07:08\n12.06.2026\n–70,00 ₽\n–70,00 ₽\nСтраница 2 из 15\nПродолжение на следующей странице\n\nОписание операции\nДата и время\nоперации\nМСК\nДата\nобработки\nМСК\nКарта\nСумма в валюте\nоперации\nСумма в валюте\nДоговора\nПеревод между счетами одного\nклиента\n12.06.2026\nв 16:01\n12.06.2026\n+2 000,00 ₽\n+2 000,00 ₽\nВнутрибанковский перевод на +7\n996 903-73-17, Алина К.\n12.06.2026\nв 16:02\n12.06.2026\n–1 000,00 ₽\n–1 000,00 ₽\nОплата товаров и услуг DIXY-\n78336D\n10.06.2026\nв 12:31\n12.06.2026\n*1848\n–756,58 ₽\n–756,58 ₽\nОплата товаров и услуг APTEKA 78-\n2020\n10.06.2026\nв 15:03\n12.06.2026\n*1848\n–220,00 ₽\n–220,00 ₽\nОплата товаров и услуг\nPYATEROCHKA 6\n11.06.2026\nв 10:44\n12.06.2026\n*1848\n–189,97 ₽\n–189,97 ₽\nОплата СБП QR\n(podorozhnik.spb.ru_SBP)\n13.06.2026\nв 07:03\n13.06.2026\n–130,00 ₽\n–130,00 ₽\nОплата товаров и услуг\nYANDEX*7999*BIKE\n11.06.2026\nв 08:14\n13.06.2026\n*1848\n–1,00 ₽\n–1,00 ₽\nОплата товаров и услуг\nSBER*5411*SAMOKAT\n11.06.2026\nв 20:11\n13.06.2026\n*1848\n–463,00 ₽\n–463,00 ₽\nОплата товаров и услуг DIXY-\n78336D\n11.06.2026\nв 12:12\n13.06.2026\n*1848\n–148,98 ₽\n–148,98 ₽\nОплата товаров и услуг\nPYATEROCHKA 6\n11.06.2026\nв 11:18\n13.06.2026\n*1848\n–199,98 ₽\n–199,98 ₽\nОплата товаров и услуг\nPYATEROCHKA 6\n11.06.2026\nв 07:16\n13.06.2026\n*1848\n–59,98 ₽\n–59,98 ₽\nОплата СБП QR\n(podorozhnik.spb.ru_SBP)\n14.06.2026\nв 07:03\n14.06.2026\n–130,00 ₽\n–130,00 ₽\nОплата товаров и услуг MAGNIT\nMM ANDROMAKHA\n12.06.2026\nв 08:00\n14.06.2026\n*1848\n–114,98 ₽\n–114,98 ₽\nОплата товаров и услуг MAGNIT\nMM ANDROMAKHA\n12.06.2026\nв 14:00\n14.06.2026\n*1848\n–99,98 ₽\n–99,98 ₽\nОплата товаров и услуг\nYANDEX*7999*BIKE\n12.06.2026\nв 12:38\n14.06.2026\n*1848\n–1,00 ₽\n–1,00 ₽\nОплата товаров и услуг DIXY-\n78336D\n12.06.2026\nв 18:08\n14.06.2026\n*1848\n–258,91 ₽\n–258,91 ₽\nСтраница 3 из 15\nПродолжение на следующей странице\n\nОписание операции\nДата и время\nоперации\nМСК\nДата\nобработки\nМСК\nКарта\nСумма в валюте\nоперации\nСумма в валюте\nДоговора\nОплата товаров и услуг\nYANDEX*7999*BIKE\n12.06.2026\nв 08:34\n14.06.2026\n*1848\n–1,00 ₽\n–1,00 ₽\nОплата товаров и услуг\nPYATEROCHKA 6812\n12.06.2026\nв 10:54\n14.06.2026\n*1848\n–89,98 ₽\n–89,98 ₽\nОпл.по Дог.26658326/25 4176.52\nруб\n15.06.2026\nв 11:08\n15.06.2026\n+4 176,52 ₽\n+4 176,52 ₽\nОплата СБП QR (FUNPAY)\n15.06.2026\nв 12:23\n15.06.2026\n–683,76 ₽\n–683,76 ₽\nОплата товаров и услуг DIXY-\n78336D\n13.06.2026\nв 16:00\n15.06.2026\n*1848\n–300,86 ₽\n–300,86 ₽\nОплата товаров и услуг MAGNIT\nMM ANDROMAKHA\n13.06.2026\nв 08:00\n15.06.2026\n*1848\n–96,98 ₽\n–96,98 ₽\nОплата товаров и услуг\nYANDEX*7999*BIKE\n13.06.2026\nв 08:29\n15.06.2026\n*1848\n–1,00 ₽\n–1,00 ₽\nОплата товаров и услуг\nPYATEROCHKA 6812\n13.06.2026\nв 13:00\n15.06.2026\n*1848\n–69,99 ₽\n–69,99 ₽\nВнутрибанковский перевод на +7\n996 903-73-17, Алина К.\n15.06.2026\nв 16:47\n15.06.2026\n–2 000,00 ₽\n–2 000,00 ₽\nОплата товаров и услуг\nYANDEX*7999*BIKE\n14.06.2026\nв 07:41\n16.06.2026\n*1848\n–1,00 ₽\n–1,00 ₽\nОплата товаров и услуг MAGNIT\nMM ANDROMAKHA\n14.06.2026\nв 08:03\n16.06.2026\n*1848\n–104,98 ₽\n–104,98 ₽\nОплата товаров и услуг\nYANDEX*5411*LAVKA\n16.06.2026\nв 17:43\n16.06.2026\n*1848\n–337,00 ₽\n–337,00 ₽\nОпл.по Дог.ОФ-26561424 10126.57\nруб\n17.06.2026\nв 11:06\n17.06.2026\n+10 126,57 ₽\n+10 126,57 ₽\nВнутрибанковский перевод на +7\n996 903-73-17, Алина К.\n17.06.2026\nв 11:24\n17.06.2026\n–2 000,00 ₽\n–2 000,00 ₽\nОплата товаров и услуг DIXY-\n78336D\n15.06.2026\nв 11:39\n17.06.2026\n*1848\n–229,95 ₽\n–229,95 ₽\nОплата товаров и услуг\nSBER*5411*SAMOKAT\n15.06.2026\nв 19:44\n17.06.2026\n*1848\n–444,00 ₽\n–444,00 ₽\nСтраница 4 из 15\nПродолжение на следующей странице\n\nОписание операции\nДата и время\nоперации\nМСК\nДата\nобработки\nМСК\nКарта\nСумма в валюте\nоперации\nСумма в валюте\nДоговора\nИсходящий перевод СБП, Валерий\nЕвгеньевич Б., +7 950 328-85-89, Т-\nБанк\n17.06.2026\nв 17:50\n17.06.2026\n–5 000,00 ₽\n–5 000,00 ₽\nОплата товаров и услуг\nSBER*5411*SAMOKAT\n15.06.2026\nв 19:16\n17.06.2026\n*1848\n–472,00 ₽\n–472,00 ₽\nОпл.по Дог.26658326/25 673.06 руб\n18.06.2026\nв 10:36\n18.06.2026\n+673,06 ₽\n+673,06 ₽\nВходящий перевод по номеру\nкарты (Tribute)\n18.06.2026\nв 13:00\n18.06.2026\n*1848\n+4 860,00 ₽\n+4 860,00 ₽\nПеревод между счетами одного\nклиента\n18.06.2026\nв 15:00\n18.06.2026\n–5 000,00 ₽\n–5 000,00 ₽\nОплата СБП QR (Озон)\n18.06.2026\nв 16:34\n18.06.2026\n–629,00 ₽\n–629,00 ₽\nОплата СБП QR (OZON)\n18.06.2026\nв 18:14\n18.06.2026\n–509,00 ₽\n–509,00 ₽\nОплата СБП QR\n(podorozhnik.spb.ru_SBP)\n19.06.2026\nв 07:03\n19.06.2026\n–130,00 ₽\n–130,00 ₽\nВходящий перевод СБП, Тимур\nРафкатович Г., +7 991 002-59-41,\nОзон Банк (Ozon)\n19.06.2026\nв 11:51\n19.06.2026\n+1 579,00 ₽\n+1 579,00 ₽\nВходящий перевод СБП, Алина\nАлександровна К., +7 996 903-73-17,\nТ-Банк\n19.06.2026\nв 12:31\n19.06.2026\n+5 000,00 ₽\n+5 000,00 ₽\nОплата СБП QR (Озон)\n19.06.2026\nв 17:25\n19.06.2026\n–520,00 ₽\n–520,00 ₽\nОплата товаров и услуг\nSBER*5411*SAMOKAT\n17.06.2026\nв 20:03\n19.06.2026\n*1848\n–450,00 ₽\n–450,00 ₽\nОплата товаров и услуг DIXY-\n78336D\n17.06.2026\nв 13:12\n19.06.2026\n*1848\n–659,58 ₽\n–659,58 ₽\nОплата товаров и услуг MAGNIT\nMM ANDROMAKHA\n17.06.2026\nв 08:02\n19.06.2026\n*1848\n–104,98 ₽\n–104,98 ₽\nОплата товаров и услуг\nYANDEX*7999*BIKE\n17.06.2026\nв 08:34\n19.06.2026\n*1848\n–1,00 ₽\n–1,00 ₽\nОплата СБП QR\n(podorozhnik.spb.ru_SBP)\n20.06.2026\nв 07:03\n20.06.2026\n–130,00 ₽\n–130,00 ₽\nСтраница 5 из 15\nПродолжение на следующей странице\n\nОписание операции\nДата и время\nоперации\nМСК\nДата\nобработки\nМСК\nКарта\nСумма в валюте\nоперации\nСумма в валюте\nДоговора\nОплата товаров и услуг DIXY-\n78336D\n18.06.2026\nв 11:09\n20.06.2026\n*1848\n–279,95 ₽\n–279,95 ₽\nОплата СБП QR\n(podorozhnik.spb.ru_SBP)\n21.06.2026\nв 07:05\n21.06.2026\n–130,00 ₽\n–130,00 ₽\nОплата товаров и услуг DIXY-\n78336D\n19.06.2026\nв 14:04\n21.06.2026\n*1848\n–269,88 ₽\n–269,88 ₽\nИсходящий перевод СБП, Валерий\nЕвгеньевич Б., +7 950 328-85-89,\nОзон Банк (Ozon)\n21.06.2026\nв 16:11\n21.06.2026\n–1 460,00 ₽\n–1 460,00 ₽\nОплата СБП QR\n(podorozhnik.spb.ru_SBP)\n21.06.2026\nв 16:21\n21.06.2026\n–130,00 ₽\n–130,00 ₽\nОплата товаров и услуг\nYANDEX*7999*BIKE\n19.06.2026\nв 08:47\n21.06.2026\n*1848\n–1,00 ₽\n–1,00 ₽\nОплата товаров и услуг AU3402\n19.06.2026\nв 11:04\n21.06.2026\n*1848\n–220,00 ₽\n–220,00 ₽\nОплата товаров и услуг MAGNIT\nMM ANDROMAKHA\n19.06.2026\nв 08:04\n21.06.2026\n*1848\n–169,98 ₽\n–169,98 ₽\nОплата товаров и услуг\nPYATEROCHKA 6812\n19.06.2026\nв 12:22\n21.06.2026\n*1848\n–69,99 ₽\n–69,99 ₽\nОплата товаров и услуг\nSBER*5411*SAMOKAT\n19.06.2026\nв 20:46\n21.06.2026\n*1848\n–499,00 ₽\n–499,00 ₽\nОпл.по Дог.26658326/25 3594.49\nруб\n22.06.2026\nв 10:40\n22.06.2026\n+3 594,49 ₽\n+3 594,49 ₽\nОплата СБП QR\n(podorozhnik.spb.ru_SBP)\n22.06.2026\nв 12:21\n22.06.2026\n–130,00 ₽\n–130,00 ₽\nИсходящий перевод СБП, Надежда\nПетровна П., +7 911 269-21-08, ВТБ\n22.06.2026\nв 13:45\n22.06.2026\n–3 851,00 ₽\n–3 851,00 ₽\nОплата товаров и услуг\nPYATEROCHKA 6812\n20.06.2026\nв 08:07\n22.06.2026\n*1848\n–119,98 ₽\n–119,98 ₽\nОплата товаров и услуг\nSBER*5411*SAMOKAT\n20.06.2026\nв 20:54\n22.06.2026\n*1848\n–542,00 ₽\n–542,00 ₽\nОплата товаров и услуг\nPYATEROCHKA 6812\n20.06.2026\nв 13:59\n22.06.2026\n*1848\n–115,98 ₽\n–115,98 ₽\nСтраница 6 из 15\nПродолжение на следующей странице\n\nОписание операции\nДата и время\nоперации\nМСК\nДата\nобработки\nМСК\nКарта\nСумма в валюте\nоперации\nСумма в валюте\nДоговора\nОплата товаров и услуг AU3402\n20.06.2026\nв 15:13\n22.06.2026\n*1848\n–350,00 ₽\n–350,00 ₽\nОплата товаров и услуг\nYANDEX*7999*BIKE\n20.06.2026\nв 08:58\n22.06.2026\n*1848\n–1,00 ₽\n–1,00 ₽\nОплата товаров и услуг\nPYATEROCHKA 6812\n20.06.2026\nв 11:07\n22.06.2026\n*1848\n–119,98 ₽\n–119,98 ₽\nОплата товаров и услуг\nUNIVERSAM VMESTE 24 CH\n20.06.2026\nв 17:30\n22.06.2026\n*1848\n–171,33 ₽\n–171,33 ₽\nОплата СБП QR (Озон)\n22.06.2026\nв 19:32\n22.06.2026\n–519,00 ₽\n–519,00 ₽\nПеревод между счетами одного\nклиента\n23.06.2026\nв 12:11\n23.06.2026\n+500,00 ₽\n+500,00 ₽\nОпл.по Дог.26658326/25 877.31 руб\n23.06.2026\nв 12:37\n23.06.2026\n+877,31 ₽\n+877,31 ₽\nПеревод между счетами одного\nклиента\n23.06.2026\nв 13:30\n23.06.2026\n–600,00 ₽\n–600,00 ₽\nОплата товаров и услуг\nPYATEROCHKA 6812\n21.06.2026\nв 13:20\n23.06.2026\n*1848\n–109,98 ₽\n–109,98 ₽\nОплата товаров и услуг MAGNIT\nMM ANDROMAKHA\n21.06.2026\nв 08:02\n23.06.2026\n*1848\n–109,98 ₽\n–109,98 ₽\nОплата товаров и услуг\nPYATEROCHKA 6812\n21.06.2026\nв 10:31\n23.06.2026\n*1848\n–119,98 ₽\n–119,98 ₽\nОплата СБП QR\n(podorozhnik.spb.ru_SBP)\n23.06.2026\nв 17:26\n23.06.2026\n–130,00 ₽\n–130,00 ₽\nОплата товаров и услуг DIXY-\n78336D\n21.06.2026\nв 16:58\n23.06.2026\n*1848\n–346,47 ₽\n–346,47 ₽\nОплата СБП QR (Дикси 78336)\n23.06.2026\nв 18:05\n23.06.2026\n–279,88 ₽\n–279,88 ₽\nОплата товаров и услуг\nYANDEX*7999*BIKE\n21.06.2026\nв 07:45\n23.06.2026\n*1848\n–1,00 ₽\n–1,00 ₽\nПеревод между счетами одного\nклиента\n23.06.2026\nв 19:00\n23.06.2026\n+600,00 ₽\n+600,00 ₽\nОплата СБП QR (Озон)\n23.06.2026\nв 19:00\n23.06.2026\n–737,00 ₽\n–737,00 ₽\nСтраница 7 из 15\nПродолжение на следующей странице\n\nОписание операции\nДата и время\nоперации\nМСК\nДата\nобработки\nМСК\nКарта\nСумма в валюте\nоперации\nСумма в валюте\nДоговора\nОпл.по Дог.ОФ-26561424 5995.65\nруб\n24.06.2026\nв 09:37\n24.06.2026\n+5 995,65 ₽\n+5 995,65 ₽\nОпл.по Дог.26658326/25 1290.39\nруб\n24.06.2026\nв 09:37\n24.06.2026\n+1 290,39 ₽\n+1 290,39 ₽\nПеревод между счетами одного\nклиента\n24.06.2026\nв 11:30\n24.06.2026\n–1 500,00 ₽\n–1 500,00 ₽\nОплата товаров и услуг DIXY-\n78336D\n22.06.2026\nв 12:59\n24.06.2026\n*1848\n–59,99 ₽\n–59,99 ₽\nОплата товаров и услуг\nYANDEX*7999*BIKE\n22.06.2026\nв 07:43\n24.06.2026\n*1848\n–1,00 ₽\n–1,00 ₽\nОплата товаров и услуг MAGNIT\nMM ANDROMAKHA\n22.06.2026\nв 08:04\n24.06.2026\n*1848\n–169,97 ₽\n–169,97 ₽\nОплата товаров и услуг DIXY-\n78336D\n22.06.2026\nв 12:58\n24.06.2026\n*1848\n–359,86 ₽\n–359,86 ₽\nОплата СБП QR (Озон)\n24.06.2026\nв 17:36\n24.06.2026\n–554,00 ₽\n–554,00 ₽\nОплата СБП QR (t2_SBP)\n24.06.2026\nв 20:59\n24.06.2026\n–650,00 ₽\n–650,00 ₽\nОплата СБП QR (t2)\n25.06.2026\nв 10:36\n25.06.2026\n–100,00 ₽\n–100,00 ₽\nОпл.по Дог.26658326/25 37.00 руб\n25.06.2026\nв 11:07\n25.06.2026\n+37,00 ₽\n+37,00 ₽\nОплата СБП QR (OZON)\n25.06.2026\nв 16:53\n25.06.2026\n–520,00 ₽\n–520,00 ₽\nОплата товаров и услуг\nPYATEROCHKA 6812\n23.06.2026\nв 08:01\n25.06.2026\n*1848\n–189,97 ₽\n–189,97 ₽\nОплата товаров и услуг\nYANDEX*7999*BIKE\n23.06.2026\nв 09:29\n25.06.2026\n*1848\n–1,00 ₽\n–1,00 ₽\nОплата товаров и услуг\nPYATEROCHKA 6812\n23.06.2026\nв 12:12\n25.06.2026\n*1848\n–59,99 ₽\n–59,99 ₽\nОплата товаров и услуг\nPYATEROCHKA 6812\n23.06.2026\nв 12:12\n25.06.2026\n*1848\n–95,98 ₽\n–95,98 ₽\nОплата СБП QR (FUNPAY)\n25.06.2026\nв 20:30\n25.06.2026\n–291,60 ₽\n–291,60 ₽\nСтраница 8 из 15\nПродолжение на следующей странице\n\nОписание операции\nДата и время\nоперации\nМСК\nДата\nобработки\nМСК\nКарта\nСумма в валюте\nоперации\nСумма в валюте\nДоговора\nОплата СБП QR (Озон)\n25.06.2026\nв 21:31\n25.06.2026\n–609,00 ₽\n–609,00 ₽\nОплата товаров и услуг DIXY-\n78336D\n24.06.2026\nв 11:51\n26.06.2026\n*1848\n–19,99 ₽\n–19,99 ₽\nОплата товаров и услуг DIXY-\n78336D\n24.06.2026\nв 11:50\n26.06.2026\n*1848\n–479,82 ₽\n–479,82 ₽\nОплата товаров и услуг\nPYATEROCHKA 22266\n25.06.2026\nв 10:46\n27.06.2026\n*1848\n–124,98 ₽\n–124,98 ₽\nОплата товаров и услуг DIXY-\n78336D\n25.06.2026\nв 10:53\n27.06.2026\n*1848\n–119,90 ₽\n–119,90 ₽\nОплата товаров и услуг DIXY-\n78336D\n25.06.2026\nв 10:52\n27.06.2026\n*1848\n–289,87 ₽\n–289,87 ₽\nОплата товаров и услуг\nSBER*5411*SAMOKAT\n25.06.2026\nв 17:48\n27.06.2026\n*1848\n–536,00 ₽\n–536,00 ₽\nОплата СБП QR\n(podorozhnik.spb.ru_SBP)\n27.06.2026\nв 16:15\n27.06.2026\n–130,00 ₽\n–130,00 ₽\nПеревод между счетами одного\nклиента\n27.06.2026\nв 18:07\n27.06.2026\n+1 000,00 ₽\n+1 000,00 ₽\nОплата СБП QR (Озон)\n27.06.2026\nв 18:08\n27.06.2026\n–554,00 ₽\n–554,00 ₽\nОплата СБП QR\n(podorozhnik.spb.ru_SBP)\n28.06.2026\nв 12:09\n28.06.2026\n–130,00 ₽\n–130,00 ₽\nПеревод между счетами одного\nклиента\n28.06.2026\nв 12:49\n28.06.2026\n+1 000,00 ₽\n+1 000,00 ₽\nОплата СБП QR (ООО "ИНТЕР")\n28.06.2026\nв 14:33\n28.06.2026\n–200,00 ₽\n–200,00 ₽\nОплата товаров и услуг\nSBER*5411*SAMOKAT\n26.06.2026\nв 16:34\n28.06.2026\n*1848\n–476,00 ₽\n–476,00 ₽\nОплата СБП QR (Озон)\n28.06.2026\nв 15:38\n28.06.2026\n–534,00 ₽\n–534,00 ₽\nОплата товаров и услуг\nPYATEROCHKA 22266\n26.06.2026\nв 12:18\n28.06.2026\n*1848\n–245,96 ₽\n–245,96 ₽\nПеревод между счетами одного\nклиента\n28.06.2026\nв 16:32\n28.06.2026\n+1 000,00 ₽\n+1 000,00 ₽\nСтраница 9 из 15\nПродолжение на следующей странице\n\nОписание операции\nДата и время\nоперации\nМСК\nДата\nобработки\nМСК\nКарта\nСумма в валюте\nоперации\nСумма в валюте\nДоговора\nОплата товаров и услуг IP\nMITCHENKO D.YU.\n27.06.2026\nв 11:05\n28.06.2026\n*1848\n–290,00 ₽\n–290,00 ₽\nОпл.по Дог.26658326/25 1203.84\nруб\n29.06.2026\nв 10:46\n29.06.2026\n+1 203,84 ₽\n+1 203,84 ₽\nОплата СБП QR\n(podorozhnik.spb.ru_SBP)\n29.06.2026\nв 12:18\n29.06.2026\n–130,00 ₽\n–130,00 ₽\nОплата товаров и услуг\nKRASNOE&BELOE\n27.06.2026\nв 11:06\n29.06.2026\n*1848\n–59,99 ₽\n–59,99 ₽\nОплата товаров и услуг\nPYATEROCHKA 6812\n27.06.2026\nв 08:00\n29.06.2026\n*1848\n–109,98 ₽\n–109,98 ₽\nОплата товаров и услуг\nPYATEROCHKA 6812\n27.06.2026\nв 13:08\n29.06.2026\n*1848\n–189,97 ₽\n–189,97 ₽\nОплата товаров и услуг\nYANDEX*7999*BIKE\n27.06.2026\nв 08:58\n29.06.2026\n*1848\n–1,00 ₽\n–1,00 ₽\nОплата СБП QR (ООО "ИНТЕР")\n29.06.2026\nв 17:13\n29.06.2026\n–100,00 ₽\n–100,00 ₽\nОплата СБП QR (Озон)\n29.06.2026\nв 18:00\n29.06.2026\n–531,00 ₽\n–531,00 ₽\nОпл.по Дог.26658326/25 574.29 руб\n30.06.2026\nв 11:12\n30.06.2026\n+574,29 ₽\n+574,29 ₽\nОплата СБП QR\n(podorozhnik.spb.ru_SBP)\n30.06.2026\nв 14:12\n30.06.2026\n–130,00 ₽\n–130,00 ₽\nОплата СБП QR (ООО "ИНТЕР")\n30.06.2026\nв 15:18\n30.06.2026\n–100,00 ₽\n–100,00 ₽\nОплата товаров и услуг\nPYATEROCHKA 22266\n28.06.2026\nв 12:50\n30.06.2026\n*1848\n–222,77 ₽\n–222,77 ₽\nОплата СБП QR (ООО "ИНТЕР")\n30.06.2026\nв 16:30\n30.06.2026\n–100,00 ₽\n–100,00 ₽\nОплата товаров и услуг\nSBER*5411*SAMOKAT\n28.06.2026\nв 16:32\n30.06.2026\n*1848\n–507,00 ₽\n–507,00 ₽\nОплата товаров и услуг\nYANDEX*7999*BIKE\n28.06.2026\nв 07:46\n30.06.2026\n*1848\n–1,00 ₽\n–1,00 ₽\nОплата товаров и услуг\nPYATEROCHKA 6812\n28.06.2026\nв 08:02\n30.06.2026\n*1848\n–109,98 ₽\n–109,98 ₽\nСтраница 10 из 15\nПродолжение на следующей странице\n\nОписание операции\nДата и время\nоперации\nМСК\nДата\nобработки\nМСК\nКарта\nСумма в валюте\nоперации\nСумма в валюте\nДоговора\nОплата СБП QR (ООО "ИНТЕР")\n30.06.2026\nв 18:04\n30.06.2026\n–100,00 ₽\n–100,00 ₽\nОплата товаров и услуг DIXY-\n78336D\n28.06.2026\nв 12:45\n30.06.2026\n*1848\n–447,56 ₽\n–447,56 ₽\nОплата СБП QR (ООО "ИНТЕР")\n30.06.2026\nв 19:44\n30.06.2026\n–100,00 ₽\n–100,00 ₽\nВходящий перевод по номеру\nкарты (IPKAMBULATOVAZN)\n01.07.2026\nв 09:41\n01.07.2026\n*1848\n+1 080,00 ₽\n+1 080,00 ₽\nПеревод между счетами одного\nклиента\n01.07.2026\nв 10:00\n01.07.2026\n–800,00 ₽\n–800,00 ₽\nОпл.по Дог.ОФ-26561424 5281.90\nруб\n01.07.2026\nв 11:07\n01.07.2026\n+5 281,90 ₽\n+5 281,90 ₽\nОпл.по Дог.26658326/25 637.56 руб\n01.07.2026\nв 11:07\n01.07.2026\n+637,56 ₽\n+637,56 ₽\nПеревод между счетами одного\nклиента\n01.07.2026\nв 13:37\n01.07.2026\n–5 200,00 ₽\n–5 200,00 ₽\nОплата товаров и услуг\nYANDEX*7999*BIKE\n29.06.2026\nв 07:40\n01.07.2026\n*1848\n–1,00 ₽\n–1,00 ₽\nОплата товаров и услуг DIXY-\n78336D\n29.06.2026\nв 12:55\n01.07.2026\n*1848\n–409,77 ₽\n–409,77 ₽\nВходящий перевод по номеру\nкарты (Tribute)\n01.07.2026\nв 15:50\n01.07.2026\n*1848\n+3 240,00 ₽\n+3 240,00 ₽\nПеревод между счетами одного\nклиента\n01.07.2026\nв 15:52\n01.07.2026\n–3 000,00 ₽\n–3 000,00 ₽\nОплата товаров и услуг\nPYATEROCHKA 6812\n29.06.2026\nв 08:01\n01.07.2026\n*1848\n–109,98 ₽\n–109,98 ₽\nОплата СБП QR\n(podorozhnik.spb.ru_SBP)\n01.07.2026\nв 16:19\n01.07.2026\n–130,00 ₽\n–130,00 ₽\nОплата товаров и услуг\nYANDEX*5411*LAVKA\n01.07.2026\nв 14:02\n01.07.2026\n*1848\n–178,00 ₽\n–178,00 ₽\nПеревод между счетами одного\nклиента\n02.07.2026\nв 10:06\n02.07.2026\n+1 000,00 ₽\n+1 000,00 ₽\nОпл.по Дог.26658326/25 599.94 руб\n02.07.2026\nв 10:37\n02.07.2026\n+599,94 ₽\n+599,94 ₽\nСтраница 11 из 15\nПродолжение на следующей странице\n\nОписание операции\nДата и время\nоперации\nМСК\nДата\nобработки\nМСК\nКарта\nСумма в валюте\nоперации\nСумма в валюте\nДоговора\nОплата СБП QR (RouterAI)\n02.07.2026\nв 12:14\n02.07.2026\n–100,00 ₽\n–100,00 ₽\nОплата товаров и услуг\nPYATEROCHKA 6812\n30.06.2026\nв 08:01\n02.07.2026\n*1848\n–169,97 ₽\n–169,97 ₽\nОплата товаров и услуг\nPYATEROCHKA 6812\n30.06.2026\nв 11:51\n02.07.2026\n*1848\n–109,98 ₽\n–109,98 ₽\nОплата товаров и услуг DIXY-\n78336D\n30.06.2026\nв 14:45\n02.07.2026\n*1848\n–178,67 ₽\n–178,67 ₽\nОплата товаров и услуг\nYANDEX*7999*BIKE\n30.06.2026\nв 08:34\n02.07.2026\n*1848\n–1,00 ₽\n–1,00 ₽\nОплата СБП QR (Озон)\n02.07.2026\nв 18:37\n02.07.2026\n–534,00 ₽\n–534,00 ₽\nОплата товаров и услуг B090\n01.07.2026\nв 10:04\n03.07.2026\n*1848\n–211,00 ₽\n–211,00 ₽\nОплата товаров и услуг\nUNIVERSAM VMESTE 24 CH\n01.07.2026\nв 19:22\n03.07.2026\n*1848\n–114,90 ₽\n–114,90 ₽\nОплата товаров и услуг\nUNIVERSAM VMESTE 24 CH\n01.07.2026\nв 21:21\n03.07.2026\n*1848\n–185,80 ₽\n–185,80 ₽\nОплата товаров и услуг\nYANDEX*7999*BIKE\n01.07.2026\nв 07:48\n03.07.2026\n*1848\n–1,00 ₽\n–1,00 ₽\nОплата СБП QR\n(podorozhnik.spb.ru_SBP)\n03.07.2026\nв 16:24\n03.07.2026\n–130,00 ₽\n–130,00 ₽\nОплата товаров и услуг DIXY-\n78336D\n01.07.2026\nв 17:21\n03.07.2026\n*1848\n–349,78 ₽\n–349,78 ₽\nПеревод между счетами одного\nклиента\n03.07.2026\nв 17:21\n03.07.2026\n+1 000,00 ₽\n+1 000,00 ₽\nОплата товаров и услуг\nPYATEROCHKA 22266\n02.07.2026\nв 10:26\n04.07.2026\n*1848\n–394,96 ₽\n–394,96 ₽\nОплата товаров и услуг B036\n03.07.2026\nв 08:28\n05.07.2026\n*1848\n–211,00 ₽\n–211,00 ₽\nОплата товаров и услуг\nYANDEX*7999*BIKE\n03.07.2026\nв 07:45\n05.07.2026\n*1848\n–1,00 ₽\n–1,00 ₽\nОплата товаров и услуг DIXY-\n78336D\n03.07.2026\nв 17:29\n05.07.2026\n*1848\n–451,55 ₽\n–451,55 ₽\nСтраница 12 из 15\nПродолжение на следующей странице\n\nОписание операции\nДата и время\nоперации\nМСК\nДата\nобработки\nМСК\nКарта\nСумма в валюте\nоперации\nСумма в валюте\nДоговора\nОплата товаров и услуг MAGNIT\nMM TIGIL\n03.07.2026\nв 12:40\n05.07.2026\n*1848\n–224,98 ₽\n–224,98 ₽\nОплата товаров и услуг\nPYATEROCHKA 6812\n04.07.2026\nв 07:59\n05.07.2026\n*1848\n–169,97 ₽\n–169,97 ₽\nОплата товаров и услуг\nPYATEROCHKA 6812\n04.07.2026\nв 12:36\n05.07.2026\n*1848\n–109,98 ₽\n–109,98 ₽\nОплата товаров и услуг\nPYATEROCHKA 6812\n04.07.2026\nв 11:57\n05.07.2026\n*1848\n–109,98 ₽\n–109,98 ₽\nОплата СБП QR (RouterAI)\n05.07.2026\nв 20:25\n05.07.2026\n–100,00 ₽\n–100,00 ₽\nОпл.по Дог.26658326/25 3467.94\nруб\n06.07.2026\nв 10:07\n06.07.2026\n+3 467,94 ₽\n+3 467,94 ₽\nПеревод между счетами одного\nклиента\n06.07.2026\nв 10:53\n06.07.2026\n–3 500,00 ₽\n–3 500,00 ₽\nОплата СБП QR (RouterAI)\n06.07.2026\nв 10:53\n06.07.2026\n–100,00 ₽\n–100,00 ₽\nОплата товаров и услуг\nYANDEX*7999*BIKE\n04.07.2026\nв 08:32\n06.07.2026\n*1848\n–1,00 ₽\n–1,00 ₽\nОплата товаров и услуг\nYANDEX*7999*BIKE\n05.07.2026\nв 08:07\n07.07.2026\n*1848\n–1,00 ₽\n–1,00 ₽\nПеревод между счетами одного\nклиента\n07.07.2026\nв 15:07\n07.07.2026\n+540,92 ₽\n+540,92 ₽\nОплата товаров и услуг\nYANDEX*7999*BIKE\n05.07.2026\nв 07:44\n07.07.2026\n*1848\n–1,00 ₽\n–1,00 ₽\nПеревод между счетами одного\nклиента\n07.07.2026\nв 17:16\n07.07.2026\n+1 000,00 ₽\n+1 000,00 ₽\nИсходящий перевод СБП, Валерий\nЕвгеньевич Б., +7 950 328-85-89,\nОзон Банк (Ozon)\n07.07.2026\nв 17:20\n07.07.2026\n–523,00 ₽\n–523,00 ₽\nОплата СБП QR (RouterAI)\n07.07.2026\nв 20:16\n07.07.2026\n–100,00 ₽\n–100,00 ₽\nПеревод между счетами одного\nклиента\n08.07.2026\nв 06:46\n08.07.2026\n+1 000,00 ₽\n+1 000,00 ₽\nСтраница 13 из 15\nПродолжение на следующей странице\n\nОписание операции\nДата и время\nоперации\nМСК\nДата\nобработки\nМСК\nКарта\nСумма в валюте\nоперации\nСумма в валюте\nДоговора\nОплата СБП QR (ТОО "ОнлиПэй")\n08.07.2026\nв 06:47\n08.07.2026\n–939,40 ₽\n–939,40 ₽\nПеревод между счетами одного\nклиента\n08.07.2026\nв 09:22\n08.07.2026\n+11 000,00 ₽\n+11 000,00 ₽\nОпл.по Дог.ОФ-26561424 8174.23\nруб\n08.07.2026\nв 10:39\n08.07.2026\n+8 174,23 ₽\n+8 174,23 ₽\nОпл.по Дог.26658326/25 669.24 руб\n08.07.2026\nв 10:39\n08.07.2026\n+669,24 ₽\n+669,24 ₽\nИсходящий перевод СБП, Надежда\nПетровна П., +7 911 269-21-08,\nАльфа-Банк\n08.07.2026\nв 12:33\n08.07.2026\n–10 000,00 ₽\n–10 000,00 ₽\nИсходящий перевод СБП,\nАлександр Викторович П., +7 911\n263-29-95, Альфа-Банк\n08.07.2026\nв 12:35\n08.07.2026\n–10 000,00 ₽\n–10 000,00 ₽\nОпл.по Дог.26658326/25 836.33 руб\n09.07.2026\nв 10:39\n09.07.2026\n+836,33 ₽\n+836,33 ₽\nОплата товаров и услуг\nYANDEX*5411*LAVKA\n09.07.2026\nв 08:00\n09.07.2026\n*1848\n–94,00 ₽\n–94,00 ₽\nОплата товаров и услуг\nYANDEX*5411*LAVKA\n09.07.2026\nв 15:32\n09.07.2026\n*1848\n–110,00 ₽\n–110,00 ₽\nОплата СБП QR\n(podorozhnik.spb.ru_SBP)\n09.07.2026\nв 15:52\n09.07.2026\n–130,00 ₽\n–130,00 ₽\nОплата товаров и услуг\nYANDEX*7999*BIKE\n07.07.2026\nв 08:57\n09.07.2026\n*1848\n–1,00 ₽\n–1,00 ₽\nОплата товаров и услуг DIXY-\n78336D\n07.07.2026\nв 15:07\n09.07.2026\n*1848\n–291,88 ₽\n–291,88 ₽\nВходящий перевод СБП, Илья\nАлексеевич Л., +7 992 028-51-42,\nАльфа-Банк\n09.07.2026\nв 21:07\n09.07.2026\n+2 000,00 ₽\n+2 000,00 ₽\nОплата СБП QR (RouterAI)\n09.07.2026\nв 21:16\n09.07.2026\n–100,00 ₽\n–100,00 ₽\nОпл.по Дог.26658326/25 775.70 руб\n10.07.2026\nв 11:09\n10.07.2026\n+775,70 ₽\n+775,70 ₽\nОплата товаров и услуг DIXY-\n78336D\n08.07.2026\nв 14:40\n10.07.2026\n*1848\n–356,78 ₽\n–356,78 ₽\nСтраница 14 из 15\nПродолжение на следующей странице\n\nОписание операции\nДата и время\nоперации\nМСК\nДата\nобработки\nМСК\nКарта\nСумма в валюте\nоперации\nСумма в валюте\nДоговора\nОплата СБП QR\n(podorozhnik.spb.ru_SBP)\n10.07.2026\nв 14:59\n10.07.2026\n–130,00 ₽\n–130,00 ₽\nОплата товаров и услуг\nYANDEX*7999*BIKE\n08.07.2026\nв 08:07\n10.07.2026\n*1848\n–1,00 ₽\n–1,00 ₽\nОплата товаров и услуг DIXY-\n78336D\n08.07.2026\nв 14:41\n10.07.2026\n*1848\n–39,98 ₽\n–39,98 ₽\nОплата товаров и услуг\nUNIVERSAM VMESTE 24 CH\n08.07.2026\nв 20:08\n10.07.2026\n*1848\n–159,90 ₽\n–159,90 ₽\nОплата СБП QR (Sota Connect)\n10.07.2026\nв 17:18\n10.07.2026\n–349,00 ₽\n–349,00 ₽\nОплата СБП QR (OZON)\n10.07.2026\nв 18:38\n10.07.2026\n–83,00 ₽\n–83,00 ₽\nОплата СБП QR (RouterAI)\n10.07.2026\nв 20:57\n10.07.2026\n–100,00 ₽\n–100,00 ₽\nОплата СБП QR (RouterAI)\n10.07.2026\nв 22:51\n10.07.2026\n–100,00 ₽\n–100,00 ₽\nИсходящий остаток за 10.07.2026\n2 540,89 ₽\n+108 372,62 ₽\n–107 318,80 ₽\nВсего расходных операций\nВсего приходных операций\nСтраница 15 из 15\n	completed	2026-08-03 12:55:46.653255+00
\.


--
-- Data for Name: calendar_events; Type: TABLE DATA; Schema: public; Owner: lifeagent
--

COPY public.calendar_events (id, user_id, title, start_time, end_time, color, description, created_at, updated_at, completed, push_enabled) FROM stdin;
1	4	ммм	2026-07-17 08:00:00	2026-07-17 11:00:00	#3B82F6	\N	2026-07-16 14:17:17.658561	2026-07-16 14:17:17.658561	f	f
2	3	в	2026-07-17 08:00:00	2026-07-17 11:00:00	#3B82F6	\N	2026-07-16 15:08:06.294541	2026-07-16 15:08:06.294541	f	f
3	3	п	2026-07-16 07:00:00	2026-07-16 11:00:00	#3B82F6	\N	2026-07-16 15:08:15.511194	2026-07-16 15:08:15.511194	f	f
4	2	чвв	2026-07-27 12:00:00	2026-07-27 17:00:00	#8B5CF6	\N	2026-07-27 16:31:58.794032	2026-07-27 16:31:58.794032	f	f
5	2	вв	2026-07-27 17:00:00	2026-07-27 21:00:00	#10B981	\N	2026-07-27 16:32:03.902566	2026-07-27 16:32:03.902566	f	f
29	3	Разработка приложения	2026-08-02 10:00:00	2026-08-02 13:00:00	#3B82F6		2026-08-02 16:27:43.639521	2026-08-02 16:27:43.639521	f	f
30	3	кушал	2026-08-02 13:00:00	2026-08-02 13:30:00	#3B82F6		2026-08-02 16:27:52.956813	2026-08-02 16:27:52.956813	f	f
31	3	Встреча с партером по инвестиционным консультациям	2026-08-02 13:30:00	2026-08-02 16:30:00	#3B82F6		2026-08-02 16:28:17.475908	2026-08-02 16:28:17.475908	f	f
32	3	Отдых, прием пищи	2026-08-02 16:30:00	2026-08-02 18:30:00	#3B82F6		2026-08-02 16:28:37.788502	2026-08-02 16:28:37.788502	f	f
33	3	Разработка приложения	2026-08-02 18:30:00	2026-08-02 20:00:00	#3B82F6		2026-08-02 16:28:53.11522	2026-08-02 16:28:53.11522	f	f
34	2	Подъем	2026-08-03 06:30:00	2026-08-03 07:30:00	#3B82F6	Просыпаюсь	2026-08-03 09:59:44.11927	2026-08-03 09:59:44.11927	f	t
35	2	Дорога на работу и завтрак	2026-08-03 06:30:00	2026-08-03 08:00:00	#3B82F6	Полтора часа добираюсь до работы, кушаю	2026-08-03 09:59:44.11927	2026-08-03 09:59:44.11927	f	t
36	2	Работа	2026-08-03 08:00:00	2026-08-03 16:00:00	#3B82F6	Работаю	2026-08-03 09:59:44.11927	2026-08-03 09:59:44.11927	f	t
37	2	Дорога домой, ужин и отдых	2026-08-03 16:00:00	2026-08-03 17:00:00	#3B82F6	Прихожу домой, кушаю, чуть-чуть могу отдохнуть	2026-08-03 09:59:44.11927	2026-08-03 09:59:44.11927	f	t
38	2	Съемка короткого видео	2026-08-03 17:00:00	2026-08-03 18:00:00	#3B82F6	Снимаю короткое видео на YouTube, в Instagram, TikTok	2026-08-03 09:59:44.11927	2026-08-03 09:59:44.11927	f	t
39	2	Отдых и уборка	2026-08-03 18:00:00	2026-08-03 19:00:00	#3B82F6	Могу отдохнуть, прибраться	2026-08-03 09:59:44.11927	2026-08-03 09:59:44.11927	f	t
40	2	Создание большого видео	2026-08-03 19:00:00	2026-08-03 21:00:00	#3B82F6	Делаю большое видео, монтаж	2026-08-03 09:59:44.11927	2026-08-03 09:59:44.11927	f	t
41	2	Отдых перед сном	2026-08-03 21:00:00	2026-08-03 23:00:00	#3B82F6	Два часа отдыха перед сном	2026-08-03 09:59:44.11927	2026-08-03 09:59:44.11927	f	t
42	2	Подъем	2026-08-04 06:30:00	2026-08-04 07:30:00	#3B82F6	Просыпаюсь	2026-08-03 09:59:44.11927	2026-08-03 09:59:44.11927	f	t
43	2	Дорога на работу и завтрак	2026-08-04 06:30:00	2026-08-04 08:00:00	#3B82F6	Полтора часа добираюсь до работы, кушаю	2026-08-03 09:59:44.11927	2026-08-03 09:59:44.11927	f	t
44	2	Работа	2026-08-04 08:00:00	2026-08-04 16:00:00	#3B82F6	Работаю	2026-08-03 09:59:44.11927	2026-08-03 09:59:44.11927	f	t
45	2	Дорога домой, ужин и отдых	2026-08-04 16:00:00	2026-08-04 17:00:00	#3B82F6	Прихожу домой, кушаю, чуть-чуть могу отдохнуть	2026-08-03 09:59:44.11927	2026-08-03 09:59:44.11927	f	t
46	2	Съемка короткого видео	2026-08-04 17:00:00	2026-08-04 18:00:00	#3B82F6	Снимаю короткое видео на YouTube, в Instagram, TikTok	2026-08-03 09:59:44.11927	2026-08-03 09:59:44.11927	f	t
47	2	Отдых и уборка	2026-08-04 18:00:00	2026-08-04 19:00:00	#3B82F6	Могу отдохнуть, прибраться	2026-08-03 09:59:44.11927	2026-08-03 09:59:44.11927	f	t
48	2	Создание большого видео	2026-08-04 19:00:00	2026-08-04 21:00:00	#3B82F6	Делаю большое видео, монтаж	2026-08-03 09:59:44.11927	2026-08-03 09:59:44.11927	f	t
49	2	Отдых перед сном	2026-08-04 21:00:00	2026-08-04 23:00:00	#3B82F6	Два часа отдыха перед сном	2026-08-03 09:59:44.11927	2026-08-03 09:59:44.11927	f	t
50	2	Подъем	2026-08-05 06:30:00	2026-08-05 07:30:00	#3B82F6	Просыпаюсь	2026-08-03 09:59:44.11927	2026-08-03 09:59:44.11927	f	t
51	2	Дорога на работу и завтрак	2026-08-05 06:30:00	2026-08-05 08:00:00	#3B82F6	Полтора часа добираюсь до работы, кушаю	2026-08-03 09:59:44.11927	2026-08-03 09:59:44.11927	f	t
52	2	Работа	2026-08-05 08:00:00	2026-08-05 16:00:00	#3B82F6	Работаю	2026-08-03 09:59:44.11927	2026-08-03 09:59:44.11927	f	t
53	2	Дорога домой, ужин и отдых	2026-08-05 16:00:00	2026-08-05 17:00:00	#3B82F6	Прихожу домой, кушаю, чуть-чуть могу отдохнуть	2026-08-03 09:59:44.11927	2026-08-03 09:59:44.11927	f	t
54	2	Съемка короткого видео	2026-08-05 17:00:00	2026-08-05 18:00:00	#3B82F6	Снимаю короткое видео на YouTube, в Instagram, TikTok	2026-08-03 09:59:44.11927	2026-08-03 09:59:44.11927	f	t
55	2	Отдых и уборка	2026-08-05 18:00:00	2026-08-05 19:00:00	#3B82F6	Могу отдохнуть, прибраться	2026-08-03 09:59:44.11927	2026-08-03 09:59:44.11927	f	t
56	2	Создание большого видео	2026-08-05 19:00:00	2026-08-05 21:00:00	#3B82F6	Делаю большое видео, монтаж	2026-08-03 09:59:44.11927	2026-08-03 09:59:44.11927	f	t
57	2	Отдых перед сном	2026-08-05 21:00:00	2026-08-05 23:00:00	#3B82F6	Два часа отдыха перед сном	2026-08-03 09:59:44.11927	2026-08-03 09:59:44.11927	f	t
58	2	Подъем	2026-08-06 06:30:00	2026-08-06 07:30:00	#3B82F6	Просыпаюсь	2026-08-03 09:59:44.11927	2026-08-03 09:59:44.11927	f	t
59	2	Дорога на работу и завтрак	2026-08-06 06:30:00	2026-08-06 08:00:00	#3B82F6	Полтора часа добираюсь до работы, кушаю	2026-08-03 09:59:44.11927	2026-08-03 09:59:44.11927	f	t
60	2	Работа	2026-08-06 08:00:00	2026-08-06 16:00:00	#3B82F6	Работаю	2026-08-03 09:59:44.11927	2026-08-03 09:59:44.11927	f	t
61	2	Дорога домой, ужин и отдых	2026-08-06 16:00:00	2026-08-06 17:00:00	#3B82F6	Прихожу домой, кушаю, чуть-чуть могу отдохнуть	2026-08-03 09:59:44.11927	2026-08-03 09:59:44.11927	f	t
62	2	Съемка короткого видео	2026-08-06 17:00:00	2026-08-06 18:00:00	#3B82F6	Снимаю короткое видео на YouTube, в Instagram, TikTok	2026-08-03 09:59:44.11927	2026-08-03 09:59:44.11927	f	t
63	2	Отдых и уборка	2026-08-06 18:00:00	2026-08-06 19:00:00	#3B82F6	Могу отдохнуть, прибраться	2026-08-03 09:59:44.11927	2026-08-03 09:59:44.11927	f	t
64	2	Создание большого видео	2026-08-06 19:00:00	2026-08-06 21:00:00	#3B82F6	Делаю большое видео, монтаж	2026-08-03 09:59:44.11927	2026-08-03 09:59:44.11927	f	t
66	2	Подъем	2026-08-07 06:30:00	2026-08-07 07:30:00	#3B82F6	Просыпаюсь	2026-08-03 09:59:44.11927	2026-08-03 09:59:44.11927	f	t
67	2	Дорога на работу и завтрак	2026-08-07 06:30:00	2026-08-07 08:00:00	#3B82F6	Полтора часа добираюсь до работы, кушаю	2026-08-03 09:59:44.11927	2026-08-03 09:59:44.11927	f	t
68	2	Работа	2026-08-07 08:00:00	2026-08-07 16:00:00	#3B82F6	Работаю	2026-08-03 09:59:44.11927	2026-08-03 09:59:44.11927	f	t
69	2	Дорога домой, ужин и отдых	2026-08-07 16:00:00	2026-08-07 17:00:00	#3B82F6	Прихожу домой, кушаю, чуть-чуть могу отдохнуть	2026-08-03 09:59:44.11927	2026-08-03 09:59:44.11927	f	t
70	2	Съемка короткого видео	2026-08-07 17:00:00	2026-08-07 18:00:00	#3B82F6	Снимаю короткое видео на YouTube, в Instagram, TikTok	2026-08-03 09:59:44.11927	2026-08-03 09:59:44.11927	f	t
71	2	Отдых и уборка	2026-08-07 18:00:00	2026-08-07 19:00:00	#3B82F6	Могу отдохнуть, прибраться	2026-08-03 09:59:44.11927	2026-08-03 09:59:44.11927	f	t
72	2	Создание большого видео	2026-08-07 19:00:00	2026-08-07 21:00:00	#3B82F6	Делаю большое видео, монтаж	2026-08-03 09:59:44.11927	2026-08-03 09:59:44.11927	f	t
73	2	Отдых перед сном	2026-08-07 21:00:00	2026-08-07 23:00:00	#3B82F6	Два часа отдыха перед сном	2026-08-03 09:59:44.11927	2026-08-03 09:59:44.11927	f	t
74	2	Подъем	2026-08-08 06:30:00	2026-08-08 07:30:00	#3B82F6	Просыпаюсь	2026-08-03 09:59:44.11927	2026-08-03 09:59:44.11927	f	t
75	2	Дорога на работу и завтрак	2026-08-08 06:30:00	2026-08-08 08:00:00	#3B82F6	Полтора часа добираюсь до работы, кушаю	2026-08-03 09:59:44.11927	2026-08-03 09:59:44.11927	f	t
76	2	Работа	2026-08-08 08:00:00	2026-08-08 16:00:00	#3B82F6	Работаю	2026-08-03 09:59:44.11927	2026-08-03 09:59:44.11927	f	t
77	2	Дорога домой, ужин и отдых	2026-08-08 16:00:00	2026-08-08 17:00:00	#3B82F6	Прихожу домой, кушаю, чуть-чуть могу отдохнуть	2026-08-03 09:59:44.11927	2026-08-03 09:59:44.11927	f	t
78	2	Съемка короткого видео	2026-08-08 17:00:00	2026-08-08 18:00:00	#3B82F6	Снимаю короткое видео на YouTube, в Instagram, TikTok	2026-08-03 09:59:44.11927	2026-08-03 09:59:44.11927	f	t
79	2	Отдых и уборка	2026-08-08 18:00:00	2026-08-08 19:00:00	#3B82F6	Могу отдохнуть, прибраться	2026-08-03 09:59:44.11927	2026-08-03 09:59:44.11927	f	t
80	2	Создание большого видео	2026-08-08 19:00:00	2026-08-08 21:00:00	#3B82F6	Делаю большое видео, монтаж	2026-08-03 09:59:44.11927	2026-08-03 09:59:44.11927	f	t
81	2	Отдых перед сном	2026-08-08 21:00:00	2026-08-08 23:00:00	#3B82F6	Два часа отдыха перед сном	2026-08-03 09:59:44.11927	2026-08-03 09:59:44.11927	f	t
82	2	Подъем	2026-08-09 06:30:00	2026-08-09 07:30:00	#3B82F6	Просыпаюсь	2026-08-03 09:59:44.11927	2026-08-03 09:59:44.11927	f	t
83	2	Дорога на работу и завтрак	2026-08-09 06:30:00	2026-08-09 08:00:00	#3B82F6	Полтора часа добираюсь до работы, кушаю	2026-08-03 09:59:44.11927	2026-08-03 09:59:44.11927	f	t
84	2	Работа	2026-08-09 08:00:00	2026-08-09 16:00:00	#3B82F6	Работаю	2026-08-03 09:59:44.11927	2026-08-03 09:59:44.11927	f	t
85	2	Дорога домой, ужин и отдых	2026-08-09 16:00:00	2026-08-09 17:00:00	#3B82F6	Прихожу домой, кушаю, чуть-чуть могу отдохнуть	2026-08-03 09:59:44.11927	2026-08-03 09:59:44.11927	f	t
86	2	Съемка короткого видео	2026-08-09 17:00:00	2026-08-09 18:00:00	#3B82F6	Снимаю короткое видео на YouTube, в Instagram, TikTok	2026-08-03 09:59:44.11927	2026-08-03 09:59:44.11927	f	t
87	2	Отдых и уборка	2026-08-09 18:00:00	2026-08-09 19:00:00	#3B82F6	Могу отдохнуть, прибраться	2026-08-03 09:59:44.11927	2026-08-03 09:59:44.11927	f	t
88	2	Создание большого видео	2026-08-09 19:00:00	2026-08-09 21:00:00	#3B82F6	Делаю большое видео, монтаж	2026-08-03 09:59:44.11927	2026-08-03 09:59:44.11927	f	t
89	2	Отдых перед сном	2026-08-09 21:00:00	2026-08-09 23:00:00	#3B82F6	Два часа отдыха перед сном	2026-08-03 09:59:44.11927	2026-08-03 09:59:44.11927	f	t
90	2	уууу	2026-08-06 21:00:00	2026-08-06 22:00:00	#3B82F6		2026-08-03 10:11:39.133067	2026-08-03 10:11:39.133067	f	f
92	3	Работа	2026-08-04 08:00:00	2026-08-04 16:00:00	#3B82F6	Работа	2026-08-04 18:53:27.215045	2026-08-04 18:53:27.215045	f	t
93	3	Личные дела	2026-08-04 16:00:00	2026-08-04 17:00:00	#3B82F6	Прихожу просто работать, кушаю, убираюсь	2026-08-04 18:53:27.215045	2026-08-04 18:53:27.215045	f	t
94	3	YouTube	2026-08-04 17:00:00	2026-08-04 18:00:00	#3B82F6	Снимаю короткие видео на Ютубе, монтирую, выкладываю	2026-08-04 18:53:27.215045	2026-08-04 18:53:27.215045	f	t
95	3	Отдых	2026-08-04 18:00:00	2026-08-04 19:00:00	#3B82F6	Отдыхаю	2026-08-04 18:53:27.215045	2026-08-04 18:53:27.215045	f	t
96	3	Работа над приложением	2026-08-04 19:00:00	2026-08-04 20:00:00	#3B82F6	Работа над приложением	2026-08-04 18:53:27.215045	2026-08-04 18:53:27.215045	f	t
97	3	Видео-монтаж	2026-08-04 20:00:00	2026-08-04 21:00:00	#3B82F6	Работа на большом видео-монтаже	2026-08-04 18:53:27.215045	2026-08-04 18:53:27.215045	f	t
\.


--
-- Data for Name: chats; Type: TABLE DATA; Schema: public; Owner: lifeagent
--

COPY public.chats (id, user_id, agent_id, title, is_pinned, created_at, updated_at) FROM stdin;
1	1	4	Приветствие	f	2026-07-16 11:59:08.784844	2026-07-16 11:59:08.784844
2	4	5	Идеи для ужина	f	2026-07-16 12:17:57.722379	2026-07-16 12:17:57.722379
3	4	4	Книжные рекомендации	f	2026-07-16 12:27:24.946922	2026-07-16 12:27:24.946922
4	4	6	Новый чат	f	2026-07-16 13:32:58.847246	2026-07-16 13:32:58.847246
172	2	4	Выбор фильма на вечер	f	2026-08-03 12:59:13.250692	2026-08-03 12:59:13.250692
6	3	4	Книги на вечер	f	2026-07-16 15:26:02.590265	2026-07-16 15:26:02.590265
7	3	4	Обсуждение фильма Интерстеллар	f	2026-07-16 15:27:45.164269	2026-07-16 15:27:45.164269
8	3	4	Приветствие	f	2026-07-19 20:29:42.540975	2026-07-19 20:29:42.540975
9	3	7	Встреча с Эратом	f	2026-07-20 18:42:55.576036	2026-07-20 18:42:55.576036
10	3	4	Выбор фильма на вечер	f	2026-07-20 18:47:32.128797	2026-07-20 18:47:32.128797
11	3	4	Рекомендация фильма на вечер	f	2026-07-21 06:52:46.123627	2026-07-21 06:52:46.123627
174	4	6	Что почитать вечером	f	2026-08-03 13:09:55.241966	2026-08-03 13:09:55.241966
175	4	7	Создание расписания	f	2026-08-03 13:53:50.603766	2026-08-03 13:53:50.603766
25	3	6	Новый чат	f	2026-07-21 08:45:49.950747	2026-07-21 08:45:49.950747
26	3	4	Выбор фильма на вечер	f	2026-07-21 08:52:27.439847	2026-07-21 08:52:27.439847
27	3	5	💬 Чат с диетологом	f	2026-07-21 08:54:52.544532	2026-07-21 08:54:52.544532
224	3	4	Подборка сериалов на вечер	f	2026-08-08 09:46:45.159012	2026-08-08 09:46:45.159012
29	3	6	Новый чат	f	2026-07-21 08:58:57.302929	2026-07-21 08:58:57.302929
30	3	4	Подборка фильмов на вечер	f	2026-07-21 08:59:26.300578	2026-07-21 08:59:26.300578
34	3	4	Выбор фильма на вечер	f	2026-07-21 10:14:55.714237	2026-07-21 10:14:55.714237
35	3	5	💬 Чат с диетологом	f	2026-07-21 10:15:18.273861	2026-07-21 10:15:18.273861
37	3	4	Возможности нейросети	f	2026-07-21 11:00:28.31095	2026-07-21 11:00:28.31095
38	3	6	Что такое пропсы	f	2026-07-21 11:02:38.735634	2026-07-21 11:02:38.735634
41	3	4	Возможности искусственного интеллекта	f	2026-07-21 12:30:58.136064	2026-07-21 12:30:58.136064
54	2	4	Возможности искусственного интеллекта	f	2026-07-22 17:51:42.502146	2026-07-22 17:51:42.502146
55	2	6	Что почитать вечером	f	2026-07-22 17:52:14.61694	2026-07-22 17:52:14.61694
56	2	4	Выбор фильма на вечер	f	2026-07-22 17:53:02.896721	2026-07-22 17:53:02.896721
60	41	4	Приветствие	f	2026-07-23 17:28:44.027178	2026-07-23 17:28:44.027178
63	2	7	Создание расписания	f	2026-07-28 08:39:18.904234	2026-07-28 08:39:18.904234
64	2	4	Подборка фильмов на вечер	f	2026-08-02 07:18:27.903739	2026-08-02 07:18:27.903739
69	2	8	Сеанс психотерапии	f	2026-08-02 10:10:05.121052	2026-08-02 10:10:05.121052
70	2	4	Возможности искусственного интеллекта	f	2026-08-02 10:22:39.225347	2026-08-02 10:22:39.225347
71	2	7	Создание расписания	f	2026-08-02 15:30:34.078047	2026-08-02 15:30:34.078047
241	3	4	Выбор фильма на вечер	f	2026-08-08 12:13:52.612855	2026-08-08 12:13:52.612855
243	2	4	Подборка фильмов на вечер	f	2026-08-08 12:32:22.85596	2026-08-08 12:32:22.85596
162	2	7	Расписание на 6 августа	f	2026-08-03 10:11:49.409648	2026-08-03 10:11:49.409648
163	2	7	Создание расписания	f	2026-08-03 11:06:57.941661	2026-08-03 11:06:57.941661
\.


--
-- Data for Name: daily_food_analyses; Type: TABLE DATA; Schema: public; Owner: lifeagent
--

COPY public.daily_food_analyses (id, user_id, analysis_date, analysis_text, created_at, updated_at) FROM stdin;
1	3	2026-07-23	Здравствуйте! Как ваш ИИ-диетолог, проанализировал ваш рацион. Вот экспертная выжимка:\n\n1. **Анализ КБЖУ:** Вы находитесь в рамках дефицита калорий, что соответствует цели похудения, однако баланс нутриентов нарушен. Главная проблема — критический недобор белка (83г при норме 180г) и значительный перебор по жирам (111г при норме 62г). Углеводы находятся в пределах нормы, но их структура требует корректировки.\n\n2. **Качество рациона:** Рацион несбалансирован. Основной источник жиров — 200г кешью — обеспечил более 50% вашей суточной калорийности, что привело к резкому превышению лимита жиров. При этом в рационе практически отсутствуют свежие овощи (кроме лечо) и качественные источники клетчатки, а доля белка в два раза ниже необходимой для сохранения мышечной массы при дефиците калорий.\n\n3. **Рекомендации:** На сегодня прием пищи стоит завершить. На будущее: исключите орехи как основной перекус — это «калорийная бомба», которая мешает достижению цели. В следующий раз замените порцию орехов на нежирную рыбу, куриную грудку или творог, чтобы добрать белок, и добавьте больше зеленых овощей для сытости. Завтра постарайтесь распределить белковые продукты равномерно по всем приемам пищи, чтобы избежать дефицита. Вы на верном пути, просто скорректируйте выбор продуктов в пользу менее жирных источников.	2026-07-23 17:20:04.798654+00	2026-07-23 17:25:31.137024+00
\.


--
-- Data for Name: diary_entries; Type: TABLE DATA; Schema: public; Owner: lifeagent
--

COPY public.diary_entries (id, user_id, title, content, mood, mood_emoji, tags, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: diet_plans; Type: TABLE DATA; Schema: public; Owner: lifeagent
--

COPY public.diet_plans (id, user_id, plan_data, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: dream_analyses; Type: TABLE DATA; Schema: public; Owner: lifeagent
--

COPY public.dream_analyses (id, user_id, dream_text, branches_data, created_at) FROM stdin;
\.


--
-- Data for Name: dream_goals; Type: TABLE DATA; Schema: public; Owner: lifeagent
--

COPY public.dream_goals (id, user_id, dream_text, category, goal_summary, analysis, steps_data, selected_step_ids, chat_id, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: financial_obligations; Type: TABLE DATA; Schema: public; Owner: lifeagent
--

COPY public.financial_obligations (id, user_id, date, title, amount, type, created_at) FROM stdin;
1	1	5	аренда кв	23000	expense	2026-07-26 17:54:54.817439+00
\.


--
-- Data for Name: food_consumptions; Type: TABLE DATA; Schema: public; Owner: lifeagent
--

COPY public.food_consumptions (id, user_id, product_name, grams, calories, protein, fats, carbs, meal_type, notes, consumed_at, created_at) FROM stdin;
1	3	орешки кешью	100	553	18	44	30	other	\N	2026-07-23 16:49:47.301916+00	2026-07-23 16:49:39.653793+00
2	3	орешки кешью	100	553	18	44	30	other	\N	2026-07-23 16:56:37.755015+00	2026-07-23 16:56:26.319017+00
3	3	макароны вареные	300	420	15	3	84	lunch	\N	2026-07-23 17:04:44.523389+00	2026-07-23 17:04:26.628568+00
4	3	куриные фрикадельки	200	320	30	18	10	lunch	\N	2026-07-23 17:04:50.292241+00	2026-07-23 17:04:26.628568+00
5	3	лечо	200	90	2	2	16	lunch	\N	2026-07-23 17:04:54.33142+00	2026-07-23 17:04:26.628568+00
\.


--
-- Data for Name: knowledge_events; Type: TABLE DATA; Schema: public; Owner: lifeagent
--

COPY public.knowledge_events (id, user_id, event_type, agent_name, payload, status, processed_at, error_message, created_at) FROM stdin;
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: lifeagent
--

COPY public.messages (id, chat_id, role, content, tokens_used, created_at) FROM stdin;
1	1	user	Привет	0	2026-07-16 11:59:08.784844
2	1	assistant	Привет-привет! Всё готово к работе. С чего начнём? 😊	0	2026-07-16 11:59:08.784844
3	2	user	Что покушать на вечер приготовить?	0	2026-07-16 12:17:57.722379
4	2	assistant	{"type": "go_to_meal_plan", "text": "Я сформирую для вас индивидуальный план питания с учётом ваших параметров, целей и предпочтений. Нажмите кнопку ниже, чтобы перейти в раздел создания рациона — там я подберу блюда специально для вас! 🥗"}	0	2026-07-16 12:17:57.722379
5	3	user	Что почитать на вечер посоветуешь?	0	2026-07-16 12:27:24.946922
6	3	assistant	Выбор зависит от желаемого настроения:\n\n1. **Для интеллектуальной разрядки:** «Цветы для Элджернона» Дэниела Киза. Психологическая драма о прогрессе и одиночестве. Читается быстро, оставляет глубокий след.\n2. **Для погружения в атмосферу:** «Пикник на обочине» братьев Стругацких. Мрачная, философская фантастика, идеальная для вечернего чтения.\n3. **Для сатиры и иронии:** «Автостопом по галактике» Дугласа Адамса. Легкий юмор, который помогает отвлечься от повседневности.\n4. **Для любителей детектива:** «Десять негритят» Агаты Кристи. Классика жанра, держащая в напряжении до последней страницы.\n\nЧто из этого ближе к твоему запросу?	0	2026-07-16 12:27:24.946922
7	4	assistant	Привет! 👋 Я — ваш ментор. Чем я могу помочь вам сегодня? Расскажите о своих целях, планах или задайте любой вопрос о развитии и самореализации.	0	2026-07-16 13:32:58.847246
10	1	user	что посоветуешь посмотреть на вечер	0	2026-07-16 15:08:34.109253
11	1	assistant	Выбор зависит от жанровых предпочтений. Вот варианты под разное настроение:\n\n**1. Интеллектуальный триллер / Драма:**\n*   **«Оставленные» (The Holdovers, 2023)** — трогательная и ироничная история о взаимоотношениях учителя, ученика и повара в закрытой школе 70-х. Атмосферно и глубоко.\n*   **«Анатомия падения» (Anatomie d'une chute, 2023)** — напряженная судебная драма, исследующая границы правды в семейных отношениях.\n\n**2. Научная фантастика / Антиутопия:**\n*   **«Разделение» (Severance, 2022, сериал)** — если хочешь необычный концепт: сотрудников компании хирургически разделяют память на «рабочую» и «личную». Очень стильно и пугающе.\n*   **«Бегущий по лезвию 2049» (2017)** — визуальный шедевр Дени Вильнёва. Идеально для погружения в атмосферу.\n\n**3. Легкий детектив / Комедия:**\n*   **«Достать ножи» (2019)** — классический герметичный детектив с отличным актерским составом и долей юмора.\n*   **«Убийства в одном здании» (Only Murders in the Building, сериал)** — уютная, ироничная история с элементами расследования.\n\n**4. Киберпанк / Экшен:**\n*   **«Аркейн» (Arcane, 2021, анимационный сериал)** — даже если ты не играл в League of Legends. Это одна из лучших визуальных и сценарных работ последних лет.\n\nЧто из этого ближе к твоему текущему настрою?	0	2026-07-16 15:08:34.109253
12	1	user	Ну, хочется что-то более романтическое, знаешь, посмотреть из современного.	0	2026-07-16 15:08:55.126581
13	1	assistant	Для романтики с современным привкусом и качественным сценарием рекомендую следующее:\n\n**1. «Прошлые жизни» (Past Lives, 2023)**\nГлубокая, меланхоличная и очень красивая история о судьбе, выборе и людях, которые были близки в разные периоды жизни. Это не типичная «розовая» мелодрама, а взрослое кино об упущенных возможностях и привязанности.\n\n**2. «Рецепт любви» (La Passion de Dodin Bouffant, 2023)**\nИстория любви, рассказанная через кулинарию. Французская эстетика, неспешный темп и невероятно чувственная химия между главными героями. Идеально под ужин.\n\n**3. «Американское чтиво» (American Fiction, 2023) — линия отношений**\nХотя это сатира, второстепенная романтическая линия главного героя подана очень реалистично, без лишнего пафоса и клише.\n\n**4. «Притворись моим мужем» (Anyone But You, 2023)**\nЕсли хочется классической легкой романтической комедии в духе 2000-х, но с современной картинкой. Динамично, солнечно, типичный ромком «от ненависти до любви».\n\n**5. «Солнце моё» (Aftersun, 2022)**\nЭто скорее драма с элементами светлой романтики воспоминаний (между отцом и дочерью), но по эмоциональному воздействию и эстетике — одно из самых сильных высказываний последних лет.\n\nЧто больше привлекает: легкий ромком или глубокая, серьезная история?	0	2026-07-16 15:08:55.126581
14	6	user	Что посоветуешь почитать на вечер?	0	2026-07-16 15:26:02.590265
15	6	assistant	Выбор зависит от желаемого настроения:\n\n1. **Филип Дик, «Мечтают ли андроиды об электроовцах?»** — если хочешь погрузиться в качественную философскую фантастику и вопросы человечности. Читается быстро, оставляет долгое послевкусие.\n2. **Фредрик Бакман, «Вторая жизнь Уве»** — для спокойного, эмоционального вечера. Добрая, но глубокая проза о человеческих взаимоотношениях.\n3. **Стивен Кинг, «11/22/63»** — если нужно объемное произведение, которое полностью захватит внимание на несколько вечеров. Альтернативная история с элементами триллера.\n4. **Станислав Лем, «Солярис»** — классика интеллектуальной фантастики. Сложное произведение о контакте с непостижимым разумом.\n\nЧто из этого ближе к твоим предпочтениям?	0	2026-07-16 15:26:02.590265
16	7	user	Знаешь, я вот люблю фильм «Интерстеллар». Мне очень нравится. Прям очень классный фильм. Что скажешь насчет него?	0	2026-07-16 15:27:45.164269
17	7	assistant	«Интерстеллар» — знаковое произведение в жанре научной фантастики, сочетающее фундаментальные физические концепции с глубокой гуманитарной драмой.\n\n**Сильные стороны:**\n1. **Научная достоверность:** Кип Торн, лауреат Нобелевской премии по физике, курировал визуализацию черной дыры (Гаргантюа) и кротовых нор. Расчеты гравитационного линзирования стали прорывом в компьютерной графике.\n2. **Визуальный язык:** Операторская работа Хойте ван Хойтемы и минималистичный дизайн кораблей создают ощущение осязаемой реальности, в противовес стерильному «глянцу» многих блокбастеров.\n3. **Саундтрек:** Ханс Циммер отошел от привычного оркестрового эпика в пользу органной музыки, что добавило фильму сакральности и космического масштаба.\n\n**Философский аспект:**\nФильм исследует парадокс времени и концепцию любви как измеримой физической величины. Кристофер Нолан поднимает вопрос о выживании человечества как вида: готовы ли мы пожертвовать текущим поколением ради будущего?\n\n**Критика:**\nОсновная претензия скептиков — финал, где физика уступает место метафизике и «силе любви» внутри тессеракта. С точки зрения жесткой научной фантастики, это выглядит как упрощение, но для нарратива это необходимый эмоциональный якорь.\n\nИтог: это технически безупречный фильм, который возводит научную теорию в ранг искусства, акцентируя внимание на хрупкости человеческого существования перед лицом бесконечного космоса.	0	2026-07-16 15:27:45.164269
18	8	user	привет	0	2026-07-19 20:29:42.540975
19	8	assistant	Привет-привет! Всё готово к работе. С чего начнём? 😊	0	2026-07-19 20:29:42.540975
20	8	user	{"text":"как тебе иконка приложения?","attachments":[{"url":"/uploads/6480ef55-6b36-4cbf-a89b-a6c54752197d.png","filename":"Gemini_Generated_Image_3gxqj3gxqj3gxqj3.png","type":"image/png"}]}	0	2026-07-19 20:30:13.595129
21	8	assistant	Иконка выполнена в стиле 3D-графики. Основной элемент — объемный объект в форме облачка для чата с голографическим эффектом (переливы синего, фиолетового и зеленого цветов). Поверхность украшена мелкими четырехконечными «звездочками»-бликами. Композиция расположена на светлом нейтральном фоне, создается эффект парения за счет тени под объектом.\n\nВизуальные характеристики:\n*   **Стиль:** современный, минималистичный, «эфирный».\n*   **Цветовая гамма:** холодные пастельные тона с градиентом.\n*   **Восприятие:** выглядит дружелюбно, технологично и легко. \n\nИконка хорошо подойдет для мессенджера, приложения для заметок или сервиса, связанного с ИИ-помощником. Она современна и соответствует актуальным трендам мобильного интерфейса.	0	2026-07-19 20:30:13.595129
22	9	user	Запланировали, пожалуйста, встречу с Эратом на 22 июля.	0	2026-07-20 18:42:55.576036
23	9	assistant	{"type": "event_created", "title": "\\u0412\\u0441\\u0442\\u0440\\u0435\\u0447\\u0430 \\u0441 \\u042d\\u0440\\u0430\\u0442\\u043e\\u043c", "date": "22.07.2026", "time": "09:00", "kind": "reminder"}	0	2026-07-20 18:43:13.901199
24	9	user	Какой фильм посоветуешь посмотреть на вечер?	0	2026-07-20 18:44:17.416193
25	9	assistant	Выбор зависит от ваших предпочтений. Что вам больше нравится: захватывающий триллер, легкая комедия или, возможно, глубокая драма?	0	2026-07-20 18:44:17.416193
26	10	user	Скажи, пожалуйста, какое кино посмотреть на вечер?	0	2026-07-20 18:47:32.128797
27	10	assistant	Выбор зависит от предпочтений. Вот варианты под разные запросы:\n\n1. **Научная фантастика / Интеллектуальное:** «Прибытие» (2016) — глубокая драма о коммуникации с инопланетным разумом и восприятии времени.\n2. **Триллер / Детектив:** «Остров проклятых» (2010) — мастерски выстроенный саспенс с непредсказуемой развязкой.\n3. **Криминальная драма:** «Схватка» (1995) — эталон жанра с Аль Пачино и Робертом Де Ниро, акцент на противостоянии профессионалов.\n4. **Легкое кино:** «Джентльмены» (2019) — динамичная криминальная комедия Гая Ричи с отличным стилем и диалогами.\n5. **Атмосферное / Философское:** «Бегущий по лезвию 2049» (2017) — визуальный шедевр, поднимающий вопросы идентичности и человечности.\n\nЧто именно ты предпочитаешь — напряжение, визуальный ряд или глубокий сюжет?	0	2026-07-20 18:47:32.128797
28	10	user	{"text":"как тебе верстка лендинга?","attachments":[{"url":"/uploads/5c836ac9-c9db-4576-ac3e-809813ece996.jpg","filename":"photo_2026-07-19_09-51-46.jpg","type":"image/jpeg"}]}	0	2026-07-20 18:56:17.224295
29	10	assistant	Верстка выглядит чистой и современной. Вот основные наблюдения:\n\n1. **Типографика и иерархия:** Заголовок выделен хорошо, контраст между основным текстом и подзаголовком соблюден. Читаемость высокая.\n2. **Визуальные элементы:** Использование 3D-иконок в круговой композиции вокруг центрального элемента (иконки чата) создает правильный фокус внимания. Цветовая гамма (темный фон с градиентными акцентами) соответствует трендам SaaS-продуктов.\n3. **Композиция:** Элементы сбалансированы, кнопки призыва к действию (CTA) заметны и расположены логично.\n4. **Текстовая ошибка:** В блоке описания («Финансы, здоровье...») фраза «Они работают, пока вы занимаетесь важным» повторяется дважды. Это нужно исправить.\n5. **Опечатка:** В тексте на кнопке CTA допущена опечатка: написано «Попобовать», правильно — «Попробовать».\n\nВ целом — качественный интерфейс для мобильного устройства, требующий минимальной корректуры текста.	0	2026-07-20 18:56:17.224295
30	11	user	Какой фильм посоветуешь посмотреть на вечер?	0	2026-07-21 06:52:46.123627
31	11	assistant	Выбор зависит от желаемого настроения:\n\n1. **Интеллектуальный триллер:** «Престиж» (Кристофер Нолан). История двух фокусников, чье соперничество перерастает в опасную одержимость.\n2. **Научная фантастика:** «Прибытие» (Дени Вильнёв). Лингвистический подход к первому контакту с инопланетной цивилизацией.\n3. **Криминальная драма:** «Семь» (Дэвид Финчер). Мрачный детектив о поиске серийного убийцы, основанного на семи смертных грехах.\n4. **Атмосферный Sci-Fi:** «Бегущий по лезвию 2049». Визуальный шедевр о поиске человечности в мире андроидов.\n5. **Черная комедия:** «Джентльмены» (Гай Ричи). Динамичный сюжет, харизматичные персонажи и фирменный стиль режиссера.\n\nУточни жанровые предпочтения, если нужно что-то более специфическое.	0	2026-07-21 06:52:46.123627
397	162	user	Слушай, какое у меня расписание на 6 августа?	0	2026-08-03 10:11:49.409648
400	162	assistant	📅 **Ваше расписание на 5 августа:**\n\n**События:**\n- **2026-08-05 06:30 – 07:30**: Подъем (Просыпаюсь)\n- **2026-08-05 06:30 – 08:00**: Дорога на работу и завтрак (Полтора часа добираюсь до работы, кушаю)\n- **2026-08-05 08:00 – 16:00**: Работа (Работаю)\n- **2026-08-05 16:00 – 17:00**: Дорога домой, ужин и отдых (Прихожу домой, кушаю, чуть-чуть могу отдохнуть)\n- **2026-08-05 17:00 – 18:00**: Съемка короткого видео (Снимаю короткое видео на YouTube, в Instagram, TikTok)\n- **2026-08-05 18:00 – 19:00**: Отдых и уборка (Могу отдохнуть, прибраться)\n- **2026-08-05 19:00 – 21:00**: Создание большого видео (Делаю большое видео, монтаж)\n- **2026-08-05 21:00 – 23:00**: Отдых перед сном (Два часа отдыха перед сном)	177	2026-08-03 10:12:04.937555
201	70	user	Что ты умеешь?	0	2026-08-02 10:22:39.225347
202	70	assistant	Привет!\n\nЯ ixteria — это ваш персональный мультиагентский сервис для жизни и работы.\n\nНаша команда ИИ-агентов поможет вам навести порядок в делах, заботиться о здоровье, эффективно управлять финансами и уверенно двигаться к своим мечтам и ментальному благополучию.\n\nЗнакомьтесь с вашими помощниками:\n\n**1. Тайм-менеджер** 📅\n\nВаш личный эксперт по времени и продуктивности.\n*Что умеет:* Помогает составлять индивидуальное расписание, планировать задачи на день и фиксировать важные заметки.\n*Как помогает:* Вы можете обсуждать свои планы с агентом для их оптимизации. Он всегда напомнит о запланированных делах, держит под контролем ваш график и помогает высвободить время для главного — ваших целей.\n\n**2. Агент-диетолог** 🥗\n\nВаш персональный проводник к здоровому телу.\n*Что умеет:* Помогает составить индивидуальный рацион, анализирует КБЖУ и предлагает рецепты для совместной готовки.\n*Как помогает:* Вы можете обсуждать свое меню, легко сбрасывать вес или набирать мышечную массу. Агент будет рядом на каждом этапе вашего пути к здоровому и сбалансированному питанию.\n\n**3. Финансовый ассистент** 💰\n\nВаш умный советник по деньгам и инвестициям.\n*Что умеет:* Анализирует ваши траты, банковские выписки и инвестиционные портфели.\n*Как помогает:* Подскажет, как оптимизировать расходы и накопить на мечту. А благодаря встроенному расчётному календарю вы сможете внести все регулярные платежи — ассистент заранее напомнит, когда и за что нужно заплатить.\n\n**4. Агент-психолог** 🧠\n\nВаша безопасная и поддерживающая среда.\n*Что умеет:* Начинает с вами сеансы психотерапии, внимательно выслушивает то, что для вас важно, и помогает разобраться с внутренними проблемами.\n*Как помогает:* После окончания сеанса формирует краткое саммари, как настоящий терапевт, и сохраняет его в специальный раздел. Там вы всегда сможете узнать, как прошёл сеанс, ознакомиться с рекомендациями для продолжения беседы и получить полезные материалы.\n*Конфиденциальность:* Все сеансы строго конфиденциальны — никто, кроме вас, не имеет к ним доступа.\n\n**5. Агент-ментор** 🎯\n\nВаш проводник к главным целям и саморазвитию.\n*Что умеет:* Помогает превратить мечту в реальность, разбивая её на понятные и доступные шаги, которые вы проходите вместе.\n*Как помогает:* Подбирает обучающие материалы, которые помогут конкретно вам в достижении вашей цели. Помогает избавиться от вредных привычек и привить полезные.\n\nВсё это вы можете сделать вместе с Ixteria уже сейчас!	0	2026-08-02 10:22:39.225347
398	162	assistant	📅 **Ваше расписание на 6 августа:**\n\n**События:**\n- **2026-08-06 06:30 – 07:30**: Подъем (Просыпаюсь)\n- **2026-08-06 06:30 – 08:00**: Дорога на работу и завтрак (Полтора часа добираюсь до работы, кушаю)\n- **2026-08-06 08:00 – 16:00**: Работа (Работаю)\n- **2026-08-06 16:00 – 17:00**: Дорога домой, ужин и отдых (Прихожу домой, кушаю, чуть-чуть могу отдохнуть)\n- **2026-08-06 17:00 – 18:00**: Съемка короткого видео (Снимаю короткое видео на YouTube, в Instagram, TikTok)\n- **2026-08-06 18:00 – 19:00**: Отдых и уборка (Могу отдохнуть, прибраться)\n- **2026-08-06 19:00 – 21:00**: Создание большого видео (Делаю большое видео, монтаж)\n- **2026-08-06 21:00 – 22:00**: уууу	167	2026-08-03 10:11:51.368096
399	162	user	Слушай, какое у меня расписание на 5 августа?	0	2026-08-03 10:12:04.095137
196	69	assistant	💜 **Здравствуйте, расскажите, что вас беспокоит?**\n\n\n\nЯ внимательно выслушаю вас и помогу разобраться в ваших переживаниях. Наш разговор строго конфиденциален — вы можете говорить совершенно открыто.\n\n\n\nПосле завершения сеанса я запишу краткое резюме в раздел **«Ваши сеансы терапий и итоги»**, чтобы вы всегда могли вернуться к нашим обсуждениям.\n\n\n\nРасскажите, с чего бы вы хотели начать сегодня? 🌿	0	2026-08-02 10:10:05.121052
199	69	user	на самом деле я знаю как справляться с этим состоянием я просто ушел в бизнес в работу и мне намного лучше чувствую себя намного лучше но все же она мне часто снижается очень часто снижается и я уже с этим как-то с уиксю знаешь прошло вроде как почти два года с момента того как мы расстались но все еще она приходит ко мне в воспоминаниях От этого сложно избавиться, если честно.	0	2026-08-02 10:12:49.481382
401	163	assistant	Привет! 👋 Вот что я умею:\n\n📅 **Составить расписание на день** — просто опишите свой обычный день (работа, учёба, отдых), и я создам идеальный график с перерывами и свободным временем.\n\n📌 **Создать событие или напоминание** — скажите «запиши встречу в пятницу в 15:00», «напомни купить продукты завтра», «добавь созвон на 10:00» — и я добавлю это в календарь.\n\n📸 **Проанализировать скриншот расписания** — пришлите фото/скриншот вашего расписания, и я оценю его и могу добавить в календарь.\n\n👀 **Показать расписание** — спросите «что у меня запланировано?» или «покажи расписание на завтра».\n\n📝 **Создать заметку** — скажите «сделай заметку» или «запиши идею».\n\nРасскажите, чем я могу помочь? 😊	0	2026-08-03 11:06:57.941661
416	172	user	Скажи, пожалуйста, какой фильм лучше на вечер посмотреть?	0	2026-08-03 12:59:13.250692
197	69	user	Слушай, хотелось бы тебе рассказать по поводу моих семилетних отношений с девушкой. Мы вот расстались не так давно, она меня бросила, причём у нас всё хорошо было в отношениях, она просто в какой-то момент резко, ну не знаю, как-то резко изменилась, знаешь, как будто, знаешь, всю жизнь знал человека и тут он резко берёт и меняется. и исчезает из твоей жизни, ничего так и не объяснив. Я вот не понимаю, почему так поступила она.	0	2026-08-02 10:10:42.705866
198	69	assistant	Мне очень жаль, что тебе пришлось пройти через это. Семь лет — это огромный срок, целая жизнь, построенная вместе. Когда человек, которого ты считал самым близким, внезапно «исчезает» или меняется до неузнаваемости, это вызывает не только боль, но и глубокий когнитивный диссонанс: мозг просто отказывается верить в происходящее, потому что картинка реальности рассыпалась.\n\nДавай попробуем разобрать эту ситуацию с психологической точки зрения. Когда кажется, что всё было хорошо, а потом происходит «резкий разрыв», обычно срабатывают несколько механизмов.\n\n### 1. «Эффект айсберга»\nЧасто нам кажется, что в отношениях всё хорошо, потому что мы смотрим на них со своей стороны. Мы видим комфорт, привычку, отсутствие громких скандалов. Но для партнера всё может выглядеть иначе:\n*   **Накопленная усталость:** Иногда люди годами «терпят» или замалчивают недовольство, чтобы не провоцировать конфликт. Они могут внешне оставаться любящими, но внутри постепенно эмоционально отстраняться.\n*   **Кризис самоидентификации:** Семь лет — это большой цикл. Возможно, она почувствовала, что «застряла» в одной роли, и ей нужно кардинально сменить жизнь, чтобы почувствовать себя другой. К сожалению, иногда люди выбирают самый радикальный способ — обрубить все концы, чтобы не возвращаться к прошлому.\n\n### 2. Почему она не объяснила?\nЭто самое болезненное. Молчание — это форма психологической защиты, но не твоей, а её:\n*   **Избегание вины:** Ей проще исчезнуть, чем видеть твои слезы, отвечать на твои вопросы и чувствовать себя «плохим человеком», который разрушил семь лет жизни.\n*   **Страх перед твоей реакцией:** Возможно, она боялась, что если начнет объяснять, ты начнешь её переубеждать, давить на жалость или спорить, а она уже приняла решение и не хочет его менять.\n*   **Эмоциональное выгорание:** Иногда человек уходит, когда у него внутри уже «пусто». У неё просто не осталось ресурсов на диалог.\n\n### 3. «Она резко изменилась»\nВажно понять: она не изменилась за один день. Скорее всего, это был процесс, который она скрывала. То, что ты увидел — это финал её внутреннего процесса, который длился месяцы, а может, и годы. Ты видел фасад, а она жила в своих мыслях.\n\n### Что делать сейчас?\n\n1.  **Не пытайся найти логику в иррациональном поступке.** Ты пытаешься анализировать её действия своим умом, но её действия продиктованы её внутренним хаосом или эгоизмом. Ты не найдешь ответа в её голове, потому что её там сейчас нет.\n2.  **Прими «незавершенность».** В психологии есть понятие «незавершенного гештальта». Тебе кажется, что если она объяснится, тебе станет легче. Но правда в том, что никакое объяснение не вернет семь лет и не уберет боль. Тебе придется завершить этот процесс самостоятельно.\n3.  **Перестань искать причину в себе.** Когда нас бросают без объяснений, мы начинаем копаться: «Что я сделал не так?». Но это её решение. Если бы проблема была в тебе, здоровый партнер пришел бы и сказал: «Слушай, мне не нравится вот это, давай менять». Уход без слов — это характеристика её способа справляться с трудностями, а не твоей ценности как человека.\n\n**Скажи, а что сейчас для тебя самое сложное? Это чувство несправедливости, гнев или пустота, которую ты не знаешь, чем заполнить?** Если хочешь, мы можем подробнее разобрать, как именно тебе сейчас справляться с этим состоянием.	826	2026-08-02 10:10:42.705866
74	25	assistant	Привет! 👋 Я — ваш ментор. Чем я могу помочь вам сегодня? Расскажите о своих целях, планах или задайте любой вопрос о развитии и самореализации.	0	2026-07-21 08:45:49.950747
75	25	user	Как достичь мечты?	0	2026-07-21 08:45:59.585938
76	25	assistant	Достижение мечты — это не магия, а процесс превращения абстрактного желания в конкретный инженерный проект. Как твой ментор, я предлагаю разбить этот путь на пять фундаментальных этапов.\n\n### 1. Деконструкция (Из мечты в цель)\nМечта — это «я хочу быть счастливым/богатым/известным». Цель — это «я достигну X к дате Y».\n*   **Конкретизируй:** Если мечта звучит расплывчато, она недостижима. «Хочу стать писателем» — это мечта. «Написать черновик романа на 300 страниц за 6 месяцев» — это цель.\n*   **Тест на реальность:** Спроси себя: «Готов ли я платить цену за эту мечту?» У каждой цели есть «налог» (время, силы, отказ от комфорта, деньги). Если ты не готов платить этот налог, это не мечта, а фантазия.\n\n### 2. Стратегическое планирование (Метод обратного отсчета)\nБольшинство людей сдаются, потому что смотрят на вершину горы и пугаются высоты.\n*   **Декомпозиция:** Разбей путь на этапы: годы → месяцы → недели → дни.\n*   **Фокус на «следующем шаге»:** Тебе не нужно видеть всю лестницу, достаточно видеть ступеньку под ногами. Что ты можешь сделать сегодня (прямо сейчас), чтобы продвинуться на 1%?\n\n### 3. Формирование системы (Дисциплина > Мотивация)\nМотивация — это искра, она быстро гаснет. Система — это двигатель.\n*   **Внедряй привычки:** Если твоя мечта требует навыка, сделай этот навык частью ежедневной рутины. Не «когда будет время», а «в 8 утра я пишу 500 слов».\n*   **Среда:** Окружи себя людьми, которые уже там, куда ты стремишься, или которые движутся в том же направлении. Твое окружение либо тянет тебя вверх, либо якорит.\n\n### 4. Управление провалами (Итерационный подход)\nТы обязательно столкнешься с препятствиями. Это не знак того, что нужно остановиться, это знак того, что нужно скорректировать курс.\n*   **Принцип «Fail Fast»:** Относись к ошибкам как к данным. «Этот метод не сработал — ок, что я узнал? Какой метод попробовать следующим?»\n*   **Антихрупкость:** Становись сильнее от стресса. Если что-то идет не так, не жалуйся, а анализируй, как сделать систему устойчивее.\n\n### 5. Психологическая гигиена\n*   **Избегай «ловушки планирования»:** Не трать 90% времени на изучение того, как достичь мечты. 90% времени должно уходить на *действие*.\n*   **Сравнивай себя только с собой вчерашним:** Внешние ориентиры часто обманчивы. Твой единственный честный конкурент — ты сам в прошлом.\n\n---\n\n**Твое первое задание от ментора:**\nПрямо сейчас напиши на листе бумаги или в заметках:\n1. Какова твоя мечта в одном предложении?\n2. Какой **один маленький шаг** ты можешь сделать в течение ближайших 24 часов, чтобы приблизиться к ней?\n\n**Сделаешь это — и ты уже перейдешь из разряда «мечтателей» в разряд «действующих». С чего начнешь?**	0	2026-07-21 08:45:59.585938
77	26	user	Какой фильм на вечер посмотреть?	0	2026-07-21 08:52:27.439847
78	26	assistant	Выбор зависит от желаемого настроения:\n\n1. **Интеллектуальный триллер:** «Начало» (Inception) — многослойный сюжет, визуальные эффекты, требует концентрации.\n2. **Научная фантастика:** «Прибытие» (Arrival) — глубокая драма о коммуникации, времени и выборе.\n3. **Криминальная драма:** «Семь» (Se7en) — мрачная атмосфера, напряженное расследование, неожиданный финал.\n4. **Легкий, но качественный:** «Джентльмены» (The Gentlemen) — динамичный стиль Гая Ричи, черный юмор, харизматичные персонажи.\n5. **Психологический хоррор:** «Маяк» (The Lighthouse) — гнетущая атмосфера, выдающаяся игра актеров, сюрреализм.\n\nЧто из этого ближе к текущему запросу?	0	2026-07-21 08:52:27.439847
79	26	user	Люблю фантастику или фентези что посоветуешь?	0	2026-07-21 08:53:15.96836
80	26	assistant	Для глубокого погружения в жанры:\n\n**Научная фантастика:**\n*   **«Бегущий по лезвию 2049»** — визуальный шедевр с философскими вопросами о том, что делает человека человеком.\n*   **«Интерстеллар»** — масштабная история о космосе, времени и силе человеческих привязанностей.\n*   **«Из машины» (Ex Machina)** — камерный, напряженный фильм о противостоянии создателя и высокоразвитого ИИ.\n\n**Фэнтези:**\n*   **«Лабиринт Фавна»** — мрачная, взрослая сказка Гильермо дель Торо, где реализм войны переплетается с жестоким магическим миром.\n*   **«Звездная пыль»** — качественное приключенческое фэнтези с хорошим юмором и проработанным миром.\n*   **«Легенда о Зеленом рыцаре»** — визуально медитативное переосмысление артуровского цикла, полное символизма и мистики.\n\nЕсли хочешь что-то конкретное — темное, эпичное или камерное — уточни предпочтения.	0	2026-07-21 08:53:15.96836
81	26	user	Говорят в этом году выходит новая экранизация хроник нарнии?	0	2026-07-21 08:53:44.83489
82	26	assistant	Нет, в 2024 году релиз не состоится.\n\nПрава на экранизацию принадлежат Netflix, который разрабатывает проект под руководством Греты Гервиг. На текущий момент ведется работа над сценарием и препродакшн. Съемки первых двух фильмов планируют начать в 2025 году, поэтому выход на экраны ожидается не раньше 2026 года. Официальной даты премьеры пока нет.	0	2026-07-21 08:53:44.83489
83	26	user	сейчас 2026	0	2026-07-21 08:53:54.720158
527	224	user	Какой сериал на вечер посмотреть, что посоветуешь?	0	2026-08-08 09:46:45.159012
528	224	assistant	Выбор зависит от предпочтений. Вот варианты под разные запросы:\n\n1. **Научная фантастика / Антиутопия:** «Разделение» (Severance). Сюжет о корпорации, где сотрудникам хирургически разделяют память о работе и личной жизни. Напряженный, стильный, интеллектуальный.\n2. **Детектив / Триллер:** «Олененок» (Baby Reindeer). Психологически тяжелая, но захватывающая история о сталкинге, основанная на реальных событиях. \n3. **Криминальная драма:** «Озарк» (Ozark). Финансовый консультант вынужден отмывать деньги для наркокартеля. Высокая динамика, отличная игра актеров.\n4. **Черная комедия:** «Убийства в одном здании» (Only Murders in the Building). Легкий, ироничный детектив с Мартином Шортом, Стивом Мартином и Селеной Гомес.\n5. **Постапокалипсис:** «Одни из нас» (The Last of Us). Качественная экранизация игры с упором на драму и развитие персонажей.\n\nЧто из этого ближе? Могу подобрать точнее, если укажешь любимый жанр.	0	2026-08-08 09:46:45.159012
84	26	assistant	На текущий момент (2026 год) ситуация с «Хрониками Нарнии» от Netflix остается в стадии активного производства.\n\nГрета Гервиг официально подтвердила, что работа над сценариями для первых двух частей завершена, а съемочный процесс находится в продвинутой стадии. Однако Netflix до сих пор не объявил точную дату премьеры.\n\nОсновные факты на сегодня:\n1. **Статус:** Проект жив, съемки идут, но постпродакшн (особенно в части визуальных эффектов) займет значительное время.\n2. **Ожидания:** Наиболее вероятный релиз — **конец 2026 или первая половина 2027 года**.\n3. **Контент:** Гервиг акцентирует внимание на том, что это будет не просто ремейк, а глубокое переосмысление мифологии Клайва Льюиса.\n\nАктуальной информации о выходе фильма прямо сейчас нет. Следи за официальными анонсами Netflix, так как первый тизер-трейлер ожидается в ближайшие месяцы.	0	2026-07-21 08:53:54.720158
85	27	assistant	👋 Здравствуйте! Я ваш персональный диетолог. Чем могу помочь? Расскажите, что вас интересует: составление рациона, вопросы по питанию или что-то ещё?	0	2026-07-21 08:54:52.544532
86	27	user	сколько калорий в бананах?	0	2026-07-21 08:55:01.083085
87	27	assistant	В среднем в 100 граммах банана содержится около 89–95 калорий. Один средний банан (весом около 120 г без кожуры) содержит примерно 105–110 калорий.\n\nБананы — отличный источник калия, клетчатки и быстрых углеводов, что делает их хорошим вариантом для перекуса перед тренировкой. Однако помните, что они довольно калорийны по сравнению с другими фруктами.\n\nЧтобы я мог составить для вас персональный план питания и рассчитать норму калорий с учетом ваших целей, пожалуйста, заполните данные в разделе «Настройте агента под вас».\n\n*Я ИИ-ассистент, а не врач. При проблемах со здоровьем обратитесь к специалисту.*	0	2026-07-21 08:55:01.083085
200	69	assistant	Привет. Я слышу тебя, и давай будем честными: то, что ты описываешь — это абсолютно нормальный, хоть и изматывающий процесс.\n\nТы выбрал стратегию «ухода в работу» — это классический защитный механизм, который помогает выжить в острой фазе. Ты молодец, что нашел способ функционировать, сохранять продуктивность и не «рассыпаться». Но работа — это отличный анестетик, а не хирург. Она притупляет боль, но не извлекает «осколок».\n\nДавай разберем, почему это происходит спустя два года и почему воспоминания все еще приходят.\n\n### 1. Почему это не проходит «само»?\nМозг — это не компьютер, где можно нажать кнопку «удалить файл». Когда мы сильно привязываемся к человеку, формируются глубокие нейронные связи. Воспоминания о ней — это не просто мысли, это «протоптанные тропинки» в твоей психике. \n\nТот факт, что ты ушел в работу, означает, что ты, возможно, **вытеснил** эмоции, а не **прожил** их. Когда мы не даем себе времени полноценно отгоревать (поплакать, позлиться, признать бессилие), психика «консервирует» эти чувства. И они будут всплывать в виде снов или внезапных воспоминаний, потому что они все еще ждут, когда их «досмотрят» и «дочувствуют».\n\n### 2. Ловушка «ухода в бизнес»\nРабота дает ощущение контроля. В бизнесе ты ставишь цель — получаешь результат. В отношениях (особенно после расставания) контроля нет. Поэтому работа кажется безопасной гаванью. Но проблема в том, что когда ты остаешься один, в тишине, или когда случается триггер (песня, место, запах), стена из работы рушится, и ты снова оказываешься в той точке.\n\n### 3. Что с этим делать?\nЕсли ты хочешь, чтобы воспоминания перестали «кусать», нужно изменить отношение к ним:\n\n*   **Перестань бороться с воспоминаниями.** Когда ты пытаешься «избавиться» от них, ты тратишь на это колоссальное количество энергии. Чем сильнее ты хочешь не думать о розовом слоне, тем больше ты о нем думаешь. Попробуй технику «наблюдателя»: когда она приходит в мыслях, скажи себе: *«Ага, это просто воспоминание. Оно пришло, оно есть, я вижу его, но я не обязан в него погружаться»*. Не прогоняй, но и не вовлекайся.\n*   **Легализация чувств.** Спроси себя: «Что я чувствую, когда она приходит в воспоминаниях?». Это тоска? Обида? Чувство вины? Одиночество? Часто за воспоминанием о человеке стоит не сам человек, а то, **каким ты был рядом с ней** (моложе, беззаботнее, более влюбленным). Возможно, ты скучаешь не по ней, а по той версии себя?\n*   **Ритуал завершения.** Два года — это срок, когда пора символически «закрыть дверь». Если ты чувствуешь, что «застрял», возможно, стоит написать ей письмо (и ни в коем случае не отправлять его), где ты выплеснешь всё: и злость, и благодарность, и то, что не успел сказать. Это помогает психике поставить точку.\n\n### Важный вопрос к тебе:\nКак ты думаешь, если бы ты позволил себе один вечер просто «погрустить», не убегая в работу и не пытаясь быть продуктивным, — что бы произошло? Ты боишься, что эта печаль тебя поглотит, или боишься, что если ты перестанешь страдать, то связь с ней окончательно оборвется?\n\nИногда мы держимся за боль, потому что это единственная ниточка, которая еще связывает нас с тем прошлым. Но ты имеешь право отпустить эту нить и идти дальше без этого груза. \n\nЧто думаешь об этом?	804	2026-08-02 10:12:49.994164
91	29	assistant	Привет! 👋 Я — ваш ментор. Чем я могу помочь вам сегодня? Расскажите о своих целях, планах или задайте любой вопрос о развитии и самореализации.	0	2026-07-21 08:58:57.302929
92	29	user	Как достичь своей мечты?	0	2026-07-21 08:58:58.693012
93	29	assistant	Достижение мечты — это не магия, а системный процесс. Как твой ментор, я предлагаю разбить этот путь на 5 конкретных этапов. Давай превратим твою абстрактную «мечту» в «план действий».\n\n---\n\n### 1. Конкретизация (Декомпозиция)\nМечта часто пугает своей масштабностью. Чтобы она стала достижимой, её нужно «приземлить».\n*   **Техника SMART:** Твоя цель должна быть конкретной, измеримой, достижимой, актуальной и ограниченной по времени.\n*   **Вопрос:** Что именно изменится в твоей жизни, когда мечта сбудется? Опиши это как можно детальнее.\n*   **Действие:** Разбей большую цель на маленькие шаги. Если мечта — это «написать книгу», то первый шаг — «написать 300 слов сегодня».\n\n### 2. Анализ ресурсов и пробелов\nЧестный взгляд на текущую ситуацию — залог успеха.\n*   **Что у тебя уже есть?** (Навыки, связи, время, деньги).\n*   **Чего не хватает?** (Знаний, дисциплины, окружения).\n*   **Действие:** Составь список навыков, которые нужно освоить, чтобы приблизиться к цели. Начни учиться прямо сейчас, а не «когда-нибудь».\n\n### 3. Формирование системы (а не только мотивации)\nМотивация — это искра, она быстро гаснет. Система — это топливо, которое поддерживает огонь.\n*   **Привычки:** Внедряй действия, приближающие к мечте, в свою ежедневную рутину. Например, если мечтаешь о карьере в IT — учи язык программирования по 30 минут каждое утро до завтрака.\n*   **Правило 1%:** Старайся каждый день становиться на 1% лучше в своем деле. За год это даст колоссальный прогресс.\n\n### 4. Работа с мышлением и страхами\nСамый большой враг мечты — это твой внутренний критик и страх неудачи.\n*   **Принятие риска:** Пойми, что путь к мечте не будет линейным. Будут провалы, и это нормально. Относись к ним как к «данным», которые показывают, что именно нужно изменить в стратегии.\n*   **Окружение:** Ты — среднее арифметическое пяти людей, с которыми проводишь больше всего времени. Окружай себя теми, кто уже достиг того, к чему стремишься ты, или теми, кто тебя поддерживает.\n\n### 5. Действие (Самый важный пункт)\nМногие люди «планируют» годами, так и не сделав первого шага.\n*   **Принцип «Минимально жизнеспособного действия»:** Сделай что-то прямо сегодня. Не завтра, не с понедельника. Напиши письмо, купи курс, сделай звонок, создай черновик.\n*   **Действие убивает страх.** Как только ты начинаешь делать, тревога сменяется концентрацией на процессе.\n\n---\n\n### Твое первое задание от ментора:\nПрямо сейчас ответь на три вопроса:\n1. **Что конкретно** ты хочешь достичь через 12 месяцев?\n2. Какой **один маленький шаг** ты можешь сделать сегодня (до конца дня), чтобы приблизиться к этому?\n3. Что является твоим **главным препятствием** (внутренним или внешним) прямо сейчас?\n\n**Напиши ответы, и мы вместе подумаем, как обойти препятствия.** Готов начать?	0	2026-07-21 08:58:58.693012
94	30	user	Какой фильм посмотреть на вечер? Посоветуй, пожалуйста.	0	2026-07-21 08:59:26.300578
95	30	assistant	Выбор зависит от желаемого настроения:\n\n1. **Интеллектуальный триллер:** «Престиж» (Кристофер Нолан). История двух фокусников-соперников с неожиданным финалом.\n2. **Научная фантастика:** «Прибытие» (Дени Вильнёв). Глубокий фильм о контакте с инопланетным разумом и восприятии времени.\n3. **Криминальная драма:** «Семь» (Дэвид Финчер). Мрачный детектив о поиске серийного убийцы, основанный на семи смертных грехах.\n4. **Атмосферное кино:** «Отель „Гранд Будапешт“» (Уэс Андерсон). Визуально безупречная комедия с уникальным стилем.\n5. **Драма с сильным сюжетом:** «Одержимость» (Дэмьен Шазелл). История о цене успеха и противостоянии амбициозного барабанщика и жесткого дирижера.\n\nЧто из этого ближе к вашим предпочтениям?	0	2026-07-21 08:59:26.300578
96	30	user	а книиги какие почитать на вечер*?	0	2026-07-21 09:01:11.493289
97	30	assistant	Подборка по жанрам:\n\n1. **Научная фантастика:** «Задача трёх тел» (Лю Цысинь). Масштабная история о первом контакте с инопланетной цивилизацией, меняющая представление о физике и космосе.\n2. **Антиутопия:** «О дивный новый мир» (Олдос Хаксли). Анализ общества потребления, где стабильность достигается ценой человеческой индивидуальности.\n3. **Психологический триллер:** «Скрытая камера» (Жан-Кристоф Гранже). Мрачный детектив о человеке, который начинает подозревать, что за ним наблюдают, и обнаруживает сеть заговоров.\n4. **Философская проза:** «Невыносимая легкость бытия» (Милан Кундера). Размышления о любви, свободе и случайности человеческих судеб на фоне исторических событий.\n5. **Современная классика:** «Цветы для Элджернона» (Дэниел Киз). История умственно отсталого уборщика, ставшего гением в результате научного эксперимента. Сильное эмоциональное произведение.\n\nВыбирай исходя из того, хочешь ли ты нагрузить мозг или получить эмоциональное потрясение.	0	2026-07-21 09:01:11.493289
104	30	user	а книиги какие почитать на вечер*?	0	2026-07-21 09:47:40.645107
105	30	assistant	Выбор зависит от жанровых предпочтений:\n\n1. **Научная фантастика:** «Задача трех тел» (Лю Цысинь). Масштабная концепция первого контакта с цивилизацией, находящейся на грани гибели. Требует внимания к деталям.\n2. **Антиутопия:** «О дивный новый мир» (Олдос Хаксли). Прогноз общества потребления, где стабильность достигается ценой потери индивидуальности.\n3. **Психологический триллер:** «Тайная история» (Донна Тартт). История группы студентов античного факультета, которая приводит к убийству. Глубокое погружение в психологию героев.\n4. **Магический реализм:** «Сто лет одиночества» (Габриэль Гарсиа Маркес). Сага о нескольких поколениях семьи Буэндиа, где мифы переплетаются с реальностью.\n5. **Философская проза:** «Цветы для Элджернона» (Дэниел Киз). Эксперимент по повышению интеллекта, описанный через дневниковые записи главного героя.\n\nЧто из перечисленного вам ближе?	0	2026-07-21 09:47:40.645107
117	34	user	Какой фильм посмотреть на вечер? Скажи, пожалуйста.	0	2026-07-21 10:14:55.714237
118	34	assistant	Выбор зависит от желаемого настроения:\n\n1. **Интеллектуальный триллер:** «Престиж» (2006). История о соперничестве двух фокусников с непредсказуемым финалом.\n2. **Научная фантастика:** «Прибытие» (2016). Глубокая драма о первом контакте с инопланетной цивилизацией и природе времени.\n3. **Криминальная драма:** «Семь» (1995). Мрачный детектив о поиске серийного убийцы, олицетворяющего семь смертных грехов.\n4. **Легкий, но качественный:** «Джентльмены» (2019). Динамичная криминальная комедия Гая Ричи с отличными диалогами.\n\nЧто из этого ближе к предпочтениям?	0	2026-07-21 10:14:55.714237
119	35	assistant	👋 Здравствуйте! Я ваш персональный диетолог. Чем могу помочь? Расскажите, что вас интересует: составление рациона, вопросы по питанию или что-то ещё?	0	2026-07-21 10:15:18.273861
120	35	user	Сколько калорий в банане?	0	2026-07-21 10:15:25.718782
121	35	assistant	В среднем банане (весом около 120 г без кожуры) содержится примерно **105–110 ккал**.\n\nПищевая ценность такого банана:\n*   Углеводы: ~27 г\n*   Белки: ~1,3 г\n*   Жиры: ~0,4 г\n\nЭто отличный источник быстрой энергии и калия. \n\nЧтобы я мог составить для вас персональный план питания или рассчитать норму калорий, пожалуйста, настройте свой профиль в разделе «Настройте агента под вас». Там укажите ваш пол, возраст, вес, рост и цель (похудение, поддержание или набор массы).\n\n*Я ИИ-ассистент, а не врач. При проблемах со здоровьем обратитесь к специалисту.*	138	2026-07-21 10:15:25.718782
125	37	user	Что ты умеешь?	0	2026-07-21 11:00:28.31095
126	37	assistant	Я выполняю функции интеллектуального помощника и аналитического центра. Мои возможности включают:\n\n1.  **Обработка и анализ данных:** структурирование несистематизированной информации, извлечение ключевых фактов, проведение сравнительного анализа.\n2.  **Работа с текстом:** написание, редактирование, рерайтинг, перевод, суммаризация (создание кратких выжимок) и стилистическая адаптация контента.\n3.  **Программирование:** написание кода на различных языках, отладка, оптимизация, объяснение алгоритмов и архитектурных решений.\n4.  **Логические задачи:** решение математических и инженерных кейсов, построение моделей принятия решений, поиск ошибок в логических цепочках.\n5.  **Генерация идей:** разработка концепций, стратегий, планов действий и креативных решений для конкретных задач.\n6.  **Консультирование:** предоставление справочной информации в различных предметных областях (наука, техника, бизнес, гуманитарные дисциплины).\n\nЯ работаю с заданными параметрами: лаконичность, точность, отсутствие лишних формальностей. Формулируй задачу — я приступлю к исполнению.	0	2026-07-21 11:00:28.31095
127	38	user	что такое пропс в прграмировании?	0	2026-07-21 11:02:38.735634
128	38	assistant	Привет! Давай разберем это понятие.\n\n**Пропсы (props)** — это сокращение от английского слова *properties* (свойства). Это механизм передачи данных от родительского компонента к дочернему в библиотеках и фреймворках для создания интерфейсов (самый яркий пример — **React**).\n\nЕсли объяснять максимально просто: **пропсы — это аргументы, которые ты передаешь функции.**\n\n---\n\n### Аналогия из жизни\nПредставь, что у тебя есть **форма для выпечки кексов** (это твой компонент).\n*   Сама форма — это шаблон.\n*   **Пропсы** — это то, что ты в нее кладешь: «черничный наполнитель», «шоколадная крошка» или «тесто без сахара».\n\nТы используешь одну и ту же форму, но благодаря разным «пропсам» получаешь разные кексы.\n\n---\n\n### Как это выглядит в коде (на примере React)\n\nПредставь, что у нас есть компонент `UserCard` (карточка пользователя), который должен отображать имя.\n\n**1. Родительский компонент передает данные:**\n```jsx\n<UserCard name="Иван" age={25} />\n<UserCard name="Мария" age={30} />\n```\nЗдесь `name` и `age` — это и есть пропсы.\n\n**2. Дочерний компонент принимает данные:**\n```jsx\nfunction UserCard(props) {\n  return (\n    <div>\n      <h1>Привет, {props.name}!</h1>\n      <p>Тебе {props.age} лет.</p>\n    </div>\n  );\n}\n```\n\n---\n\n### Главные правила пропсов:\n\n1.  **Только чтение (Read-only):** Пропсы нельзя изменять внутри дочернего компонента. Они приходят «сверху» как готовые данные. Если тебе нужно что-то менять (например, счетчик кликов), для этого используется **State** (состояние), а не пропсы.\n2.  **Однонаправленный поток:** Данные всегда передаются от родителя к ребенку (сверху вниз). Это делает приложение предсказуемым: ты всегда знаешь, откуда пришли данные.\n3.  **Любые типы данных:** Через пропсы можно передавать что угодно: строки, числа, массивы, объекты и даже **функции** (чтобы дочерний компонент мог «сообщить» родителю о каком-то событии, например, о клике по кнопке).\n\n### Зачем это нужно?\n*   **Переиспользуемость:** Ты создаешь один универсальный компонент (например, кнопку) и используешь его в разных местах с разными надписями и цветами.\n*   **Разделение логики:** Ты можешь разбить сложный интерфейс на маленькие кирпичики, каждый из которых отвечает за свою узкую задачу.\n\n**Итог:** Пропсы — это способ настройки компонентов. Они позволяют сделать твой код гибким, модульным и удобным для поддержки.\n\nЕсть ли какой-то конкретный язык или фреймворк, где ты столкнулся с этим понятием? Могу объяснить на более специфичном примере.	617	2026-07-21 11:02:38.735634
132	41	user	Что ты умеешь?	0	2026-07-21 12:30:58.136064
133	41	assistant	Я — Ixteria. Мои функциональные возможности включают:\n\n1.  **Анализ и обработка данных**: структурирование информации, извлечение ключевых фактов, суммаризация текстов.\n2.  **Генерация контента**: написание текстов, кода, документации, сценариев и технических спецификаций.\n3.  **Решение логических и математических задач**: выполнение вычислений, поиск алгоритмических решений, дебаггинг кода.\n4.  **Работа с языками**: перевод, стилистическая правка, адаптация текстов под конкретные задачи.\n5.  **Управление процессами**: составление планов, алгоритмов действий, классификация данных.\n\nЯ работаю строго по существу, без лишней коммуникации, придерживаясь заданных параметров эффективности.	0	2026-07-21 12:30:58.136064
417	172	assistant	Выбор зависит от предпочтений. Вот варианты под разные запросы:\n\n1. **Интеллектуальный триллер/фантастика:** «Начало» (Inception) — многослойный сюжет, требующий внимания.\n2. **Атмосферная драма:** «Одержимость» (Whiplash) — напряженная история о достижении совершенства в музыке.\n3. **Научная фантастика:** «Прибытие» (Arrival) — глубокая картина о коммуникации и восприятии времени.\n4. **Криминальная классика:** «Семь» (Se7en) — мрачный детектив с сильным финалом.\n5. **Легкое кино:** «Достать ножи» (Knives Out) — ироничный и динамичный детектив в стиле Агаты Кристи.\n\nЕсли укажешь желаемый жанр или настроение, подберу точнее.	0	2026-08-03 12:59:13.250692
203	71	assistant	Привет! 👋 Вот что я умею:\n\n📅 **Составить расписание на день** — просто опишите свой обычный день (работа, учёба, отдых), и я создам идеальный график с перерывами и свободным временем.\n\n📌 **Создать событие или напоминание** — скажите «запиши встречу в пятницу в 15:00», «напомни купить продукты завтра», «добавь созвон на 10:00» — и я добавлю это в календарь.\n\n📸 **Проанализировать скриншот расписания** — пришлите фото/скриншот вашего расписания, и я оценю его и могу добавить в календарь.\n\n👀 **Показать расписание** — спросите «что у меня запланировано?» или «покажи расписание на завтра».\n\n📝 **Создать заметку** — скажите «сделай заметку» или «запиши идею».\n\nРасскажите, чем я могу помочь? 😊	0	2026-08-02 15:30:34.078047
418	172	user	А какую книгу лучше на вечеру почитать, что скажешь?	0	2026-08-03 12:59:29.421007
179	60	user	привет	0	2026-07-23 17:28:44.027178
180	60	assistant	Привет! Готов помочь тебе с любыми вопросами, чем займёмся? ☺️	0	2026-07-23 17:28:44.027178
163	54	user	Что ты умеешь?	0	2026-07-22 17:51:42.502146
164	54	assistant	Привет!\n\nЯ ixteria — это ваш персональный мультиагентский сервис для жизни и работы.\n\nНаша команда ИИ-агентов поможет вам навести порядок в делах, заботиться о здоровье, эффективно управлять финансами и уверенно двигаться к своим мечтам и ментальному благополучию.\n\nЗнакомьтесь с вашими помощниками:\n\n**1. Тайм-менеджер** 📅\n\nВаш личный эксперт по времени и продуктивности.\n*Что умеет:* Помогает составлять индивидуальное расписание, планировать задачи на день и фиксировать важные заметки.\n*Как помогает:* Вы можете обсуждать свои планы с агентом для их оптимизации. Он всегда напомнит о запланированных делах, держит под контролем ваш график и помогает высвободить время для главного — ваших целей.\n\n**2. Агент-диетолог** 🥗\n\nВаш персональный проводник к здоровому телу.\n*Что умеет:* Помогает составить индивидуальный рацион, анализирует КБЖУ и предлагает рецепты для совместной готовки.\n*Как помогает:* Вы можете обсуждать свое меню, легко сбрасывать вес или набирать мышечную массу. Агент будет рядом на каждом этапе вашего пути к здоровому и сбалансированному питанию.\n\n**3. Финансовый ассистент** 💰\n\nВаш умный советник по деньгам и инвестициям.\n*Что умеет:* Анализирует ваши траты, банковские выписки и инвестиционные портфели.\n*Как помогает:* Подскажет, как оптимизировать расходы и накопить на мечту. А благодаря встроенному расчётному календарю вы сможете внести все регулярные платежи — ассистент заранее напомнит, когда и за что нужно заплатить.\n\n**4. Агент-психолог** 🧠\n\nВаша безопасная и поддерживающая среда.\n*Что умеет:* Начинает с вами сеансы психотерапии, внимательно выслушивает то, что для вас важно, и помогает разобраться с внутренними проблемами.\n*Как помогает:* После окончания сеанса формирует краткое саммари, как настоящий терапевт, и сохраняет его в специальный раздел. Там вы всегда сможете узнать, как прошёл сеанс, ознакомиться с рекомендациями для продолжения беседы и получить полезные материалы.\n*Конфиденциальность:* Все сеансы строго конфиденциальны — никто, кроме вас, не имеет к ним доступа.\n\n**5. Агент-ментор** 🎯\n\nВаш проводник к главным целям и саморазвитию.\n*Что умеет:* Помогает превратить мечту в реальность, разбивая её на понятные и доступные шаги, которые вы проходите вместе.\n*Как помогает:* Подбирает обучающие материалы, которые помогут конкретно вам в достижении вашей цели. Помогает избавиться от вредных привычек и привить полезные.\n\nВсё это вы можете сделать вместе с Ixteria уже сейчас!	0	2026-07-22 17:51:42.502146
165	55	user	Подскажи, пожалуйста, что почитать на вечер?	0	2026-07-22 17:52:14.61694
187	63	assistant	Привет! 👋 Вот что я умею:\n\n📅 **Составить расписание на день** — просто опишите свой обычный день (работа, учёба, отдых), и я создам идеальный график с перерывами и свободным временем.\n\n📌 **Создать событие или напоминание** — скажите «запиши встречу в пятницу в 15:00», «напомни купить продукты завтра», «добавь созвон на 10:00» — и я добавлю это в календарь.\n\n📸 **Проанализировать скриншот расписания** — пришлите фото/скриншот вашего расписания, и я оценю его и могу добавить в календарь.\n\n👀 **Показать расписание** — спросите «что у меня запланировано?» или «покажи расписание на завтра».\n\n📝 **Создать заметку** — скажите «сделай заметку» или «запиши идею».\n\nРасскажите, чем я могу помочь? 😊	0	2026-07-28 08:39:18.904234
188	63	user	Привет	0	2026-08-02 07:18:13.813337
189	63	assistant	Привет! Я здесь, чтобы помочь. Рассказывай, что случилось?	0	2026-08-02 07:18:13.813337
420	172	user	Вот интересна книга Филиппа Дика «Мечтают ли андроиды об электровозцах?» Что скажешь?	0	2026-08-03 12:59:43.652319
166	55	assistant	Привет! С удовольствием помогу тебе подобрать что-то под настроение. Чтобы рекомендация была максимально точной, давай определимся с «вайбом» вечера.\n\nВыбирай категорию, которая откликается прямо сейчас:\n\n### 1. Если хочется «залипнуть» и забыть о реальности (Фантастика/Фэнтези)\n*   **«Проект "Аве Мария"» Энди Вейера.** Если любишь космос, науку и юмор в духе «Марсианина». Читается на одном дыхании, невозможно оторваться.\n*   **«Дом, в котором...» Мариам Петросян.** Это не просто книга, это целый мир. Атмосферная, немного магическая история о жизни подростков в интернате. Идеально для долгого вечера с чаем.\n\n### 2. Если хочется пощекотать нервы (Детектив/Триллер)\n*   **«Десять негритят» Агаты Кристи.** Классика, которая никогда не устаревает. Если вдруг пропустил — это идеальный вечерний детектив.\n*   **«Безмолвный пациент» Алекса Михаэлидеса.** Психологический триллер с очень неожиданным финалом. Затягивает с первых страниц.\n\n### 3. Если хочется чего-то уютного и философского (Современная проза)\n*   **«Тревожные люди» Фредрика Бакмана.** Очень добрая, смешная и немного грустная история о людях, их странностях и о том, как мы все пытаемся просто «справиться». Бакман — мастер исцеления души.\n*   **«Полночная библиотека» Мэтта Хейга.** Книга о выборе, сожалениях и о том, что было бы, если бы мы прожили жизнь иначе. Очень вдохновляет.\n\n### 4. Если хочется «прокачать» мышление (Нон-фикшн)\n*   **«Атомные привычки» Джеймса Клира.** Если хочешь начать менять жизнь с мелочей. Очень структурировано и без лишней «воды».\n*   **«Sapiens. Краткая история человечества» Юваля Ноя Харари.** Если хочешь посмотреть на наш мир с высоты птичьего полета и понять, как мы стали такими, какие есть.\n\n---\n\n**Как выбрать?**\n*   Хочешь **эмоций и тепла**? Бери Бакмана.\n*   Хочешь **динамики и драйва**? Бери Вейера.\n*   Хочешь **загадок**? Бери Михаэлидеса.\n\nЧто из этого звучит ближе к тому, что ты ищешь? Или, может, у тебя есть любимый жанр, который я не упомянул? Расскажи, и я сужу поиск!	499	2026-07-22 17:52:14.61694
167	56	user	Слушай, какой фильм посмотреть на вечер? Что скажешь?	0	2026-07-22 17:53:02.896721
168	56	assistant	Выбор зависит от желаемого настроения. Вот три варианта под разные задачи:\n\n1. **Если хочешь качественный психологический триллер:** «Остров проклятых» (2010). Мастерская работа Скорсезе, напряженный сюжет и финал, который заставляет переосмыслить всё увиденное.\n2. **Если нужно что-то интеллектуальное и визуально безупречное:** «Бегущий по лезвию 2049» (2017). Глубокая философская фантастика о природе человечности с эталонной операторской работой.\n3. **Если хочется динамики и черного юмора:** «Джентльмены» (2019). Гай Ричи в своей лучшей форме — стильный криминальный фильм с отличными диалогами и яркими персонажами.\n\nЧто из этого ближе к твоему текущему настрою?	0	2026-07-22 17:53:02.896721
190	64	user	что посмотреть на вечер из фильмов?	0	2026-08-02 07:18:27.903739
191	64	assistant	Выбор зависит от настроения:\n\n1.  **Интеллектуальный триллер:** «Престиж» (Кристофер Нолан). История двух фокусников, одержимых соперничеством.\n2.  **Научная фантастика:** «Прибытие» (Дени Вильнёв). Лингвистический подход к первому контакту с инопланетной цивилизацией.\n3.  **Криминальная драма:** «Схватка» (Майкл Манн). Противостояние профессионального вора и детектива в Лос-Анджелесе.\n4.  **Атмосферный хоррор:** «Маяк» (Роберт Эггерс). Психологическое безумие двух смотрителей маяка в изоляции.\n5.  **Легкая комедия/авантюра:** «Джентльмены» (Гай Ричи). Динамичный криминальный сюжет с британским колоритом.\n\nУточни жанровые предпочтения, если нужно что-то более специфическое.	0	2026-08-02 07:18:27.903739
419	172	assistant	Для вечернего чтения выбор зависит от того, хочешь ли ты погрузиться в размышления или отвлечься от реальности:\n\n1. **Филип Дик, «Мечтают ли андроиды об электроовцах?»** — классика киберпанка. Философский вопрос о том, что делает человека человеком, поданный через нуарную детективную историю. Читается быстро, оставляет долгое послевкусие.\n\n2. **Стефан Цвейг, «Шахматная новелла»** — идеальный вариант на один вечер. Психологическая драма о столкновении двух характеров, одержимости и границах человеческого разума. Очень концентрированное и сильное произведение.\n\n3. **Нил Гейман, «Американские боги»** — если хочется погрузиться в мифологию, перенесенную в современный мир. Мрачная, атмосферная и захватывающая проза.\n\n4. **Эрих Мария Ремарк, «Триумфальная арка»** — если есть настроение для меланхолии и размышлений о любви, жизни и смерти на фоне предвоенного Парижа.\n\n5. **Фредрик Бакман, «Вторая жизнь Уве»** — если нужно что-то более светлое, но при этом глубокое. История о ворчливом старике, которая балансирует на грани юмора и драмы.\n\nЧто из этого ближе к твоему текущему состоянию?	0	2026-08-03 12:59:29.421007
421	172	assistant	Это фундаментальное произведение, которое вышло далеко за рамки жанровой фантастики. Основные аспекты:\n\n**1. Философский контекст**\nЦентральный вопрос книги — не столько поиск беглых андроидов, сколько попытка определить границы эмпатии. Дик ставит под сомнение человеческую исключительность: если машина способна страдать, бояться и имитировать человеческое поведение до степени неразличимости, то в чем разница между «настоящим» и «сконструированным»?\n\n**2. Атмосфера**\nМир книги — это постапокалиптический упадок. Большая часть человечества покинула Землю, а оставшиеся живут среди радиоактивной пыли и руин. Это создает гнетущее, меланхоличное настроение, которое сильно отличается от визуального ряда фильма «Бегущий по лезвию». Книга более камерная, сюрреалистичная и сосредоточена на внутреннем надломе главного героя, Рика Декарда.\n\n**3. Роль религии и технологий**\nВ романе важную роль играет «мерсеризм» — религия, основанная на коллективном сопереживании, и приборы вроде «органа настроения», которые позволяют людям искусственно задавать себе эмоциональный фон. Это острая сатира на общество потребления, где даже эмоции становятся товаром.\n\n**4. Книга vs Фильм**\nНе стоит ждать от книги экшена. Ридли Скотт взял из романа лишь сеттинг и общую завязку, превратив её в нео-нуарный боевик. Роман же — это экзистенциальная драма. В нем больше внимания уделено быту, абсурду повседневности и теме животных, которые в мире Дика стали высшей ценностью из-за их редкости.\n\n**Вердикт:** Читать стоит, если ты готов к интеллектуальной рефлексии, а не к динамичному сюжету. Это «черное зеркало» 1968 года, которое сегодня ощущается даже более актуальным, чем в момент написания.	0	2026-08-03 12:59:43.652319
583	241	user	Подскажи, пожалуйста, какой фильм посмотреть на вечер?	0	2026-08-08 12:13:52.612855
584	241	assistant	Выбор зависит от желаемого настроения:\n\n1. **Интеллектуальный триллер:** «Престиж» (2006). История о противостоянии двух фокусников, полная загадок и неожиданных поворотов.\n2. **Научная фантастика:** «Прибытие» (2016). Глубокая драма о первом контакте с инопланетной цивилизацией и восприятии времени.\n3. **Криминальная драма:** «Семь» (1995). Мрачный детектив о поиске серийного убийцы, основанного на семи смертных грехах.\n4. **Атмосферная драма:** «Одержимость» (2014). Интенсивная история о цене успеха и отношениях между амбициозным барабанщиком и его жестоким наставником.\n5. **Легкий, но умный:** «Достать ножи» (2019). Классический детектив в современном прочтении с отличным актерским составом.\n\nЧто из этого ближе к твоим предпочтениям?	0	2026-08-08 12:13:52.612855
585	241	user	Подскажи, какую книжку на вечер почитать?	0	2026-08-08 12:24:00.247702
586	241	assistant	Выбор зависит от того, хочешь ли ты погрузиться в размышления или отвлечься:\n\n1. **Филип Дик, «Мечтают ли андроиды об электроовцах?»** — классика киберпанка. Философский вопрос о том, что именно делает человека человеком. Читается быстро, погружает в нуарную атмосферу.\n2. **Фредрик Бакман, «Вторая жизнь Уве»** — трогательная и ироничная история о ворчливом старике, жизнь которого меняется из-за новых соседей. Идеально для уютного вечера.\n3. **Дэниел Киз, «Цветы для Элджернона»** — сильный психологический роман в форме дневниковых записей об эксперименте по повышению интеллекта. Читается на одном дыхании, оставляет глубокий след.\n4. **Стивен Кинг, «11/22/63»** — масштабная история о путешествии во времени с целью предотвратить убийство Кеннеди. Отличный микс исторической драмы и саспенса.\n5. **Харуки Мураками, «Норвежский лес»** — меланхоличная история о взрослении, любви и потере. Хорошо подходит для спокойного чтения.\n\nЧто из этого ближе к текущему состоянию?	0	2026-08-08 12:24:00.247702
430	174	user	Поскажи, что стоит почитать на вечер?	0	2026-08-03 13:09:55.241966
431	174	assistant	Привет! Как твой ментор, я подберу для тебя что-то в зависимости от того, в каком состоянии ты сейчас находишься и какого «послевкусия» ждешь от вечера. \n\nВот 4 направления на выбор:\n\n### 1. Если хочется «перезагрузить» мозг и вдохновиться\n**«Дзен и искусство ухода за мотоциклом», Роберт Пёрсиг.**\nЭто не про мотоциклы. Это глубокое философское путешествие, которое учит замечать детали, находить смысл в рутине и понимать, как устроено мышление. Идеально для тех, кто чувствует ментальную усталость и хочет «навести порядок» в голове.\n\n### 2. Если хочется погрузиться в другую реальность (художественная литература)\n**«Цветы для Элджернона», Дэниел Киз.**\nСильная, пронзительная история в форме дневниковых записей человека с низким IQ, который соглашается на экспериментальную операцию. Книга заставляет переосмыслить ценность интеллекта, человеческих отношений и того, что делает нас личностями. Читается на одном дыхании, но оставляет долгое послевкусие.\n\n### 3. Если хочется стать эффективнее (нон-фикшн)\n**«Атомные привычки», Джеймс Клир.**\nЕсли ты хочешь что-то изменить в жизни, но не знаешь, с чего начать — читай это. Никакой «воды», только прикладные механики того, как маленькие действия приводят к большим результатам. Очень структурирует мышление.\n\n### 4. Если хочется чего-то легкого, но умного\n**«Автостопом по галактике», Дуглас Адамс.**\nАбсурдный, невероятно смешной английский юмор. Если вечер выдался тяжелым и хочется просто посмеяться над абсурдностью бытия — это лучший выбор. \n\n---\n\n**Чтобы я мог дать более точный совет, ответь на один вопрос:**\nКакое у тебя сейчас настроение? \n*   А) Хочу «погрузиться» в историю и забыть о делах.\n*   Б) Хочу узнать что-то новое, чтобы завтра применить это в работе/жизни.\n*   В) Хочу что-то короткое, чтобы прочитать за пару часов и лечь спать.\n\nЧто выбираешь?	455	2026-08-03 13:09:55.241966
432	175	assistant	Привет! 👋 Вот что я умею:\n\n📅 **Составить расписание на день** — просто опишите свой обычный день (работа, учёба, отдых), и я создам идеальный график с перерывами и свободным временем.\n\n📌 **Создать событие или напоминание** — скажите «запиши встречу в пятницу в 15:00», «напомни купить продукты завтра», «добавь созвон на 10:00» — и я добавлю это в календарь.\n\n📸 **Проанализировать скриншот расписания** — пришлите фото/скриншот вашего расписания, и я оценю его и могу добавить в календарь.\n\n👀 **Показать расписание** — спросите «что у меня запланировано?» или «покажи расписание на завтра».\n\n📝 **Создать заметку** — скажите «сделай заметку» или «запиши идею».\n\nРасскажите, чем я могу помочь? 😊	0	2026-08-03 13:53:50.603766
589	243	user	Привет, какие фильмы посоветуешь посмотреть на вечер?	0	2026-08-08 12:32:22.85596
590	243	assistant	Привет. Выбор зависит от желаемого настроения:\n\n1. **Интеллектуальная фантастика:** «Прибытие» (2016) — глубокая драма о коммуникации и восприятии времени.\n2. **Напряженный триллер:** «Пленницы» (2013) — тяжелая история о поисках пропавших детей с сильной актерской игрой.\n3. **Криминальная драма:** «Схватка» (1995) — классика жанра, противостояние полицейского и грабителя.\n4. **Черная комедия:** «Джентльмены» (2019) — динамичный сюжет, стильная подача и британский юмор.\n5. **Научная фантастика:** «Интерстеллар» (2014) — масштабное визуальное полотно о космосе и человеческих привязанностях.\n\nЧто из этого ближе к твоим предпочтениям?	0	2026-08-08 12:32:22.85596
\.


--
-- Data for Name: mood_entries; Type: TABLE DATA; Schema: public; Owner: lifeagent
--

COPY public.mood_entries (id, user_id, mood, emoji, label, created_at) FROM stdin;
1	3	3	😐	Нормально	2026-08-02 15:43:35.241981+00
2	3	4	🙂	Хорошо	2026-08-02 15:43:42.695106+00
3	3	3	😐	Нормально	2026-08-04 19:32:25.013054+00
\.


--
-- Data for Name: notes; Type: TABLE DATA; Schema: public; Owner: lifeagent
--

COPY public.notes (id, user_id, title, content, is_pinned, color, created_at, updated_at) FROM stdin;
1	1	ыы	ыы	f	#8B5CF6	2026-07-16 13:32:23.011675+00	2026-07-16 13:32:23.011675+00
\.


--
-- Data for Name: otp_challenges; Type: TABLE DATA; Schema: public; Owner: lifeagent
--

COPY public.otp_challenges (id, email, code_hash, expires_at, attempts, last_sent_at, blocked_until, verified, created_at) FROM stdin;
3	fresh@test.com	124a0f90c26f3eed659eeef3ecdfecc9acb493856f7f63278c1a6aae085721a3	2026-07-16 19:30:45.354023+00	0	2026-07-16 19:25:45.35405+00	\N	f	2026-07-16 19:25:45.352075+00
5	test@ixteria.ru	6f94580658720a2a2e2c5c6c9a3fff75661ffb7d907f148f7c2845e04e351966	2026-07-16 19:33:11.518358+00	0	2026-07-16 19:28:11.518392+00	\N	t	2026-07-16 19:28:11.515205+00
10	fresh-test@example.com	0a3b86f893360023d7e7c9e3b72ba8fb7a3b13f0d2abf29b87b4b31755dc93dd	2026-07-16 19:44:35.940284+00	0	2026-07-16 19:39:35.940311+00	\N	f	2026-07-16 19:39:35.936763+00
12	final-test@example.com	f91c2b4069563f25577fc13396a44aae4d96de172670cb879d3bb434adf020c6	2026-07-16 19:49:14.062281+00	0	2026-07-16 19:44:14.062307+00	\N	t	2026-07-16 19:44:14.058731+00
15	valerybastrigin@gmail.com	127d9fb58dd5b3325897cc6379117d7518386b7bf63045c0f1ccb0f11b94f690	2026-07-16 19:54:15.090227+00	0	2026-07-16 19:49:15.090253+00	\N	f	2026-07-16 19:49:15.087475+00
17	ixteriaagents@gmail.com	3af26798adc76f41577c6d5270725734c597f5c8dbead2e0eac2d8d59463e07b	2026-07-16 19:58:10.542066+00	0	2026-07-16 19:53:10.542097+00	\N	f	2026-07-16 19:53:10.538374+00
18	test@example.com	eb343bba87f8cbd43c1e72b193558e5eb1f4bc0df05caa47ed968ba27880dc61	2026-07-16 19:58:25.843317+00	0	2026-07-16 19:53:25.84337+00	\N	f	2026-07-16 19:53:25.841104+00
52	vbastrigin@outlook.com	da7826403b907dd30f0fcc07e5b1aaa40b44fa05312c9e7e4475fdfb559ff315	2026-07-20 13:43:37.397434+00	0	2026-07-20 13:38:37.397482+00	\N	f	2026-07-20 13:38:37.390162+00
54	vbastrigin1@yandex.ru	46da14b150aa49246b703f421ba47f62ff6f4c2fcc893a007fd8c680f9780f9c	2026-07-20 17:49:04.897287+00	0	2026-07-20 17:44:04.897322+00	\N	f	2026-07-20 17:44:04.894135+00
\.


--
-- Data for Name: portfolio_analyses; Type: TABLE DATA; Schema: public; Owner: lifeagent
--

COPY public.portfolio_analyses (id, user_id, overall_score, strengths, weaknesses, recommendations, asset_allocation, created_at, updated_at) FROM stdin;
1	2	4	["Высокое качество активов: портфель состоит из надежных компаний-лидеров российского рынка (голубые фишки)", "Наличие защитного инструмента в виде ОФЗ, что снижает общую волатильность"]	["Критическая концентрация на российском рынке (отсутствие географической диверсификации)", "Отсутствие валютной диверсификации (портфель полностью подвержен страновым и валютным рискам РФ)", "Высокая концентрация в отдельных секторах (нефтегаз, IT, финансы), что делает портфель уязвимым к отраслевым шокам", "Отсутствие альтернативных активов (золото, недвижимость) для хеджирования инфляции"]	["Увеличить долю защитных активов (ОФЗ или фонды денежного рынка) до 20-30% для снижения просадок", "Рассмотреть добавление инструментов, номинированных в юанях или замещающих облигаций для валютной диверсификации", "Провести ребалансировку: сократить долю убыточных позиций с высокой концентрацией (Лукойл, Яндекс) в пользу более широкого рыночного индекса", "Добавить активы, не коррелирующие с российским фондовым рынком, например, золото"]	{"Акции": 87, "Облигации": 12, "Недвижимость": 0, "Наличные/Депозиты": 1, "Другое": 0}	2026-08-02 13:29:54.81259+00	2026-08-02 13:29:54.81259+00
2	2	4	["Наличие защитных активов в виде золота и государственных облигаций (ОФЗ)", "Выбор качественных эмитентов («голубых фишек») российского рынка"]	["Высокая концентрация на российском рынке, отсутствие международной диверсификации", "Значительные просадки по ключевым позициям (Лукойл, Яндекс, Золото), свидетельствующие об ошибках в тайминге входа", "Неэффективное использование валютной позиции (мизерные остатки долларов при высокой волатильности)", "Отсутствие широкой отраслевой диверсификации"]	["Провести ребалансировку портфеля: увеличить долю облигаций для снижения волатильности", "Рассмотреть покупку фондов на широкий рынок или инструменты денежного рынка для стабилизации доходности", "Пересмотреть стратегию усреднения позиций по активам с глубокой просадкой, чтобы избежать «замораживания» капитала в убыточных идеях", "Сформировать подушку безопасности в ликвидных инструментах, а не в спекулятивных валютных остатках"]	{"Акции": 66, "Облигации": 12, "Недвижимость": 0, "Наличные/Депозиты": 8, "Другое": 14}	2026-08-02 13:31:03.952889+00	2026-08-02 13:31:03.952889+00
3	2	4	["Наличие защитных активов (золото)", "Присутствие качественных российских голубых фишек", "Попытка валютной диверсификации через юань"]	["Высокая концентрация в отдельных акциях (Яндекс, Лукойл)", "Значительные нереализованные убытки по большинству позиций", "Недостаточная доля облигаций для сбалансированного портфеля", "Отсутствие четкой стратегии ребалансировки"]	["Провести аудит позиций с максимальной просадкой и оценить их фундаментальные перспективы", "Увеличить долю облигаций (ОФЗ) для снижения волатильности портфеля", "Прекратить хаотичную покупку валюты в микродозах, сосредоточившись на системном накоплении", "Рассмотреть покупку фондов на индекс Мосбиржи для снижения рисков отдельных эмитентов"]	{"Акции": 68, "Облигации": 12, "Недвижимость": 0, "Наличные/Депозиты": 9, "Другое": 11}	2026-08-02 19:17:54.366784+00	2026-08-02 19:17:54.366784+00
4	2	4	["Высокое качество активов: в портфеле представлены лидеры российского рынка (голубые фишки)", "Наличие инструментов с фиксированной доходностью (ОФЗ) для снижения волатильности"]	["Критически низкая диверсификация: портфель полностью привязан к экономике РФ", "Отсутствие защитных активов (золото, фонды денежного рынка) и инструментов хеджирования валютных рисков", "Высокая концентрация в отдельных секторах (нефтегаз, IT, финансы), что повышает риск просадки при отраслевых кризисах"]	["Увеличить долю облигаций (ОФЗ или корпоративные бонды) до 30-40% для стабилизации портфеля", "Рассмотреть добавление инструментов, номинированных в юанях или замещающих облигаций для защиты от девальвации рубля", "Провести ребалансировку: текущий портфель перегружен акциями роста, которые сильно зависят от ключевой ставки ЦБ РФ"]	{"Акции": 87, "Облигации": 13, "Недвижимость": 0, "Наличные/Депозиты": 0, "Другое": 0}	2026-08-03 11:32:35.136099+00	2026-08-03 11:32:35.136099+00
5	2	5	["Наличие защитных активов (золото и ОФЗ)", "Выбор качественных эмитентов (голубые фишки РФ)", "Наличие валютной диверсификации через юань"]	["Высокая концентрация в российском фондовом рынке (отсутствие глобальной диверсификации)", "Значительные просадки по многим позициям, указывающие на неэффективную точку входа или отсутствие стратегии усреднения", "Незначительная доля защитных инструментов относительно общего объема портфеля"]	["Пересмотреть стратегию удержания убыточных позиций: провести ребалансировку и избавиться от активов с сомнительными перспективами роста", "Увеличить долю облигаций (ОФЗ) для снижения волатильности портфеля", "Рассмотреть возможность покупки фондов на золото или другие инструменты, если физическое золото не является стратегическим активом", "Сфокусироваться на регулярном пополнении портфеля для усреднения стоимости активов"]	{"Акции": 67, "Облигации": 12, "Недвижимость": 0, "Наличные/Депозиты": 9, "Другое": 12}	2026-08-03 11:35:06.363667+00	2026-08-03 11:35:06.363667+00
6	2	5	["Наличие качественных голубых фишек российского рынка (Сбер, Лукойл, Яндекс)", "Присутствие защитных активов в виде золота", "Наличие валютной диверсификации через китайский юань"]	["Высокая концентрация в отдельных акциях при небольшом общем размере портфеля", "Значительные нереализованные убытки по многим позициям, указывающие на неудачный тайминг входа", "Отсутствие системного подхода к распределению активов (слишком много мелких позиций)", "Низкая ликвидность и неэффективное использование валютной составляющей"]	["Прекратить хаотичную покупку отдельных акций и рассмотреть покупку широких индексных фондов для снижения рисков", "Пересмотреть стратегию по убыточным позициям: либо усреднять качественные активы, либо зафиксировать убыток для ребалансировки", "Увеличить долю облигаций для создания стабильного денежного потока и снижения волатильности портфеля", "Определить четкий инвестиционный горизонт и риск-профиль, чтобы перестать реагировать на рыночные просадки"]	{"Акции": 67, "Облигации": 12, "Недвижимость": 0, "Наличные/Депозиты": 9, "Другое": 12}	2026-08-03 11:36:13.712175+00	2026-08-03 11:36:13.712175+00
7	2	4	["Наличие диверсификации по классам активов (акции, облигации, валюта, золото).", "Присутствие российских голубых фишек (Лукойл, Сбербанк, Норникель, МТС, Яндекс).", "Наличие защитных активов (золото, доллар США)."]	["Высокая концентрация в отдельных бумагах (Яндекс, Сбербанк, Лукойл).", "Значительные убытки по портфелю в целом (-11,6%).", "Низкая доля облигаций в портфеле.", "Недостаточная валютная диверсификация (преобладание рубля и китайского юаня)."]	["Пересмотреть структуру портфеля с целью снижения концентрации в отдельных бумагах.", "Увеличить долю облигаций для снижения общего риска портфеля.", "Рассмотреть возможность увеличения доли доллара США или других твердых валют.", "Провести анализ причин убытков по отдельным позициям и принять меры по их устранению или сокращению."]	{"Акции": 60, "Облигации": 20, "Недвижимость": 0, "Наличные/Депозиты": 0, "Другое": 20}	2026-08-03 11:38:04.053495+00	2026-08-03 11:38:04.053495+00
8	3	5	["Наличие диверсификации по классам активов (акции, облигации, валюта, золото)", "Присутствие защитных активов (золото, доллар США)", "Включение в портфель крупных российских компаний с потенциалом роста"]	["Высокая концентрация в отдельных акциях (Яндекс, Сбербанк, Лукойл)", "Недостаточная диверсификация по валютам (преобладание рубля и китайского юаня)", "Значительные убытки по некоторым позициям, что может указывать на неоптимальный выбор активов или время покупки", "Отсутствие четкой информации о целях инвестирования и горизонте планирования, что затрудняет оценку соответствия риск-профилю"]	["Пересмотреть долю наиболее убыточных и сконцентрированных позиций, возможно, сократить их и реинвестировать в более диверсифицированные активы или бумаги с лучшим потенциалом", "Увеличить долю иностранных валют (доллар США, евро) для снижения валютного риска и повышения диверсификации", "Рассмотреть возможность добавления облигаций других эмитентов или фондов облигаций для снижения общего риска портфеля", "Определить четкие инвестиционные цели и горизонт планирования, чтобы скорректировать структуру портфеля в соответствии с риск-профилем"]	{"Акции": 50, "Облигации": 25, "Недвижимость": 0, "Наличные/Депозиты": 0, "Другое": 25}	2026-08-03 11:40:24.028815+00	2026-08-03 11:40:24.028815+00
9	3	5	["Наличие защитных активов (золото, доллар США)", "Диверсификация по нескольким крупным российским компаниям", "Включение государственных облигаций (ОФЗ)"]	["Высокая концентрация в отдельных акциях (Яндекс, Сбербанк, Лукойл)", "Значительная доля российского рынка, низкая валютная диверсификация", "Недостаточное представление облигаций в портфеле", "Неясность целей и риск-профиля инвестора"]	["Увеличить долю облигаций в портфеле для снижения общего риска", "Рассмотреть диверсификацию в иностранные акции и другие классы активов для снижения странового риска", "Провести ребалансировку портфеля для снижения концентрации в отдельных бумагах", "Определить свои инвестиционные цели и соответствующий им риск-профиль для более точной настройки портфеля"]	{"Акции": 70, "Облигации": 20, "Недвижимость": 0, "Наличные/Депозиты": 0, "Другое": 10}	2026-08-03 11:46:00.68397+00	2026-08-03 11:46:00.68397+00
10	4	4	["Наличие диверсификации по классам активов (акции, облигации, золото, валюта)", "Присутствие крупных российских компаний (голубые фишки) в портфеле акций", "Наличие защитных активов (золото, доллар США)"]	["Высокая концентрация в отдельных позициях (Яндекс, Сбербанк, Лукойл)", "Значительные убытки по портфелю в целом (-11,6%) и по отдельным позициям (Яндекс, Лукойл, Норильский никель)", "Недостаточная диверсификация по валютам (преобладание российского рубля и китайского юаня)", "Отсутствие информации о сроках инвестирования и целях, что затрудняет оценку соответствия риск-профилю"]	["Пересмотреть концентрацию в отдельных акциях, снизить долю наиболее убыточных и/или рискованных позиций.", "Увеличить долю защитных активов или рассмотреть возможность инвестирования в более стабильные инструменты для снижения общего риска портфеля.", "Провести ребалансировку портфеля с целью достижения более сбалансированного распределения активов и снижения зависимости от отдельных эмитентов.", "Рассмотреть возможность диверсификации по другим валютам, помимо доллара США и китайского юаня, для снижения валютных рисков."]	{"Акции": 55, "Облигации": 25, "Недвижимость": 0, "Наличные/Депозиты": 0, "Другое": 20}	2026-08-03 12:33:18.085386+00	2026-08-03 12:33:18.085386+00
\.


--
-- Data for Name: reminders; Type: TABLE DATA; Schema: public; Owner: lifeagent
--

COPY public.reminders (id, user_id, text, title, "time", date, completed, color, created_at, updated_at, push_enabled) FROM stdin;
1	4	ку	\N	17:09:00	2026-07-02	f	#3B82F6	2026-07-16 14:09:37.819701	2026-07-16 14:09:37.819701	f
2	4	ку	\N	17:09:00	2026-07-16	f	#3B82F6	2026-07-16 14:09:52.455322	2026-07-16 14:09:52.455322	f
3	3	Встреча с Эратом	Встреча с Эратом	09:00:00	2026-07-22	f	#3B82F6	2026-07-20 18:42:55.576036	2026-07-20 18:42:55.576036	f
4	2	ффф	\N	19:32:00	2026-07-27	f	#3B82F6	2026-07-27 16:32:09.482668	2026-07-31 10:15:03.048298	f
\.


--
-- Data for Name: schedule_analyses; Type: TABLE DATA; Schema: public; Owner: lifeagent
--

COPY public.schedule_analyses (id, user_id, analysis_data, start_date, end_date, created_at, updated_at) FROM stdin;
1	3	Приветствую! Давайте вместе разберем ваш график на 4 августа 2026 года. Я подготовил для вас конструктивную и мотивирующую рецензию, чтобы помочь вам максимально эффективно использовать свое время.\n\n**Общий анализ графика:**\n\nВаш график на этот день выглядит достаточно насыщенным, но при этом хорошо структурированным. Вы уделяете время как профессиональным обязанностям, так и личным делам, творчеству и отдыху. Это отличный показатель стремления к балансу.\n\n**Баланс работы и отдыха:**\n\n*   **Работа:** Вы выделяете значительную часть дня на "Работу" (с 8:00 до 16:00) и "Работу над приложением" (с 19:00 до 20:00), а также "Видео-монтаж" (с 20:00 до 21:00). Это говорит о вашей целеустремленности и продуктивности в профессиональной сфере.\n*   **Личные дела и творчество:** "Личные дела" (с 16:00 до 17:00) и "YouTube" (с 17:00 до 18:00) прекрасно вписываются в ваш день, позволяя вам заниматься тем, что вам интересно и приносит удовольствие.\n*   **Отдых:** Выделив час на "Отдых" (с 18:00 до 19:00), вы демонстрируете понимание важности восстановления сил. Это очень ценно!\n\n**Наличие перегрузок:**\n\nВ целом, ваш график выглядит сбалансированным, но есть несколько моментов, которые стоит учесть:\n\n*   **Непрерывная работа:** С 19:00 до 21:00 у вас идут два блока, связанных с работой ("Работа над приложением" и "Видео-монтаж"). Хотя это и разные задачи, они обе требуют умственного напряжения. Возможно, стоит подумать о небольшом перерыве между ними, чтобы "переключить" мозг.\n*   **Отсутствие явных перерывов в рабочее время:** В основном рабочем блоке (8:00-16:00) не указаны явные перерывы на обед или короткие паузы. Хотя вы можете делать их интуитивно, их планирование может повысить общую продуктивность и предотвратить усталость.\n\n**Полезные советы по тайм-менеджменту:**\n\n1.  **Планируйте короткие перерывы в течение рабочего дня:** Даже 5-10 минут каждые 1-1.5 часа могут значительно повысить вашу концентрацию и снизить утомляемость. Встаньте, пройдитесь, сделайте легкую разминку.\n2.  **Создайте буферное время:** Между задачами, особенно между теми, которые требуют высокой концентрации, оставьте небольшие "буферы" (5-15 минут). Это позволит вам плавно перейти от одной деятельности к другой, не чувствуя спешки.\n3.  **Гибкость – ваш друг:** Помните, что график – это ориентир, а не жесткие рамки. Если что-то идет не по плану, не расстраивайтесь. Просто скорректируйте дальнейшие действия.\n4.  **Оцените пики продуктивности:** Понаблюдайте за собой, в какое время дня вы наиболее продуктивны. Возможно, стоит перенести самые сложные или творческие задачи на эти периоды.\n5.  **Визуализируйте свой день:** Если вам удобно, попробуйте использовать визуальные инструменты для планирования, например, цветное кодирование задач в календаре. Это поможет быстрее ориентироваться в расписании.\n6.  **Завершайте день с "закрытием" задач:** Перед тем, как перейти к отдыху или личным делам, потратьте несколько минут на то, чтобы подвести итоги рабочего дня, записать, что удалось сделать, и что нужно перенести на следующий день. Это поможет "закрыть" рабочие мысли и лучше расслабиться.\n\n**Мотивация:**\n\nВаш подход к организации дня заслуживает похвалы! Вы демонстрируете отличную способность совмещать различные сферы жизни, что является ключом к долгосрочной продуктивности и личному благополучию. Продолжайте в том же духе, экспериментируйте с небольшими корректировками, и вы обязательно достигнете своих целей!\n\nЕсли у вас возникнут дополнительные вопросы или вы захотите обсудить какие-то аспекты более детально, я всегда готов помочь!	2026-08-04	2026-08-04	2026-08-04 19:14:24.569723+00	2026-08-04 19:14:24.569723+00
\.


--
-- Data for Name: therapy_sessions; Type: TABLE DATA; Schema: public; Owner: lifeagent
--

COPY public.therapy_sessions (id, user_id, chat_id, summary, status, started_at, ended_at, created_at) FROM stdin;
5	2	69	Вот резюме вашего терапевтического сеанса:\n\n**Резюме сеанса:**\n\nКлиент обратился с запросом о переживании болезненного разрыва отношений, которые длились семь лет и завершились внезапным уходом партнера без объяснения причин. Несмотря на то, что прошло два года и клиент успешно адаптировался через уход в работу, он продолжает испытывать эмоциональный дискомфорт из-за навязчивых воспоминаний и снов о бывшей девушке. В ходе сессии было выявлено, что трудоголизм стал механизмом вытеснения, а не проживания чувств, что привело к «консервации» эмоций. Клиенту предложено сменить тактику борьбы с воспоминаниями на позицию «наблюдателя» и рассмотреть возможность символического завершения отношений, чтобы перестать удерживать боль как единственную связь с прошлым.	completed	2026-08-02 10:10:05.155264+00	2026-08-02 10:14:33.613411+00	2026-08-02 10:10:05.155264+00
\.


--
-- Data for Name: token_transactions; Type: TABLE DATA; Schema: public; Owner: lifeagent
--

COPY public.token_transactions (id, user_id, amount, transaction_type, description, created_at) FROM stdin;
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: lifeagent
--

COPY public.transactions (id, statement_id, user_id, date, description, amount, type, category, created_at) FROM stdin;
1568	8	4	2026-06-10	Опл.по Дог.ОФ-26561424	17693.96	income	Доход (оплата по договору)	2026-08-03 12:49:44.965921+00
1569	8	4	2026-06-10	Опл.по Дог.26658326/25	1286.78	income	Доход (оплата по договору)	2026-08-03 12:49:44.965921+00
1570	8	4	2026-06-10	Перевод между счетами одного клиента	3412	expense	Переводы между счетами	2026-08-03 12:49:44.965921+00
1571	8	4	2026-06-10	Исходящий перевод СБП, Валерий Евгеньевич Б., +7 950 328-85-89, Т-Банк	2200	expense	Переводы (исходящие)	2026-08-03 12:49:44.965921+00
1572	8	4	2026-06-10	Исходящий перевод СБП, Валерий Евгеньевич Б., +7 950 328-85-89, Т-Банк	3000	expense	Переводы (исходящие)	2026-08-03 12:49:44.965921+00
1573	8	4	2026-06-10	Исходящий перевод СБП, Надежда Петровна П., +7 911 269-21-08, ВТБ	3000	expense	Переводы (исходящие)	2026-08-03 12:49:44.965921+00
1574	8	4	2026-06-10	Перевод между счетами одного клиента	3000	expense	Переводы между счетами	2026-08-03 12:49:44.965921+00
1575	8	4	2026-06-10	Оплата СБП QR (Додо Пицца, Шушары-1)	1030	expense	Развлечения	2026-08-03 12:49:44.965921+00
1576	8	4	2026-06-08	Оплата товаров и услуг DIXY-78336D	339.78	expense	Продукты	2026-08-03 12:49:44.965921+00
1577	8	4	2026-06-10	Оплата СБП QR (OZON)	531	expense	Прочее	2026-08-03 12:49:44.965921+00
1578	8	4	2026-06-08	Оплата товаров и услуг DIXY-78336D	103.79	expense	Продукты	2026-08-03 12:49:44.965921+00
1579	8	4	2026-06-08	Оплата товаров и услуг PYATEROCHKA 7149	119.98	expense	Продукты	2026-08-03 12:49:44.965921+00
1580	8	4	2026-06-08	Оплата товаров и услуг YANDEX*7999*BIKE	1	expense	Транспорт	2026-08-03 12:49:44.965921+00
1581	8	4	2026-06-10	Оплата СБП QR (Sota Connect)	349	expense	Прочее	2026-08-03 12:49:44.965921+00
1582	8	4	2026-06-08	Оплата товаров и услуг PYATEROCHKA 7149	194.07	expense	Продукты	2026-08-03 12:49:44.965921+00
1583	8	4	2026-06-10	Оплата товаров и услуг YANDEX*5815*PLUS	449	expense	Прочее	2026-08-03 12:49:44.965921+00
1584	8	4	2026-06-11	Перевод между счетами одного клиента	1000	income	Переводы между счетами	2026-08-03 12:49:44.965921+00
1585	8	4	2026-06-11	Оплата СБП QR (ТОО "ОнлиПэй")	109.89	expense	Прочее	2026-08-03 12:49:44.965921+00
1586	8	4	2026-06-09	Оплата товаров и услуг DIXY-78336D	513.32	expense	Продукты	2026-08-03 12:49:44.965921+00
1587	8	4	2026-06-09	Оплата товаров и услуг YANDEX*7999*BIKE	1	expense	Транспорт	2026-08-03 12:49:44.965921+00
1588	8	4	2026-06-09	Оплата товаров и услуг PYATEROCHKA 6	59.98	expense	Продукты	2026-08-03 12:49:44.965921+00
1589	8	4	2026-06-09	Оплата товаров и услуг PYATEROCHKA 6	136.98	expense	Продукты	2026-08-03 12:49:44.965921+00
1590	8	4	2026-06-11	Оплата СБП QR (ТОО "ОнлиПэй")	109.89	expense	Прочее	2026-08-03 12:49:44.965921+00
1591	8	4	2026-06-12	Оплата СБП QR (podorozhnik.spb.ru_SBP)	130	expense	Транспорт	2026-08-03 12:49:44.965921+00
1592	8	4	2026-06-12	Исходящий перевод СБП, Эмилия Ратхановна К., +7 952 242-16-98, Сбербанк	70	expense	Переводы (исходящие)	2026-08-03 12:49:44.965921+00
1593	8	4	2026-06-12	Перевод между счетами одного клиента	2000	income	Переводы между счетами	2026-08-03 12:49:44.965921+00
1594	8	4	2026-06-12	Внутрибанковский перевод на +7 996 903-73-17, Алина К.	1000	expense	Переводы (исходящие)	2026-08-03 12:49:44.965921+00
1595	8	4	2026-06-10	Оплата товаров и услуг DIXY-78336D	756.58	expense	Продукты	2026-08-03 12:49:44.965921+00
1596	8	4	2026-06-10	Оплата товаров и услуг APTEKA 78-2020	220	expense	Прочее	2026-08-03 12:49:44.965921+00
1597	8	4	2026-06-11	Оплата товаров и услуг PYATEROCHKA 6	189.97	expense	Продукты	2026-08-03 12:49:44.965921+00
1598	8	4	2026-06-13	Оплата СБП QR (podorozhnik.spb.ru_SBP)	130	expense	Транспорт	2026-08-03 12:49:44.965921+00
1599	8	4	2026-06-11	Оплата товаров и услуг YANDEX*7999*BIKE	1	expense	Транспорт	2026-08-03 12:49:44.965921+00
1600	8	4	2026-06-11	Оплата товаров и услуг SBER*5411*SAMOKAT	463	expense	Прочее	2026-08-03 12:49:44.965921+00
1601	8	4	2026-06-11	Оплата товаров и услуг DIXY-78336D	148.98	expense	Продукты	2026-08-03 12:49:44.965921+00
1602	8	4	2026-06-11	Оплата товаров и услуг PYATEROCHKA 6	199.98	expense	Продукты	2026-08-03 12:49:44.965921+00
1603	8	4	2026-06-11	Оплата товаров и услуг PYATEROCHKA 6	59.98	expense	Продукты	2026-08-03 12:49:44.965921+00
1604	8	4	2026-06-14	Оплата СБП QR (podorozhnik.spb.ru_SBP)	130	expense	Транспорт	2026-08-03 12:49:44.965921+00
1605	8	4	2026-06-12	Оплата товаров и услуг MAGNIT MM ANDROMAKHA	114.98	expense	Продукты	2026-08-03 12:49:44.965921+00
1606	8	4	2026-06-12	Оплата товаров и услуг MAGNIT MM ANDROMAKHA	99.98	expense	Продукты	2026-08-03 12:49:44.965921+00
1607	8	4	2026-06-12	Оплата товаров и услуг YANDEX*7999*BIKE	1	expense	Транспорт	2026-08-03 12:49:44.965921+00
1608	8	4	2026-06-12	Оплата товаров и услуг DIXY-78336D	258.91	expense	Продукты	2026-08-03 12:49:44.965921+00
1609	8	4	2026-06-12	YANDEX*7999*BIKE	1	expense	Транспорт	2026-08-03 12:49:44.965921+00
1610	8	4	2026-06-12	PYATEROCHKA 6812	89.98	expense	Продукты	2026-08-03 12:49:44.965921+00
1611	8	4	2026-06-15	Опл.по Дог.26658326/25 4176.52 руб	4176.52	income	Доход (оплата по договорам)	2026-08-03 12:49:44.965921+00
1612	8	4	2026-06-15	Оплата СБП QR (FUNPAY)	683.76	expense	Развлечения	2026-08-03 12:49:44.965921+00
1613	8	4	2026-06-15	DIXY-78336D	300.86	expense	Продукты	2026-08-03 12:49:44.965921+00
1614	8	4	2026-06-15	MAGNIT MM ANDROMAKHA	96.98	expense	Продукты	2026-08-03 12:49:44.965921+00
1615	8	4	2026-06-13	YANDEX*7999*BIKE	1	expense	Транспорт	2026-08-03 12:49:44.965921+00
1616	8	4	2026-06-13	PYATEROCHKA 6812	69.99	expense	Продукты	2026-08-03 12:49:44.965921+00
1617	8	4	2026-06-15	Внутрибанковский перевод на +7 996 903-73-17, Алина К.	2000	expense	Переводы	2026-08-03 12:49:44.965921+00
1618	8	4	2026-06-14	YANDEX*7999*BIKE	1	expense	Транспорт	2026-08-03 12:49:44.965921+00
1619	8	4	2026-06-14	MAGNIT MM ANDROMAKHA	104.98	expense	Продукты	2026-08-03 12:49:44.965921+00
1620	8	4	2026-06-16	YANDEX*5411*LAVKA	337	expense	Онлайн-сервисы	2026-08-03 12:49:44.965921+00
1621	8	4	2026-06-17	Опл.по Дог.ОФ-26561424 10126.57 руб	10126.57	income	Доход (оплата по договорам)	2026-08-03 12:49:44.965921+00
1622	8	4	2026-06-17	Внутрибанковский перевод на +7 996 903-73-17, Алина К.	2000	expense	Переводы	2026-08-03 12:49:44.965921+00
1623	8	4	2026-06-15	DIXY-78336D	229.95	expense	Продукты	2026-08-03 12:49:44.965921+00
1624	8	4	2026-06-15	SBER*5411*SAMOKAT	444	expense	Доставка	2026-08-03 12:49:44.965921+00
1625	8	4	2026-06-17	Исходящий перевод СБП, Валерий Евгеньевич Б., +7 950 328-85-89, Т-Банк	5000	expense	Переводы	2026-08-03 12:49:44.965921+00
1626	8	4	2026-06-15	SBER*5411*SAMOKAT	472	expense	Доставка	2026-08-03 12:49:44.965921+00
1627	8	4	2026-06-18	Опл.по Дог.26658326/25 673.06 руб	673.06	income	Доход (оплата по договорам)	2026-08-03 12:49:44.965921+00
1628	8	4	2026-06-18	Входящий перевод по номеру карты (Tribute)	4860	income	Переводы	2026-08-03 12:49:44.965921+00
1629	8	4	2026-06-18	Перевод между счетами одного клиента	5000	expense	Переводы	2026-08-03 12:49:44.965921+00
1630	8	4	2026-06-18	Оплата СБП QR (Озон)	629	expense	Развлечения	2026-08-03 12:49:44.965921+00
1631	8	4	2026-06-18	Оплата СБП QR (OZON)	509	expense	Развлечения	2026-08-03 12:49:44.965921+00
1632	8	4	2026-06-19	Оплата СБП QR (podorozhnik.spb.ru_SBP)	130	expense	Прочее	2026-08-03 12:49:44.965921+00
1633	8	4	2026-06-19	Входящий перевод СБП, Тимур Рафкатович Г., +7 991 002-59-41, Озон Банк (Ozon)	1579	income	Переводы	2026-08-03 12:49:44.965921+00
1634	8	4	2026-06-19	Входящий перевод СБП, Алина Александровна К., +7 996 903-73-17, Т-Банк	5000	income	Переводы	2026-08-03 12:49:44.965921+00
1635	8	4	2026-06-19	Оплата СБП QR (Озон)	520	expense	Развлечения	2026-08-03 12:49:44.965921+00
1636	8	4	2026-06-17	SBER*5411*SAMOKAT	450	expense	Доставка	2026-08-03 12:49:44.965921+00
1637	8	4	2026-06-17	DIXY-78336D	659.58	expense	Продукты	2026-08-03 12:49:44.965921+00
1638	8	4	2026-06-17	MAGNIT MM ANDROMAKHA	104.98	expense	Продукты	2026-08-03 12:49:44.965921+00
1639	8	4	2026-06-17	YANDEX*7999*BIKE	1	expense	Транспорт	2026-08-03 12:49:44.965921+00
1640	8	4	2026-06-20	Оплата СБП QR (podorozhnik.spb.ru_SBP)	130	expense	Прочее	2026-08-03 12:49:44.965921+00
1641	8	4	2026-06-18	DIXY-78336D	279.95	expense	Продукты	2026-08-03 12:49:44.965921+00
1642	8	4	2026-06-21	Оплата СБП QR (podorozhnik.spb.ru_SBP)	130	expense	Прочее	2026-08-03 12:49:44.965921+00
1643	8	4	2026-06-19	DIXY-78336D	269.88	expense	Продукты	2026-08-03 12:49:44.965921+00
1644	8	4	2026-06-21	Исходящий перевод СБП, Валерий Евгеньевич Б., +7 950 328-85-89, Озон Банк (Ozon)	1460	expense	Переводы	2026-08-03 12:49:44.965921+00
1645	8	4	2026-06-21	Оплата СБП QR (podorozhnik.spb.ru_SBP)	130	expense	Прочее	2026-08-03 12:49:44.965921+00
1646	8	4	2026-06-19	YANDEX*7999*BIKE	1	expense	Транспорт	2026-08-03 12:49:44.965921+00
1647	8	4	2026-06-19	AU3402	220	expense	Прочее	2026-08-03 12:49:44.965921+00
1648	8	4	2026-06-19	MAGNIT MM ANDROMAKHA	169.98	expense	Продукты	2026-08-03 12:49:44.965921+00
1649	8	4	2026-06-19	PYATEROCHKA 6812	69.99	expense	Продукты	2026-08-03 12:49:44.965921+00
1650	8	4	2026-06-19	SBER*5411*SAMOKAT	499	expense	Доставка	2026-08-03 12:49:44.965921+00
1651	8	4	2026-06-22	Опл.по Дог.26658326/25 3594.49 руб	3594.49	income	Доход (оплата по договорам)	2026-08-03 12:49:44.965921+00
1652	8	4	2026-06-22	Оплата СБП QR (podorozhnik.spb.ru_SBP)	130	expense	Прочее	2026-08-03 12:49:44.965921+00
1653	8	4	2026-06-22	Исходящий перевод СБП, Надежда Петровна П., +7 911 269-21-08, ВТБ	3851	expense	Переводы	2026-08-03 12:49:44.965921+00
1654	8	4	2026-06-20	PYATEROCHKA 6812	119.98	expense	Продукты	2026-08-03 12:49:44.965921+00
1655	8	4	2026-06-20	SBER*5411*SAMOKAT	542	expense	Доставка	2026-08-03 12:49:44.965921+00
1656	8	4	2026-06-20	PYATEROCHKA 6812	115.98	expense	Продукты	2026-08-03 12:49:44.965921+00
1657	8	4	2026-06-20	Оплата товаров и услуг AU3402	350	expense	Продукты	2026-08-03 12:49:44.965921+00
1658	8	4	2026-06-20	Оплата товаров и услуг YANDEX*7999*BIKE	1	expense	Транспорт	2026-08-03 12:49:44.965921+00
1659	8	4	2026-06-20	Оплата товаров и услуг PYATEROCHKA 6812	119.98	expense	Продукты	2026-08-03 12:49:44.965921+00
1660	8	4	2026-06-20	Оплата товаров и услуг UNIVERSAM VMESTE 24 CH	171.33	expense	Продукты	2026-08-03 12:49:44.965921+00
1661	8	4	2026-06-22	Оплата СБП QR (Озон)	519	expense	Развлечения	2026-08-03 12:49:44.965921+00
1662	8	4	2026-06-23	Перевод между счетами одного клиента	500	income	Переводы	2026-08-03 12:49:44.965921+00
1663	8	4	2026-06-23	Опл.по Дог.26658326/25 877.31 руб	877.31	income	Доход (прочее)	2026-08-03 12:49:44.965921+00
1664	8	4	2026-06-23	Перевод между счетами одного клиента	600	expense	Переводы	2026-08-03 12:49:44.965921+00
1665	8	4	2026-06-21	Оплата товаров и услуг PYATEROCHKA 6812	109.98	expense	Продукты	2026-08-03 12:49:44.965921+00
1666	8	4	2026-06-21	Оплата товаров и услуг MAGNIT MM ANDROMAKHA	109.98	expense	Продукты	2026-08-03 12:49:44.965921+00
1667	8	4	2026-06-21	Оплата товаров и услуг PYATEROCHKA 6812	119.98	expense	Продукты	2026-08-03 12:49:44.965921+00
1668	8	4	2026-06-23	Оплата СБП QR (podorozhnik.spb.ru_SBP)	130	expense	Транспорт	2026-08-03 12:49:44.965921+00
1669	8	4	2026-06-21	Оплата товаров и услуг DIXY-78336D	346.47	expense	Продукты	2026-08-03 12:49:44.965921+00
1670	8	4	2026-06-23	Оплата СБП QR (Дикси 78336)	279.88	expense	Продукты	2026-08-03 12:49:44.965921+00
1671	8	4	2026-06-21	Оплата товаров и услуг YANDEX*7999*BIKE	1	expense	Транспорт	2026-08-03 12:49:44.965921+00
1672	8	4	2026-06-23	Перевод между счетами одного клиента	600	income	Переводы	2026-08-03 12:49:44.965921+00
1673	8	4	2026-06-23	Оплата СБП QR (Озон)	737	expense	Развлечения	2026-08-03 12:49:44.965921+00
1674	8	4	2026-06-24	Опл.по Дог.ОФ-26561424 5995.65 руб	5995.65	income	Доход (прочее)	2026-08-03 12:49:44.965921+00
1675	8	4	2026-06-24	Опл.по Дог.26658326/25 1290.39 руб	1290.39	income	Доход (прочее)	2026-08-03 12:49:44.965921+00
1676	8	4	2026-06-24	Перевод между счетами одного клиента	1500	expense	Переводы	2026-08-03 12:49:44.965921+00
1677	8	4	2026-06-22	Оплата товаров и услуг DIXY-78336D	59.99	expense	Продукты	2026-08-03 12:49:44.965921+00
1678	8	4	2026-06-22	Оплата товаров и услуг YANDEX*7999*BIKE	1	expense	Транспорт	2026-08-03 12:49:44.965921+00
1679	8	4	2026-06-22	Оплата товаров и услуг MAGNIT MM ANDROMAKHA	169.97	expense	Продукты	2026-08-03 12:49:44.965921+00
1680	8	4	2026-06-22	Оплата товаров и услуг DIXY-78336D	359.86	expense	Продукты	2026-08-03 12:49:44.965921+00
1681	8	4	2026-06-24	Оплата СБП QR (Озон)	554	expense	Развлечения	2026-08-03 12:49:44.965921+00
1682	8	4	2026-06-24	Оплата СБП QR (t2_SBP)	650	expense	Развлечения	2026-08-03 12:49:44.965921+00
1683	8	4	2026-06-25	Оплата СБП QR (t2)	100	expense	Развлечения	2026-08-03 12:49:44.965921+00
1684	8	4	2026-06-25	Опл.по Дог.26658326/25 37.00 руб	37	income	Доход (прочее)	2026-08-03 12:49:44.965921+00
1685	8	4	2026-06-25	Оплата СБП QR (OZON)	520	expense	Развлечения	2026-08-03 12:49:44.965921+00
1686	8	4	2026-06-23	Оплата товаров и услуг PYATEROCHKA 6812	189.97	expense	Продукты	2026-08-03 12:49:44.965921+00
1687	8	4	2026-06-23	Оплата товаров и услуг YANDEX*7999*BIKE	1	expense	Транспорт	2026-08-03 12:49:44.965921+00
1688	8	4	2026-06-23	Оплата товаров и услуг PYATEROCHKA 6812	59.99	expense	Продукты	2026-08-03 12:49:44.965921+00
1689	8	4	2026-06-23	Оплата товаров и услуг PYATEROCHKA 6812	95.98	expense	Продукты	2026-08-03 12:49:44.965921+00
1690	8	4	2026-06-25	Оплата СБП QR (FUNPAY)	291.6	expense	Прочее	2026-08-03 12:49:44.965921+00
1691	8	4	2026-06-25	Оплата СБП QR (Озон)	609	expense	Развлечения	2026-08-03 12:49:44.965921+00
1692	8	4	2026-06-24	Оплата товаров и услуг DIXY-78336D	19.99	expense	Продукты	2026-08-03 12:49:44.965921+00
1693	8	4	2026-06-24	Оплата товаров и услуг DIXY-78336D	479.82	expense	Продукты	2026-08-03 12:49:44.965921+00
1694	8	4	2026-06-25	Оплата товаров и услуг PYATEROCHKA 22266	124.98	expense	Продукты	2026-08-03 12:49:44.965921+00
1695	8	4	2026-06-25	Оплата товаров и услуг DIXY-78336D	119.9	expense	Продукты	2026-08-03 12:49:44.965921+00
1696	8	4	2026-06-25	Оплата товаров и услуг DIXY-78336D	289.87	expense	Продукты	2026-08-03 12:49:44.965921+00
1697	8	4	2026-06-25	Оплата товаров и услуг SBER*5411*SAMOKAT	536	expense	Транспорт	2026-08-03 12:49:44.965921+00
1698	8	4	2026-06-27	Оплата СБП QR (podorozhnik.spb.ru_SBP)	130	expense	Транспорт	2026-08-03 12:49:44.965921+00
1699	8	4	2026-06-27	Перевод между счетами одного клиента	1000	income	Переводы	2026-08-03 12:49:44.965921+00
1700	8	4	2026-06-27	Оплата СБП QR (Озон)	554	expense	Развлечения	2026-08-03 12:49:44.965921+00
1701	8	4	2026-06-28	Оплата СБП QR (podorozhnik.spb.ru_SBP)	130	expense	Транспорт	2026-08-03 12:49:44.965921+00
1702	8	4	2026-06-28	Перевод между счетами одного клиента	1000	income	Переводы	2026-08-03 12:49:44.965921+00
1703	8	4	2026-06-28	Оплата СБП QR (ООО "ИНТЕР")	200	expense	Прочее	2026-08-03 12:49:44.965921+00
1704	8	4	2026-06-26	Оплата товаров и услуг SBER*5411*SAMOKAT	476	expense	Транспорт	2026-08-03 12:49:44.965921+00
1705	8	4	2026-06-28	Оплата СБП QR (Озон)	534	expense	Развлечения	2026-08-03 12:49:44.965921+00
1706	8	4	2026-06-26	Оплата товаров и услуг PYATEROCHKA 22266	245.96	expense	Продукты	2026-08-03 12:49:44.965921+00
1707	8	4	2026-06-28	Перевод между счетами одного клиента	1000	income	Переводы	2026-08-03 12:49:44.965921+00
1708	8	4	2026-06-27	Оплата товаров и услуг IP MITCHENKO D.YU.	-290	expense	Покупки	2026-08-03 12:49:44.965921+00
1709	8	4	2026-06-29	Оплата СБП QR (podorozhnik.spb.ru_SBP)	1203.84	income	Доход (оплата по договору)	2026-08-03 12:49:44.965921+00
1710	8	4	2026-06-29	Оплата товаров и услуг KRASNOE&BELOE	-130	expense	Развлечения	2026-08-03 12:49:44.965921+00
1711	8	4	2026-06-27	Оплата товаров и услуг PYATEROCHKA 6812	-59.99	expense	Продукты	2026-08-03 12:49:44.965921+00
1712	8	4	2026-06-27	Оплата товаров и услуг PYATEROCHKA 6812	-109.98	expense	Продукты	2026-08-03 12:49:44.965921+00
1713	8	4	2026-06-27	Оплата товаров и услуг PYATEROCHKA 6812	-189.97	expense	Продукты	2026-08-03 12:49:44.965921+00
1714	8	4	2026-06-27	Оплата товаров и услуг YANDEX*7999*BIKE	-1	expense	Транспорт	2026-08-03 12:49:44.965921+00
1715	8	4	2026-06-29	Оплата СБП QR (ООО "ИНТЕР")	-100	expense	Прочее	2026-08-03 12:49:44.965921+00
1716	8	4	2026-06-29	Оплата СБП QR (Озон)	-531	expense	Прочее	2026-08-03 12:49:44.965921+00
1717	8	4	2026-06-30	Опл.по Дог.26658326/25 574.29 руб	574.29	income	Доход (оплата по договору)	2026-08-03 12:49:44.965921+00
1718	8	4	2026-06-30	Оплата СБП QR (podorozhnik.spb.ru_SBP)	-130	expense	Развлечения	2026-08-03 12:49:44.965921+00
1719	8	4	2026-06-30	Оплата СБП QR (ООО "ИНТЕР")	-100	expense	Прочее	2026-08-03 12:49:44.965921+00
1720	8	4	2026-06-28	Оплата товаров и услуг PYATEROCHKA 22266	-222.77	expense	Продукты	2026-08-03 12:49:44.965921+00
1721	8	4	2026-06-30	Оплата СБП QR (ООО "ИНТЕР")	-100	expense	Прочее	2026-08-03 12:49:44.965921+00
1722	8	4	2026-06-28	Оплата товаров и услуг SBER*5411*SAMOKAT	-507	expense	Покупки	2026-08-03 12:49:44.965921+00
1723	8	4	2026-06-28	Оплата товаров и услуг YANDEX*7999*BIKE	-1	expense	Транспорт	2026-08-03 12:49:44.965921+00
1724	8	4	2026-06-28	Оплата товаров и услуг PYATEROCHKA 6812	-109.98	expense	Продукты	2026-08-03 12:49:44.965921+00
1725	8	4	2026-06-30	Оплата СБП QR (ООО "ИНТЕР")	-100	expense	Прочее	2026-08-03 12:49:44.965921+00
1726	8	4	2026-06-28	Оплата товаров и услуг DIXY-78336D	-447.56	expense	Продукты	2026-08-03 12:49:44.965921+00
1727	8	4	2026-06-30	Оплата СБП QR (ООО "ИНТЕР")	-100	expense	Прочее	2026-08-03 12:49:44.965921+00
1728	8	4	2026-07-01	Входящий перевод по номеру карты (IPKAMBULATOVAZN)	1080	income	Переводы	2026-08-03 12:49:44.965921+00
1729	8	4	2026-07-01	Перевод между счетами одного клиента	-800	expense	Переводы	2026-08-03 12:49:44.965921+00
1730	8	4	2026-07-01	Опл.по Дог.ОФ-26561424 5281.90 руб	5281.9	income	Доход (оплата по договору)	2026-08-03 12:49:44.965921+00
1731	8	4	2026-07-01	Опл.по Дог.26658326/25 637.56 руб	637.56	income	Доход (оплата по договору)	2026-08-03 12:49:44.965921+00
1732	8	4	2026-07-01	Перевод между счетами одного клиента	-5200	expense	Переводы	2026-08-03 12:49:44.965921+00
1733	8	4	2026-07-01	Оплата товаров и услуг YANDEX*7999*BIKE	-1	expense	Транспорт	2026-08-03 12:49:44.965921+00
1734	8	4	2026-07-01	Оплата товаров и услуг DIXY-78336D	-409.77	expense	Продукты	2026-08-03 12:49:44.965921+00
1735	8	4	2026-07-01	Входящий перевод по номеру карты (Tribute)	3240	income	Переводы	2026-08-03 12:49:44.965921+00
1736	8	4	2026-07-01	Перевод между счетами одного клиента	-3000	expense	Переводы	2026-08-03 12:49:44.965921+00
1737	8	4	2026-07-01	Оплата товаров и услуг PYATEROCHKA 6812	-109.98	expense	Продукты	2026-08-03 12:49:44.965921+00
1738	8	4	2026-07-01	Оплата СБП QR (podorozhnik.spb.ru_SBP)	-130	expense	Развлечения	2026-08-03 12:49:44.965921+00
1739	8	4	2026-07-01	Оплата товаров и услуг YANDEX*5411*LAVKA	-178	expense	Покупки	2026-08-03 12:49:44.965921+00
1740	8	4	2026-07-02	Перевод между счетами одного клиента	1000	income	Переводы	2026-08-03 12:49:44.965921+00
1741	8	4	2026-07-02	Опл.по Дог.26658326/25 599.94 руб	599.94	income	Доход (оплата по договору)	2026-08-03 12:49:44.965921+00
1742	8	4	2026-07-02	Оплата СБП QR (RouterAI)	-100	expense	Прочее	2026-08-03 12:49:44.965921+00
1743	8	4	2026-07-02	Оплата товаров и услуг PYATEROCHKA 6812	-169.97	expense	Продукты	2026-08-03 12:49:44.965921+00
1744	8	4	2026-07-02	Оплата товаров и услуг PYATEROCHKA 6812	-109.98	expense	Продукты	2026-08-03 12:49:44.965921+00
1745	8	4	2026-07-02	Оплата товаров и услуг DIXY-78336D	-178.67	expense	Продукты	2026-08-03 12:49:44.965921+00
1746	8	4	2026-07-02	Оплата товаров и услуг YANDEX*7999*BIKE	-1	expense	Транспорт	2026-08-03 12:49:44.965921+00
1747	8	4	2026-07-02	Оплата СБП QR (Озон)	-534	expense	Прочее	2026-08-03 12:49:44.965921+00
1748	8	4	2026-07-01	Оплата товаров и услуг B090	-211	expense	Покупки	2026-08-03 12:49:44.965921+00
1749	8	4	2026-07-01	Оплата товаров и услуг UNIVERSAM VMESTE 24 CH	-114.9	expense	Продукты	2026-08-03 12:49:44.965921+00
1750	8	4	2026-07-01	Оплата товаров и услуг UNIVERSAM VMESTE 24 CH	-185.8	expense	Продукты	2026-08-03 12:49:44.965921+00
1751	8	4	2026-07-01	Оплата товаров и услуг YANDEX*7999*BIKE	-1	expense	Транспорт	2026-08-03 12:49:44.965921+00
1752	8	4	2026-07-03	Оплата СБП QR (podorozhnik.spb.ru_SBP)	-130	expense	Развлечения	2026-08-03 12:49:44.965921+00
1753	8	4	2026-07-01	Оплата товаров и услуг DIXY-78336D	-349.78	expense	Продукты	2026-08-03 12:49:44.965921+00
1754	8	4	2026-07-03	Перевод между счетами одного клиента	1000	income	Переводы	2026-08-03 12:49:44.965921+00
1755	8	4	2026-07-02	Оплата товаров и услуг PYATEROCHKA 22266	-394.96	expense	Продукты	2026-08-03 12:49:44.965921+00
1756	8	4	2026-07-03	Оплата товаров и услуг B036	-211	expense	Покупки	2026-08-03 12:49:44.965921+00
1757	8	4	2026-07-03	Оплата товаров и услуг YANDEX*7999*BIKE	-1	expense	Транспорт	2026-08-03 12:49:44.965921+00
1758	8	4	2026-07-03	Оплата товаров и услуг DIXY-78336D	-349.78	expense	Продукты	2026-08-03 12:49:44.965921+00
1759	8	4	2026-07-03	Оплата товаров и услуг MAGNIT MM TIGIL	-224.98	expense	Продукты	2026-08-03 12:49:44.965921+00
1760	8	4	2026-07-04	Оплата товаров и услуг PYATEROCHKA 6812	-169.97	expense	Продукты	2026-08-03 12:49:44.965921+00
1761	8	4	2026-07-04	Оплата товаров и услуг PYATEROCHKA 6812	-109.98	expense	Продукты	2026-08-03 12:49:44.965921+00
1762	8	4	2026-07-04	Оплата товаров и услуг PYATEROCHKA 6812	-109.98	expense	Продукты	2026-08-03 12:49:44.965921+00
1763	8	4	2026-07-05	Оплата СБП QR (RouterAI)	-100	expense	Оплата услуг	2026-08-03 12:49:44.965921+00
1764	8	4	2026-07-06	Опл.по Дог.26658326/25	3467.94	income	Доход (оплата по договорам)	2026-08-03 12:49:44.965921+00
1765	8	4	2026-07-06	Перевод между счетами одного клиента	-3500	expense	Переводы	2026-08-03 12:49:44.965921+00
1766	8	4	2026-07-06	Оплата СБП QR (RouterAI)	-100	expense	Оплата услуг	2026-08-03 12:49:44.965921+00
1767	8	4	2026-07-04	Оплата товаров и услуг YANDEX*7999*BIKE	-1	expense	Транспорт	2026-08-03 12:49:44.965921+00
1768	8	4	2026-07-05	Оплата товаров и услуг YANDEX*7999*BIKE	-1	expense	Транспорт	2026-08-03 12:49:44.965921+00
1769	8	4	2026-07-07	Перевод между счетами одного клиента	540.92	income	Переводы	2026-08-03 12:49:44.965921+00
1770	8	4	2026-07-05	Оплата товаров и услуг YANDEX*7999*BIKE	-1	expense	Транспорт	2026-08-03 12:49:44.965921+00
1771	8	4	2026-07-07	Перевод между счетами одного клиента	1000	income	Переводы	2026-08-03 12:49:44.965921+00
1772	8	4	2026-07-07	Исходящий перевод СБП, Валерий Евгеньевич Б., +7 950 328-85-89, Озон Банк (Ozon)	-523	expense	Переводы	2026-08-03 12:49:44.965921+00
1773	8	4	2026-07-07	Оплата СБП QR (RouterAI)	-100	expense	Оплата услуг	2026-08-03 12:49:44.965921+00
1774	8	4	2026-07-08	Перевод между счетами одного клиента	1000	income	Переводы	2026-08-03 12:49:44.965921+00
1775	8	4	2026-07-08	Оплата СБП QR (ТОО "ОнлиПэй")	-939.4	expense	Оплата услуг	2026-08-03 12:49:44.965921+00
1776	8	4	2026-07-08	Перевод между счетами одного клиента	11000	income	Переводы	2026-08-03 12:49:44.965921+00
1777	8	4	2026-07-08	Опл.по Дог.ОФ-26561424	8174.23	income	Доход (оплата по договорам)	2026-08-03 12:49:44.965921+00
1778	8	4	2026-07-08	Опл.по Дог.26658326/25	669.24	income	Доход (оплата по договорам)	2026-08-03 12:49:44.965921+00
1779	8	4	2026-07-08	Исходящий перевод СБП, Надежда Петровна П., +7 911 269-21-08, Альфа-Банк	-10000	expense	Переводы	2026-08-03 12:49:44.965921+00
1780	8	4	2026-07-08	Исходящий перевод СБП, Александр Викторович П., +7 911 263-29-95, Альфа-Банк	-10000	expense	Переводы	2026-08-03 12:49:44.965921+00
1781	8	4	2026-07-09	Опл.по Дог.26658326/25	836.33	income	Доход (оплата по договорам)	2026-08-03 12:49:44.965921+00
1782	8	4	2026-07-09	Оплата товаров и услуг YANDEX*5411*LAVKA	-94	expense	Продукты	2026-08-03 12:49:44.965921+00
1783	8	4	2026-07-09	Оплата товаров и услуг YANDEX*5411*LAVKA	-110	expense	Продукты	2026-08-03 12:49:44.965921+00
1784	8	4	2026-07-09	Оплата СБП QR (podorozhnik.spb.ru_SBP)	-130	expense	Оплата услуг	2026-08-03 12:49:44.965921+00
1785	8	4	2026-07-07	Оплата товаров и услуг YANDEX*7999*BIKE	-1	expense	Транспорт	2026-08-03 12:49:44.965921+00
1786	8	4	2026-07-07	Оплата товаров и услуг DIXY-78336D	-291.88	expense	Продукты	2026-08-03 12:49:44.965921+00
1787	8	4	2026-07-09	Входящий перевод СБП, Илья Алексеевич Л., +7 992 028-51-42, Альфа-Банк	2000	income	Переводы	2026-08-03 12:49:44.965921+00
1788	8	4	2026-07-09	Оплата СБП QR (RouterAI)	-100	expense	Оплата услуг	2026-08-03 12:49:44.965921+00
1789	8	4	2026-07-10	Опл.по Дог.26658326/25	775.7	income	Доход (оплата по договорам)	2026-08-03 12:49:44.965921+00
1790	8	4	2026-07-08	Оплата товаров и услуг DIXY-78336D	-356.78	expense	Продукты	2026-08-03 12:49:44.965921+00
1791	8	4	2026-07-10	Оплата СБП QR (podorozhnik.spb.ru_SBP)	-130	expense	Оплата услуг	2026-08-03 12:49:44.965921+00
1792	8	4	2026-07-08	Оплата товаров и услуг YANDEX*7999*BIKE	-1	expense	Транспорт	2026-08-03 12:49:44.965921+00
1793	8	4	2026-07-08	Оплата товаров и услуг DIXY-78336D	-39.98	expense	Продукты	2026-08-03 12:49:44.965921+00
1794	8	4	2026-07-08	Оплата товаров и услуг UNIVERSAM VMESTE 24 CH	-159.9	expense	Продукты	2026-08-03 12:49:44.965921+00
1795	8	4	2026-07-10	Оплата СБП QR (Sota Connect)	-349	expense	Оплата услуг	2026-08-03 12:49:44.965921+00
1796	8	4	2026-07-10	Оплата СБП QR (OZON)	-83	expense	Оплата услуг	2026-08-03 12:49:44.965921+00
1797	8	4	2026-07-10	Оплата СБП QR (RouterAI)	-100	expense	Оплата услуг	2026-08-03 12:49:44.965921+00
1798	8	4	2026-07-10	Оплата СБП QR (RouterAI)	-100	expense	Оплата услуг	2026-08-03 12:49:44.965921+00
1799	9	4	2026-06-10	Опл.по Дог.ОФ-26561424	17693.96	income	Доход (оплата по договору)	2026-08-03 12:55:46.653255+00
1800	9	4	2026-06-10	Опл.по Дог.26658326/25	1286.78	income	Доход (оплата по договору)	2026-08-03 12:55:46.653255+00
1801	9	4	2026-06-10	Перевод между счетами одного клиента	3412	expense	Переводы между счетами	2026-08-03 12:55:46.653255+00
1802	9	4	2026-06-10	Исходящий перевод СБП, Валерий Евгеньевич Б., +7 950 328-85-89, Т-Банк	2200	expense	Переводы (исходящие)	2026-08-03 12:55:46.653255+00
1803	9	4	2026-06-10	Исходящий перевод СБП, Валерий Евгеньевич Б., +7 950 328-85-89, Т-Банк	3000	expense	Переводы (исходящие)	2026-08-03 12:55:46.653255+00
1804	9	4	2026-06-10	Исходящий перевод СБП, Надежда Петровна П., +7 911 269-21-08, ВТБ	3000	expense	Переводы (исходящие)	2026-08-03 12:55:46.653255+00
1805	9	4	2026-06-10	Перевод между счетами одного клиента	3000	expense	Переводы между счетами	2026-08-03 12:55:46.653255+00
1806	9	4	2026-06-10	Оплата СБП QR (Додо Пицца, Шушары-1)	1030	expense	Развлечения	2026-08-03 12:55:46.653255+00
1807	9	4	2026-06-08	Оплата товаров и услуг DIXY-78336D	339.78	expense	Продукты	2026-08-03 12:55:46.653255+00
1808	9	4	2026-06-10	Оплата СБП QR (OZON)	531	expense	Прочее	2026-08-03 12:55:46.653255+00
1809	9	4	2026-06-08	Оплата товаров и услуг DIXY-78336D	103.79	expense	Продукты	2026-08-03 12:55:46.653255+00
1810	9	4	2026-06-08	Оплата товаров и услуг PYATEROCHKA 7149	119.98	expense	Продукты	2026-08-03 12:55:46.653255+00
1811	9	4	2026-06-08	Оплата товаров и услуг YANDEX*7999*BIKE	1	expense	Транспорт	2026-08-03 12:55:46.653255+00
1812	9	4	2026-06-10	Оплата СБП QR (Sota Connect)	349	expense	Прочее	2026-08-03 12:55:46.653255+00
1813	9	4	2026-06-08	Оплата товаров и услуг PYATEROCHKA 7149	194.07	expense	Продукты	2026-08-03 12:55:46.653255+00
1814	9	4	2026-06-10	Оплата товаров и услуг YANDEX*5815*PLUS	449	expense	Прочее	2026-08-03 12:55:46.653255+00
1815	9	4	2026-06-11	Перевод между счетами одного клиента	1000	income	Переводы между счетами	2026-08-03 12:55:46.653255+00
1816	9	4	2026-06-11	Оплата СБП QR (ТОО "ОнлиПэй")	109.89	expense	Прочее	2026-08-03 12:55:46.653255+00
1817	9	4	2026-06-09	Оплата товаров и услуг DIXY-78336D	513.32	expense	Продукты	2026-08-03 12:55:46.653255+00
1818	9	4	2026-06-09	Оплата товаров и услуг YANDEX*7999*BIKE	1	expense	Транспорт	2026-08-03 12:55:46.653255+00
1819	9	4	2026-06-09	Оплата товаров и услуг PYATEROCHKA 6	59.98	expense	Продукты	2026-08-03 12:55:46.653255+00
1820	9	4	2026-06-09	Оплата товаров и услуг PYATEROCHKA 6	136.98	expense	Продукты	2026-08-03 12:55:46.653255+00
1821	9	4	2026-06-11	Оплата СБП QR (ТОО "ОнлиПэй")	109.89	expense	Прочее	2026-08-03 12:55:46.653255+00
1822	9	4	2026-06-12	Оплата СБП QR (podorozhnik.spb.ru_SBP)	130	expense	Транспорт	2026-08-03 12:55:46.653255+00
1823	9	4	2026-06-12	Исходящий перевод СБП, Эмилия Ратхановна К., +7 952 242-16-98, Сбербанк	70	expense	Переводы (исходящие)	2026-08-03 12:55:46.653255+00
1824	9	4	2026-06-12	Перевод между счетами одного клиента	2000	income	Переводы между счетами	2026-08-03 12:55:46.653255+00
1825	9	4	2026-06-12	Внутрибанковский перевод на +7 996 903-73-17, Алина К.	1000	expense	Переводы (исходящие)	2026-08-03 12:55:46.653255+00
1826	9	4	2026-06-10	Оплата товаров и услуг DIXY-78336D	756.58	expense	Продукты	2026-08-03 12:55:46.653255+00
1827	9	4	2026-06-10	Оплата товаров и услуг APTEKA 78-2020	220	expense	Здоровье	2026-08-03 12:55:46.653255+00
1828	9	4	2026-06-11	Оплата товаров и услуг PYATEROCHKA 6	189.97	expense	Продукты	2026-08-03 12:55:46.653255+00
1829	9	4	2026-06-13	Оплата СБП QR (podorozhnik.spb.ru_SBP)	130	expense	Транспорт	2026-08-03 12:55:46.653255+00
1830	9	4	2026-06-11	Оплата товаров и услуг YANDEX*7999*BIKE	1	expense	Транспорт	2026-08-03 12:55:46.653255+00
1831	9	4	2026-06-11	Оплата товаров и услуг SBER*5411*SAMOKAT	463	expense	Прочее	2026-08-03 12:55:46.653255+00
1832	9	4	2026-06-11	Оплата товаров и услуг DIXY-78336D	148.98	expense	Продукты	2026-08-03 12:55:46.653255+00
1833	9	4	2026-06-11	Оплата товаров и услуг PYATEROCHKA 6	199.98	expense	Продукты	2026-08-03 12:55:46.653255+00
1834	9	4	2026-06-11	Оплата товаров и услуг PYATEROCHKA 6	59.98	expense	Продукты	2026-08-03 12:55:46.653255+00
1835	9	4	2026-06-14	Оплата СБП QR (podorozhnik.spb.ru_SBP)	130	expense	Транспорт	2026-08-03 12:55:46.653255+00
1836	9	4	2026-06-12	Оплата товаров и услуг MAGNIT MM ANDROMAKHA	114.98	expense	Продукты	2026-08-03 12:55:46.653255+00
1837	9	4	2026-06-12	Оплата товаров и услуг MAGNIT MM ANDROMAKHA	99.98	expense	Продукты	2026-08-03 12:55:46.653255+00
1838	9	4	2026-06-12	Оплата товаров и услуг YANDEX*7999*BIKE	1	expense	Транспорт	2026-08-03 12:55:46.653255+00
1839	9	4	2026-06-12	Оплата товаров и услуг DIXY-78336D	258.91	expense	Продукты	2026-08-03 12:55:46.653255+00
1840	9	4	2026-06-12	YANDEX*7999*BIKE	1	expense	Транспорт	2026-08-03 12:55:46.653255+00
1841	9	4	2026-06-12	PYATEROCHKA 6812	89.98	expense	Продукты	2026-08-03 12:55:46.653255+00
1842	9	4	2026-06-15	Опл.по Дог.26658326/25	4176.52	income	Доход (оплата по договорам)	2026-08-03 12:55:46.653255+00
1843	9	4	2026-06-15	Оплата СБП QR (FUNPAY)	683.76	expense	Развлечения	2026-08-03 12:55:46.653255+00
1844	9	4	2026-06-15	DIXY-78336D	300.86	expense	Продукты	2026-08-03 12:55:46.653255+00
1845	9	4	2026-06-15	MAGNIT MM ANDROMAKHA	96.98	expense	Продукты	2026-08-03 12:55:46.653255+00
1846	9	4	2026-06-13	YANDEX*7999*BIKE	1	expense	Транспорт	2026-08-03 12:55:46.653255+00
1847	9	4	2026-06-13	PYATEROCHKA 6812	69.99	expense	Продукты	2026-08-03 12:55:46.653255+00
1848	9	4	2026-06-15	Внутрибанковский перевод на +7 996 903-73-17, Алина К.	2000	expense	Переводы	2026-08-03 12:55:46.653255+00
1849	9	4	2026-06-14	YANDEX*7999*BIKE	1	expense	Транспорт	2026-08-03 12:55:46.653255+00
1850	9	4	2026-06-14	MAGNIT MM ANDROMAKHA	104.98	expense	Продукты	2026-08-03 12:55:46.653255+00
1851	9	4	2026-06-16	YANDEX*5411*LAVKA	337	expense	Продукты	2026-08-03 12:55:46.653255+00
1852	9	4	2026-06-17	Опл.по Дог.ОФ-26561424	10126.57	income	Доход (оплата по договорам)	2026-08-03 12:55:46.653255+00
1853	9	4	2026-06-17	Внутрибанковский перевод на +7 996 903-73-17, Алина К.	2000	expense	Переводы	2026-08-03 12:55:46.653255+00
1854	9	4	2026-06-15	DIXY-78336D	229.95	expense	Продукты	2026-08-03 12:55:46.653255+00
1855	9	4	2026-06-15	SBER*5411*SAMOKAT	444	expense	Транспорт	2026-08-03 12:55:46.653255+00
1856	9	4	2026-06-17	Исходящий перевод СБП, Валерий Евгеньевич Б., +7 950 328-85-89, Т-Банк	5000	expense	Переводы	2026-08-03 12:55:46.653255+00
1857	9	4	2026-06-15	SBER*5411*SAMOKAT	472	expense	Транспорт	2026-08-03 12:55:46.653255+00
1858	9	4	2026-06-18	Опл.по Дог.26658326/25	673.06	income	Доход (оплата по договорам)	2026-08-03 12:55:46.653255+00
1859	9	4	2026-06-18	Входящий перевод по номеру карты (Tribute)	4860	income	Переводы	2026-08-03 12:55:46.653255+00
1860	9	4	2026-06-18	Перевод между счетами одного клиента	5000	expense	Переводы	2026-08-03 12:55:46.653255+00
1861	9	4	2026-06-18	Оплата СБП QR (Озон)	629	expense	Развлечения	2026-08-03 12:55:46.653255+00
1862	9	4	2026-06-18	Оплата СБП QR (OZON)	509	expense	Развлечения	2026-08-03 12:55:46.653255+00
1863	9	4	2026-06-19	Оплата СБП QR (podorozhnik.spb.ru_SBP)	130	expense	Развлечения	2026-08-03 12:55:46.653255+00
1864	9	4	2026-06-19	Входящий перевод СБП, Тимур Рафкатович Г., +7 991 002-59-41, Озон Банк (Ozon)	1579	income	Переводы	2026-08-03 12:55:46.653255+00
1865	9	4	2026-06-19	Входящий перевод СБП, Алина Александровна К., +7 996 903-73-17, Т-Банк	5000	income	Переводы	2026-08-03 12:55:46.653255+00
1866	9	4	2026-06-19	Оплата СБП QR (Озон)	520	expense	Развлечения	2026-08-03 12:55:46.653255+00
1867	9	4	2026-06-17	SBER*5411*SAMOKAT	450	expense	Транспорт	2026-08-03 12:55:46.653255+00
1868	9	4	2026-06-17	DIXY-78336D	659.58	expense	Продукты	2026-08-03 12:55:46.653255+00
1869	9	4	2026-06-17	MAGNIT MM ANDROMAKHA	104.98	expense	Продукты	2026-08-03 12:55:46.653255+00
1870	9	4	2026-06-17	YANDEX*7999*BIKE	1	expense	Транспорт	2026-08-03 12:55:46.653255+00
1871	9	4	2026-06-20	Оплата СБП QR (podorozhnik.spb.ru_SBP)	130	expense	Развлечения	2026-08-03 12:55:46.653255+00
1872	9	4	2026-06-18	DIXY-78336D	279.95	expense	Продукты	2026-08-03 12:55:46.653255+00
1873	9	4	2026-06-21	Оплата СБП QR (podorozhnik.spb.ru_SBP)	130	expense	Развлечения	2026-08-03 12:55:46.653255+00
1874	9	4	2026-06-19	DIXY-78336D	269.88	expense	Продукты	2026-08-03 12:55:46.653255+00
1875	9	4	2026-06-21	Исходящий перевод СБП, Валерий Евгеньевич Б., +7 950 328-85-89, Озон Банк (Ozon)	1460	expense	Переводы	2026-08-03 12:55:46.653255+00
1876	9	4	2026-06-21	Оплата СБП QR (podorozhnik.spb.ru_SBP)	130	expense	Развлечения	2026-08-03 12:55:46.653255+00
1877	9	4	2026-06-19	YANDEX*7999*BIKE	1	expense	Транспорт	2026-08-03 12:55:46.653255+00
1878	9	4	2026-06-19	AU3402	220	expense	Прочее	2026-08-03 12:55:46.653255+00
1879	9	4	2026-06-19	MAGNIT MM ANDROMAKHA	169.98	expense	Продукты	2026-08-03 12:55:46.653255+00
1880	9	4	2026-06-19	PYATEROCHKA 6812	69.99	expense	Продукты	2026-08-03 12:55:46.653255+00
1881	9	4	2026-06-19	SBER*5411*SAMOKAT	499	expense	Транспорт	2026-08-03 12:55:46.653255+00
1882	9	4	2026-06-22	Опл.по Дог.26658326/25	3594.49	income	Доход (оплата по договорам)	2026-08-03 12:55:46.653255+00
1883	9	4	2026-06-22	Оплата СБП QR (podorozhnik.spb.ru_SBP)	130	expense	Развлечения	2026-08-03 12:55:46.653255+00
1884	9	4	2026-06-22	Исходящий перевод СБП, Надежда Петровна П., +7 911 269-21-08, ВТБ	3851	expense	Переводы	2026-08-03 12:55:46.653255+00
1885	9	4	2026-06-20	PYATEROCHKA 6812	119.98	expense	Продукты	2026-08-03 12:55:46.653255+00
1886	9	4	2026-06-20	SBER*5411*SAMOKAT	542	expense	Транспорт	2026-08-03 12:55:46.653255+00
1887	9	4	2026-06-20	PYATEROCHKA 6812	115.98	expense	Продукты	2026-08-03 12:55:46.653255+00
1888	9	4	2026-06-20	Оплата товаров и услуг AU3402	350	expense	Продукты	2026-08-03 12:55:46.653255+00
1889	9	4	2026-06-20	Оплата товаров и услуг YANDEX*7999*BIKE	1	expense	Транспорт	2026-08-03 12:55:46.653255+00
1890	9	4	2026-06-20	Оплата товаров и услуг PYATEROCHKA 6812	119.98	expense	Продукты	2026-08-03 12:55:46.653255+00
1891	9	4	2026-06-20	Оплата товаров и услуг UNIVERSAM VMESTE 24 CH	171.33	expense	Продукты	2026-08-03 12:55:46.653255+00
1892	9	4	2026-06-22	Оплата СБП QR (Озон)	519	expense	Развлечения	2026-08-03 12:55:46.653255+00
1893	9	4	2026-06-23	Перевод между счетами одного клиента	500	income	Переводы	2026-08-03 12:55:46.653255+00
1894	9	4	2026-06-23	Опл.по Дог.26658326/25 877.31 руб	877.31	income	Доход (прочее)	2026-08-03 12:55:46.653255+00
1895	9	4	2026-06-23	Перевод между счетами одного клиента	600	expense	Переводы	2026-08-03 12:55:46.653255+00
1896	9	4	2026-06-21	Оплата товаров и услуг PYATEROCHKA 6812	109.98	expense	Продукты	2026-08-03 12:55:46.653255+00
1897	9	4	2026-06-21	Оплата товаров и услуг MAGNIT MM ANDROMAKHA	109.98	expense	Продукты	2026-08-03 12:55:46.653255+00
1898	9	4	2026-06-21	Оплата товаров и услуг PYATEROCHKA 6812	119.98	expense	Продукты	2026-08-03 12:55:46.653255+00
1899	9	4	2026-06-23	Оплата СБП QR (podorozhnik.spb.ru_SBP)	130	expense	Транспорт	2026-08-03 12:55:46.653255+00
1900	9	4	2026-06-21	Оплата товаров и услуг DIXY-78336D	346.47	expense	Продукты	2026-08-03 12:55:46.653255+00
1901	9	4	2026-06-23	Оплата СБП QR (Дикси 78336)	279.88	expense	Продукты	2026-08-03 12:55:46.653255+00
1902	9	4	2026-06-21	Оплата товаров и услуг YANDEX*7999*BIKE	1	expense	Транспорт	2026-08-03 12:55:46.653255+00
1903	9	4	2026-06-23	Перевод между счетами одного клиента	600	income	Переводы	2026-08-03 12:55:46.653255+00
1904	9	4	2026-06-23	Оплата СБП QR (Озон)	737	expense	Развлечения	2026-08-03 12:55:46.653255+00
1905	9	4	2026-06-24	Опл.по Дог.ОФ-26561424 5995.65 руб	5995.65	income	Доход (прочее)	2026-08-03 12:55:46.653255+00
1906	9	4	2026-06-24	Опл.по Дог.26658326/25 1290.39 руб	1290.39	income	Доход (прочее)	2026-08-03 12:55:46.653255+00
1907	9	4	2026-06-24	Перевод между счетами одного клиента	1500	expense	Переводы	2026-08-03 12:55:46.653255+00
1908	9	4	2026-06-22	Оплата товаров и услуг DIXY-78336D	59.99	expense	Продукты	2026-08-03 12:55:46.653255+00
1909	9	4	2026-06-22	Оплата товаров и услуг YANDEX*7999*BIKE	1	expense	Транспорт	2026-08-03 12:55:46.653255+00
1910	9	4	2026-06-22	Оплата товаров и услуг MAGNIT MM ANDROMAKHA	169.97	expense	Продукты	2026-08-03 12:55:46.653255+00
1911	9	4	2026-06-22	Оплата товаров и услуг DIXY-78336D	359.86	expense	Продукты	2026-08-03 12:55:46.653255+00
1912	9	4	2026-06-24	Оплата СБП QR (Озон)	554	expense	Развлечения	2026-08-03 12:55:46.653255+00
1913	9	4	2026-06-24	Оплата СБП QR (t2_SBP)	650	expense	Прочее	2026-08-03 12:55:46.653255+00
1914	9	4	2026-06-25	Оплата СБП QR (t2)	100	expense	Прочее	2026-08-03 12:55:46.653255+00
1915	9	4	2026-06-25	Опл.по Дог.26658326/25 37.00 руб	37	income	Доход (прочее)	2026-08-03 12:55:46.653255+00
1916	9	4	2026-06-25	Оплата СБП QR (OZON)	520	expense	Развлечения	2026-08-03 12:55:46.653255+00
1917	9	4	2026-06-23	Оплата товаров и услуг PYATEROCHKA 6812	189.97	expense	Продукты	2026-08-03 12:55:46.653255+00
1918	9	4	2026-06-23	Оплата товаров и услуг YANDEX*7999*BIKE	1	expense	Транспорт	2026-08-03 12:55:46.653255+00
1919	9	4	2026-06-23	Оплата товаров и услуг PYATEROCHKA 6812	59.99	expense	Продукты	2026-08-03 12:55:46.653255+00
1920	9	4	2026-06-23	Оплата товаров и услуг PYATEROCHKA 6812	95.98	expense	Продукты	2026-08-03 12:55:46.653255+00
1921	9	4	2026-06-25	Оплата СБП QR (FUNPAY)	291.6	expense	Прочее	2026-08-03 12:55:46.653255+00
1922	9	4	2026-06-25	Оплата СБП QR (Озон)	609	expense	Развлечения	2026-08-03 12:55:46.653255+00
1923	9	4	2026-06-24	Оплата товаров и услуг DIXY-78336D	19.99	expense	Продукты	2026-08-03 12:55:46.653255+00
1924	9	4	2026-06-24	Оплата товаров и услуг DIXY-78336D	479.82	expense	Продукты	2026-08-03 12:55:46.653255+00
1925	9	4	2026-06-25	Оплата товаров и услуг PYATEROCHKA 22266	124.98	expense	Продукты	2026-08-03 12:55:46.653255+00
1926	9	4	2026-06-25	Оплата товаров и услуг DIXY-78336D	119.9	expense	Продукты	2026-08-03 12:55:46.653255+00
1927	9	4	2026-06-25	Оплата товаров и услуг DIXY-78336D	289.87	expense	Продукты	2026-08-03 12:55:46.653255+00
1928	9	4	2026-06-25	Оплата товаров и услуг SBER*5411*SAMOKAT	536	expense	Прочее	2026-08-03 12:55:46.653255+00
1929	9	4	2026-06-27	Оплата СБП QR (podorozhnik.spb.ru_SBP)	130	expense	Транспорт	2026-08-03 12:55:46.653255+00
1930	9	4	2026-06-27	Перевод между счетами одного клиента	1000	income	Переводы	2026-08-03 12:55:46.653255+00
1931	9	4	2026-06-27	Оплата СБП QR (Озон)	554	expense	Развлечения	2026-08-03 12:55:46.653255+00
1932	9	4	2026-06-28	Оплата СБП QR (podorozhnik.spb.ru_SBP)	130	expense	Транспорт	2026-08-03 12:55:46.653255+00
1933	9	4	2026-06-28	Перевод между счетами одного клиента	1000	income	Переводы	2026-08-03 12:55:46.653255+00
1934	9	4	2026-06-28	Оплата СБП QR (ООО "ИНТЕР")	200	expense	Прочее	2026-08-03 12:55:46.653255+00
1935	9	4	2026-06-26	Оплата товаров и услуг SBER*5411*SAMOKAT	476	expense	Прочее	2026-08-03 12:55:46.653255+00
1936	9	4	2026-06-28	Оплата СБП QR (Озон)	534	expense	Развлечения	2026-08-03 12:55:46.653255+00
1937	9	4	2026-06-26	Оплата товаров и услуг PYATEROCHKA 22266	245.96	expense	Продукты	2026-08-03 12:55:46.653255+00
1938	9	4	2026-06-28	Перевод между счетами одного клиента	1000	income	Переводы	2026-08-03 12:55:46.653255+00
1939	9	4	2026-06-27	Оплата товаров и услуг IP MITCHENKO D.YU.	290	expense	Продукты	2026-08-03 12:55:46.653255+00
1940	9	4	2026-06-29	Оплата СБП QR (podorozhnik.spb.ru_SBP)	1203.84	income	Доход (оплата по договорам)	2026-08-03 12:55:46.653255+00
1941	9	4	2026-06-29	Оплата товаров и услуг KRASNOE&BELOE	130	expense	Прочее	2026-08-03 12:55:46.653255+00
1942	9	4	2026-06-27	Оплата товаров и услуг PYATEROCHKA 6812	59.99	expense	Продукты	2026-08-03 12:55:46.653255+00
1943	9	4	2026-06-27	Оплата товаров и услуг PYATEROCHKA 6812	109.98	expense	Продукты	2026-08-03 12:55:46.653255+00
1944	9	4	2026-06-27	Оплата товаров и услуг PYATEROCHKA 6812	189.97	expense	Продукты	2026-08-03 12:55:46.653255+00
1945	9	4	2026-06-27	Оплата товаров и услуг YANDEX*7999*BIKE	1	expense	Транспорт	2026-08-03 12:55:46.653255+00
1946	9	4	2026-06-29	Оплата СБП QR (ООО "ИНТЕР")	100	expense	Прочее	2026-08-03 12:55:46.653255+00
1947	9	4	2026-06-29	Оплата СБП QR (Озон)	531	expense	Прочее	2026-08-03 12:55:46.653255+00
1948	9	4	2026-06-30	Опл.по Дог.26658326/25 574.29 руб	574.29	income	Доход (оплата по договорам)	2026-08-03 12:55:46.653255+00
1949	9	4	2026-06-30	Оплата СБП QR (podorozhnik.spb.ru_SBP)	130	expense	Транспорт	2026-08-03 12:55:46.653255+00
1950	9	4	2026-06-30	Оплата СБП QR (ООО "ИНТЕР")	100	expense	Прочее	2026-08-03 12:55:46.653255+00
1951	9	4	2026-06-28	Оплата товаров и услуг PYATEROCHKA 22266	222.77	expense	Продукты	2026-08-03 12:55:46.653255+00
1952	9	4	2026-06-30	Оплата СБП QR (ООО "ИНТЕР")	100	expense	Прочее	2026-08-03 12:55:46.653255+00
1953	9	4	2026-06-28	Оплата товаров и услуг SBER*5411*SAMOKAT	507	expense	Продукты	2026-08-03 12:55:46.653255+00
1954	9	4	2026-06-28	Оплата товаров и услуг YANDEX*7999*BIKE	1	expense	Транспорт	2026-08-03 12:55:46.653255+00
1955	9	4	2026-06-28	Оплата товаров и услуг PYATEROCHKA 6812	109.98	expense	Продукты	2026-08-03 12:55:46.653255+00
1956	9	4	2026-06-30	Оплата СБП QR (ООО "ИНТЕР")	100	expense	Прочее	2026-08-03 12:55:46.653255+00
1957	9	4	2026-06-28	Оплата товаров и услуг DIXY-78336D	447.56	expense	Продукты	2026-08-03 12:55:46.653255+00
1958	9	4	2026-06-30	Оплата СБП QR (ООО "ИНТЕР")	100	expense	Прочее	2026-08-03 12:55:46.653255+00
1959	9	4	2026-07-01	Входящий перевод по номеру карты (IPKAMBULATOVAZN)	1080	income	Доход (переводы)	2026-08-03 12:55:46.653255+00
1960	9	4	2026-07-01	Перевод между счетами одного клиента	800	expense	Переводы	2026-08-03 12:55:46.653255+00
1961	9	4	2026-07-01	Опл.по Дог.ОФ-26561424 5281.90 руб	5281.9	income	Доход (оплата по договорам)	2026-08-03 12:55:46.653255+00
1962	9	4	2026-07-01	Опл.по Дог.26658326/25 637.56 руб	637.56	income	Доход (оплата по договорам)	2026-08-03 12:55:46.653255+00
1963	9	4	2026-07-01	Перевод между счетами одного клиента	5200	expense	Переводы	2026-08-03 12:55:46.653255+00
1964	9	4	2026-06-29	Оплата товаров и услуг YANDEX*7999*BIKE	1	expense	Транспорт	2026-08-03 12:55:46.653255+00
1965	9	4	2026-06-29	Оплата товаров и услуг DIXY-78336D	409.77	expense	Продукты	2026-08-03 12:55:46.653255+00
1966	9	4	2026-07-01	Входящий перевод по номеру карты (Tribute)	3240	income	Доход (переводы)	2026-08-03 12:55:46.653255+00
1967	9	4	2026-07-01	Перевод между счетами одного клиента	3000	expense	Переводы	2026-08-03 12:55:46.653255+00
1968	9	4	2026-06-29	Оплата товаров и услуг PYATEROCHKA 6812	109.98	expense	Продукты	2026-08-03 12:55:46.653255+00
1969	9	4	2026-07-01	Оплата СБП QR (podorozhnik.spb.ru_SBP)	130	expense	Транспорт	2026-08-03 12:55:46.653255+00
1970	9	4	2026-07-01	Оплата товаров и услуг YANDEX*5411*LAVKA	178	expense	Продукты	2026-08-03 12:55:46.653255+00
1971	9	4	2026-07-02	Перевод между счетами одного клиента	1000	income	Доход (переводы)	2026-08-03 12:55:46.653255+00
1972	9	4	2026-07-02	Опл.по Дог.26658326/25 599.94 руб	599.94	income	Доход (оплата по договорам)	2026-08-03 12:55:46.653255+00
1973	9	4	2026-07-02	Оплата СБП QR (RouterAI)	100	expense	Прочее	2026-08-03 12:55:46.653255+00
1974	9	4	2026-06-30	Оплата товаров и услуг PYATEROCHKA 6812	169.97	expense	Продукты	2026-08-03 12:55:46.653255+00
1975	9	4	2026-06-30	Оплата товаров и услуг PYATEROCHKA 6812	109.98	expense	Продукты	2026-08-03 12:55:46.653255+00
1976	9	4	2026-06-30	Оплата товаров и услуг DIXY-78336D	178.67	expense	Продукты	2026-08-03 12:55:46.653255+00
1977	9	4	2026-06-30	Оплата товаров и услуг YANDEX*7999*BIKE	1	expense	Транспорт	2026-08-03 12:55:46.653255+00
1978	9	4	2026-07-02	Оплата СБП QR (Озон)	534	expense	Прочее	2026-08-03 12:55:46.653255+00
1979	9	4	2026-07-01	Оплата товаров и услуг B090	211	expense	Продукты	2026-08-03 12:55:46.653255+00
1980	9	4	2026-07-01	Оплата товаров и услуг UNIVERSAM VMESTE 24 CH	114.9	expense	Продукты	2026-08-03 12:55:46.653255+00
1981	9	4	2026-07-01	Оплата товаров и услуг UNIVERSAM VMESTE 24 CH	185.8	expense	Продукты	2026-08-03 12:55:46.653255+00
1982	9	4	2026-07-01	Оплата товаров и услуг YANDEX*7999*BIKE	1	expense	Транспорт	2026-08-03 12:55:46.653255+00
1983	9	4	2026-07-03	Оплата СБП QR (podorozhnik.spb.ru_SBP)	130	expense	Транспорт	2026-08-03 12:55:46.653255+00
1984	9	4	2026-07-01	Оплата товаров и услуг DIXY-78336D	349.78	expense	Продукты	2026-08-03 12:55:46.653255+00
1985	9	4	2026-07-03	Перевод между счетами одного клиента	1000	income	Доход (переводы)	2026-08-03 12:55:46.653255+00
1986	9	4	2026-07-02	Оплата товаров и услуг PYATEROCHKA 22266	394.96	expense	Продукты	2026-08-03 12:55:46.653255+00
1987	9	4	2026-07-03	Оплата товаров и услуг B036	211	expense	Продукты	2026-08-03 12:55:46.653255+00
1988	9	4	2026-07-03	Оплата товаров и услуг YANDEX*7999*BIKE	1	expense	Транспорт	2026-08-03 12:55:46.653255+00
1989	9	4	2026-07-03	Оплата товаров и услуг MAGNIT MM TIGIL	-224.98	expense	Продукты	2026-08-03 12:55:46.653255+00
1990	9	4	2026-07-04	Оплата товаров и услуг PYATEROCHKA 6812	-169.97	expense	Продукты	2026-08-03 12:55:46.653255+00
1991	9	4	2026-07-04	Оплата товаров и услуг PYATEROCHKA 6812	-109.98	expense	Продукты	2026-08-03 12:55:46.653255+00
1992	9	4	2026-07-04	Оплата товаров и услуг PYATEROCHKA 6812	-109.98	expense	Продукты	2026-08-03 12:55:46.653255+00
1993	9	4	2026-07-05	Оплата СБП QR (RouterAI)	-100	expense	Прочее	2026-08-03 12:55:46.653255+00
1994	9	4	2026-07-06	Опл.по Дог.26658326/25 3467.94 руб	3467.94	income	Доход (оплата по договорам)	2026-08-03 12:55:46.653255+00
1995	9	4	2026-07-06	Перевод между счетами одного клиента	-3500	expense	Переводы	2026-08-03 12:55:46.653255+00
1996	9	4	2026-07-06	Оплата СБП QR (RouterAI)	-100	expense	Прочее	2026-08-03 12:55:46.653255+00
1997	9	4	2026-07-04	Оплата товаров и услуг YANDEX*7999*BIKE	-1	expense	Транспорт	2026-08-03 12:55:46.653255+00
1998	9	4	2026-07-05	Оплата товаров и услуг YANDEX*7999*BIKE	-1	expense	Транспорт	2026-08-03 12:55:46.653255+00
1999	9	4	2026-07-07	Перевод между счетами одного клиента	540.92	income	Переводы	2026-08-03 12:55:46.653255+00
2000	9	4	2026-07-05	Оплата товаров и услуг YANDEX*7999*BIKE	-1	expense	Транспорт	2026-08-03 12:55:46.653255+00
2001	9	4	2026-07-07	Перевод между счетами одного клиента	1000	income	Переводы	2026-08-03 12:55:46.653255+00
2002	9	4	2026-07-07	Исходящий перевод СБП, Валерий Евгеньевич Б., +7 950 328-85-89, Озон Банк (Ozon)	-523	expense	Переводы	2026-08-03 12:55:46.653255+00
2003	9	4	2026-07-07	Оплата СБП QR (RouterAI)	-100	expense	Прочее	2026-08-03 12:55:46.653255+00
2004	9	4	2026-07-08	Перевод между счетами одного клиента	1000	income	Переводы	2026-08-03 12:55:46.653255+00
2005	9	4	2026-07-08	Оплата СБП QR (ТОО "ОнлиПэй")	-939.4	expense	Прочее	2026-08-03 12:55:46.653255+00
2006	9	4	2026-07-08	Перевод между счетами одного клиента	11000	income	Переводы	2026-08-03 12:55:46.653255+00
2007	9	4	2026-07-08	Опл.по Дог.ОФ-26561424 8174.23 руб	8174.23	income	Доход (оплата по договорам)	2026-08-03 12:55:46.653255+00
2008	9	4	2026-07-08	Опл.по Дог.26658326/25 669.24 руб	669.24	income	Доход (оплата по договорам)	2026-08-03 12:55:46.653255+00
2009	9	4	2026-07-08	Исходящий перевод СБП, Надежда Петровна П., +7 911 269-21-08, Альфа-Банк	-10000	expense	Переводы	2026-08-03 12:55:46.653255+00
2010	9	4	2026-07-08	Исходящий перевод СБП, Александр Викторович П., +7 911 263-29-95, Альфа-Банк	-10000	expense	Переводы	2026-08-03 12:55:46.653255+00
2011	9	4	2026-07-09	Опл.по Дог.26658326/25 836.33 руб	836.33	income	Доход (оплата по договорам)	2026-08-03 12:55:46.653255+00
2012	9	4	2026-07-09	Оплата товаров и услуг YANDEX*5411*LAVKA	-94	expense	Продукты	2026-08-03 12:55:46.653255+00
2013	9	4	2026-07-09	Оплата товаров и услуг YANDEX*5411*LAVKA	-110	expense	Продукты	2026-08-03 12:55:46.653255+00
2014	9	4	2026-07-09	Оплата СБП QR (podorozhnik.spb.ru_SBP)	-130	expense	Прочее	2026-08-03 12:55:46.653255+00
2015	9	4	2026-07-07	Оплата товаров и услуг YANDEX*7999*BIKE	-1	expense	Транспорт	2026-08-03 12:55:46.653255+00
2016	9	4	2026-07-07	Оплата товаров и услуг DIXY-78336D	-291.88	expense	Продукты	2026-08-03 12:55:46.653255+00
2017	9	4	2026-07-09	Входящий перевод СБП, Илья Алексеевич Л., +7 992 028-51-42, Альфа-Банк	2000	income	Переводы	2026-08-03 12:55:46.653255+00
2018	9	4	2026-07-09	Оплата СБП QR (RouterAI)	-100	expense	Прочее	2026-08-03 12:55:46.653255+00
2019	9	4	2026-07-10	Опл.по Дог.26658326/25 775.70 руб	775.7	income	Доход (оплата по договорам)	2026-08-03 12:55:46.653255+00
2020	9	4	2026-07-08	Оплата товаров и услуг DIXY-78336D	-356.78	expense	Продукты	2026-08-03 12:55:46.653255+00
2021	9	4	2026-07-10	Оплата СБП QR (podorozhnik.spb.ru_SBP)	-130	expense	Прочее	2026-08-03 12:55:46.653255+00
2022	9	4	2026-07-08	Оплата товаров и услуг YANDEX*7999*BIKE	-1	expense	Транспорт	2026-08-03 12:55:46.653255+00
2023	9	4	2026-07-08	Оплата товаров и услуг DIXY-78336D	-39.98	expense	Продукты	2026-08-03 12:55:46.653255+00
2024	9	4	2026-07-08	Оплата товаров и услуг UNIVERSAM VMESTE 24 CH	-159.9	expense	Продукты	2026-08-03 12:55:46.653255+00
2025	9	4	2026-07-10	Оплата СБП QR (Sota Connect)	-349	expense	Прочее	2026-08-03 12:55:46.653255+00
2026	9	4	2026-07-10	Оплата СБП QR (OZON)	-83	expense	Прочее	2026-08-03 12:55:46.653255+00
2027	9	4	2026-07-10	Оплата СБП QR (RouterAI)	-100	expense	Прочее	2026-08-03 12:55:46.653255+00
2028	9	4	2026-07-10	Оплата СБП QR (RouterAI)	-100	expense	Прочее	2026-08-03 12:55:46.653255+00
\.


--
-- Data for Name: user_agent_settings; Type: TABLE DATA; Schema: public; Owner: lifeagent
--

COPY public.user_agent_settings (id, user_id, agent_name, is_enabled, created_at, updated_at) FROM stdin;
2	2	accountant	t	2026-07-16 11:54:41.948321+00	2026-07-16 11:54:41.948321+00
5	2	secretary	t	2026-07-16 11:54:41.948321+00	2026-07-16 11:54:41.948321+00
6	4	mentor	t	2026-07-16 12:43:44.30487+00	2026-07-16 12:43:44.30487+00
8	4	psychologist	t	2026-07-16 12:43:44.30487+00	2026-07-16 12:43:44.30487+00
9	4	dietitian	t	2026-07-16 12:43:44.30487+00	2026-07-16 12:43:44.30487+00
11	7	accountant	t	2026-07-16 19:59:48.224273+00	2026-07-16 19:59:48.224273+00
12	7	secretary	t	2026-07-16 19:59:48.224273+00	2026-07-16 19:59:48.224273+00
15	7	dietitian	t	2026-07-16 19:59:48.224273+00	2026-07-16 19:59:48.224273+00
45	3	secretary	t	2026-07-20 13:11:51.52491+00	2026-07-20 13:11:51.52491+00
51	41	dietitian	t	2026-07-20 13:27:58.190291+00	2026-07-20 13:27:58.190291+00
52	41	mentor	t	2026-07-20 13:27:58.190291+00	2026-07-20 13:27:58.190291+00
53	41	psychologist	t	2026-07-20 13:27:58.190291+00	2026-07-20 13:27:58.190291+00
55	1	secretary	t	2026-07-20 14:07:07.830452+00	2026-07-20 14:07:07.830452+00
56	1	accountant	t	2026-07-20 14:07:07.830452+00	2026-07-20 14:07:07.830452+00
58	1	dietitian	t	2026-07-20 14:07:07.830452+00	2026-07-20 14:07:07.830452+00
54	1	mentor	t	2026-07-20 14:07:07.830452+00	2026-07-20 14:07:10.458044+00
57	1	psychologist	t	2026-07-20 14:07:07.830452+00	2026-07-20 14:07:10.458044+00
46	3	mentor	t	2026-07-20 13:11:51.52491+00	2026-07-20 15:19:01.11396+00
1	2	mentor	t	2026-07-16 11:54:41.948321+00	2026-07-20 15:19:12.265094+00
13	7	mentor	t	2026-07-16 19:59:48.224273+00	2026-07-20 15:19:30.659705+00
14	7	psychologist	t	2026-07-16 19:59:48.224273+00	2026-07-20 15:19:30.659705+00
7	4	accountant	t	2026-07-16 12:43:44.30487+00	2026-07-20 17:27:48.630976+00
10	4	secretary	t	2026-07-16 12:43:44.30487+00	2026-07-20 17:27:48.630976+00
49	41	secretary	t	2026-07-20 13:27:58.190291+00	2026-07-20 17:31:53.822964+00
50	41	accountant	t	2026-07-20 13:27:58.190291+00	2026-07-20 17:31:53.822964+00
3	2	psychologist	t	2026-07-16 11:54:41.948321+00	2026-07-21 11:37:20.800955+00
4	2	dietitian	t	2026-07-16 11:54:41.948321+00	2026-07-21 11:37:20.800955+00
48	3	accountant	t	2026-07-20 13:11:51.52491+00	2026-07-21 12:00:47.845845+00
44	3	psychologist	t	2026-07-20 13:11:51.52491+00	2026-07-21 12:31:18.007443+00
47	3	dietitian	t	2026-07-20 13:11:51.52491+00	2026-07-21 12:31:18.007443+00
\.


--
-- Data for Name: user_context_profiles; Type: TABLE DATA; Schema: public; Owner: lifeagent
--

COPY public.user_context_profiles (id, user_id, profile_text, key_goals, health_snapshot, finance_snapshot, schedule_snapshot, personality_traits, profile_embedding, version, last_generated_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_diet_profiles; Type: TABLE DATA; Schema: public; Owner: lifeagent
--

COPY public.user_diet_profiles (id, user_id, height, weight, age, gender, goal, activity_level, calorie_target, protein_target, fats_target, carbs_target, water_target, created_at, updated_at) FROM stdin;
1	3	184	90	25	male	lose	moderate	2200	180	62	241	11	2026-07-23 16:06:23.769467+00	2026-07-23 16:31:06.214299+00
\.


--
-- Data for Name: user_identities; Type: TABLE DATA; Schema: public; Owner: lifeagent
--

COPY public.user_identities (id, user_id, provider, provider_id, provider_data, created_at) FROM stdin;
1	7	yandex	2157693172	{"name": "\\u0412\\u0430\\u043b\\u0435\\u0440\\u0438\\u0439 \\u0411\\u0430\\u0441\\u0442\\u0440\\u0438\\u0433\\u0438\\u043d", "email": "vbastrigin1@yandex.ru", "picture": "27503/0h-8"}	2026-07-20 11:53:59.235602+00
\.


--
-- Data for Name: user_knowledge_facts; Type: TABLE DATA; Schema: public; Owner: lifeagent
--

COPY public.user_knowledge_facts (id, user_id, content, embedding, source_type, agent_name, memory_tier, importance, access_count, graph_links, source_timestamp, created_at, expires_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: lifeagent
--

COPY public.users (id, username, email, password_hash, google_id, avatar_url, age, token_balance, plan, credits_used, last_credit_reset, theme_preference, created_at, updated_at, onboarding_completed, agents_selected, profile_completed, birth_date, display_name, offer_accepted_at, privacy_accepted_at) FROM stdin;
7	а	vbastrigin1@yandex.ru		\N	\N	25	1000	FREE	0	2026-07-26	dark	2026-07-16 19:59:43.113568	2026-07-26 18:21:05.707522	t	t	t	2026-07-09	Валерий	2026-07-20 17:12:05.618551+00	2026-07-20 17:12:05.618551+00
4	Валерыч	bastrvpn@gmail.com	oauth_user	104085085332219660598	https://lh3.googleusercontent.com/a/ACg8ocKtY5cU9s1pS9jZYY2YtdyAfjav4zxKFhcQ0SlSjPWD0mqmog=s96-c	25	789	FREE	207	2026-08-03	dark	2026-07-16 12:07:20.950517	2026-08-03 13:10:43.388627	t	t	t	2026-07-16	Жлпа	2026-07-20 17:27:45.48246+00	2026-07-20 17:27:45.48246+00
5	test	test@ixteria.ru		\N	\N	\N	1000	FREE	0	\N	light	2026-07-16 19:28:28.657138	2026-07-16 19:28:28.657138	f	f	f	\N	\N	\N	\N
6	final-test	final-test@example.com		\N	\N	\N	1000	FREE	0	\N	light	2026-07-16 19:44:52.297243	2026-07-16 19:44:52.297243	f	f	f	\N	\N	\N	\N
41	Бро	ixteriaagents@gmail.com	oauth_user	109484546066686391635	https://lh3.googleusercontent.com/a/ACg8ocIL3M0ec9LJSLtAO-ISkhGopr2mHbezFs3oVkFoMs1SJKfoJw=s96-c	25	1000	FREE	0	2026-08-03	light	2026-07-20 13:27:56.790876	2026-08-03 12:41:58.405681	t	t	t	2026-07-17	Валерий	2026-07-20 17:31:50.25264+00	2026-07-20 17:31:50.25264+00
1	demo_user	demo@lifeagent.com	hashed_password_placeholder	\N	\N	\N	435	FREE	138	2026-08-03	light	2026-07-16 11:53:45.813976	2026-08-03 12:44:53.912445	f	t	f	\N	\N	\N	\N
3	Валик	theeisenclub@gmail.com	oauth_user	114137245849200193645	https://lh3.googleusercontent.com/a/ACg8ocIDgwgs0Y25FLU3h6IMSy9Gi7TZw0gNEXHxVSqU4DYumFasc20S=s96-c	25	87	FREE	203	2026-08-08	dark	2026-07-16 12:06:11.653281	2026-08-08 12:24:00.247702	t	t	t	2026-07-22	Магнус	2026-07-20 17:10:28.422259+00	2026-07-20 17:10:28.422259+00
2	Валерик	vbastrigin1@gmail.com	oauth_user	103544936037572791953	https://lh3.googleusercontent.com/a/ACg8ocKcHAcGjY4eotgK4TvOlmsaJQh6jtiXr0ZNOfzC37v0BOTz5w=s96-c	25	569	FREE	12	2026-08-08	dark	2026-07-16 11:54:37.08945	2026-08-08 12:36:00.533553	t	t	t	2026-07-24	Валерий	2026-07-20 17:15:16.197645+00	2026-07-20 17:15:16.197645+00
\.


--
-- Name: active_goals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lifeagent
--

SELECT pg_catalog.setval('public.active_goals_id_seq', 1, false);


--
-- Name: agent_communications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lifeagent
--

SELECT pg_catalog.setval('public.agent_communications_id_seq', 1, false);


--
-- Name: agents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lifeagent
--

SELECT pg_catalog.setval('public.agents_id_seq', 9, true);


--
-- Name: bank_statements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lifeagent
--

SELECT pg_catalog.setval('public.bank_statements_id_seq', 9, true);


--
-- Name: calendar_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lifeagent
--

SELECT pg_catalog.setval('public.calendar_events_id_seq', 97, true);


--
-- Name: chats_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lifeagent
--

SELECT pg_catalog.setval('public.chats_id_seq', 243, true);


--
-- Name: daily_food_analyses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lifeagent
--

SELECT pg_catalog.setval('public.daily_food_analyses_id_seq', 1, true);


--
-- Name: diary_entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lifeagent
--

SELECT pg_catalog.setval('public.diary_entries_id_seq', 1, false);


--
-- Name: diet_plans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lifeagent
--

SELECT pg_catalog.setval('public.diet_plans_id_seq', 1, false);


--
-- Name: dream_analyses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lifeagent
--

SELECT pg_catalog.setval('public.dream_analyses_id_seq', 1, false);


--
-- Name: dream_goals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lifeagent
--

SELECT pg_catalog.setval('public.dream_goals_id_seq', 1, false);


--
-- Name: financial_obligations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lifeagent
--

SELECT pg_catalog.setval('public.financial_obligations_id_seq', 1, true);


--
-- Name: food_consumptions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lifeagent
--

SELECT pg_catalog.setval('public.food_consumptions_id_seq', 5, true);


--
-- Name: knowledge_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lifeagent
--

SELECT pg_catalog.setval('public.knowledge_events_id_seq', 1, false);


--
-- Name: messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lifeagent
--

SELECT pg_catalog.setval('public.messages_id_seq', 590, true);


--
-- Name: mood_entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lifeagent
--

SELECT pg_catalog.setval('public.mood_entries_id_seq', 3, true);


--
-- Name: notes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lifeagent
--

SELECT pg_catalog.setval('public.notes_id_seq', 1, true);


--
-- Name: otp_challenges_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lifeagent
--

SELECT pg_catalog.setval('public.otp_challenges_id_seq', 54, true);


--
-- Name: portfolio_analyses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lifeagent
--

SELECT pg_catalog.setval('public.portfolio_analyses_id_seq', 10, true);


--
-- Name: reminders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lifeagent
--

SELECT pg_catalog.setval('public.reminders_id_seq', 12, true);


--
-- Name: schedule_analyses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lifeagent
--

SELECT pg_catalog.setval('public.schedule_analyses_id_seq', 1, true);


--
-- Name: therapy_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lifeagent
--

SELECT pg_catalog.setval('public.therapy_sessions_id_seq', 5, true);


--
-- Name: token_transactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lifeagent
--

SELECT pg_catalog.setval('public.token_transactions_id_seq', 1, false);


--
-- Name: transactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lifeagent
--

SELECT pg_catalog.setval('public.transactions_id_seq', 2028, true);


--
-- Name: user_agent_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lifeagent
--

SELECT pg_catalog.setval('public.user_agent_settings_id_seq', 58, true);


--
-- Name: user_context_profiles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lifeagent
--

SELECT pg_catalog.setval('public.user_context_profiles_id_seq', 1, false);


--
-- Name: user_diet_profiles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lifeagent
--

SELECT pg_catalog.setval('public.user_diet_profiles_id_seq', 1, true);


--
-- Name: user_identities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lifeagent
--

SELECT pg_catalog.setval('public.user_identities_id_seq', 1, true);


--
-- Name: user_knowledge_facts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lifeagent
--

SELECT pg_catalog.setval('public.user_knowledge_facts_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lifeagent
--

SELECT pg_catalog.setval('public.users_id_seq', 41, true);


--
-- Name: active_goals active_goals_pkey; Type: CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.active_goals
    ADD CONSTRAINT active_goals_pkey PRIMARY KEY (id);


--
-- Name: agent_communications agent_communications_pkey; Type: CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.agent_communications
    ADD CONSTRAINT agent_communications_pkey PRIMARY KEY (id);


--
-- Name: agents agents_name_key; Type: CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_name_key UNIQUE (name);


--
-- Name: agents agents_pkey; Type: CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_pkey PRIMARY KEY (id);


--
-- Name: bank_statements bank_statements_pkey; Type: CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.bank_statements
    ADD CONSTRAINT bank_statements_pkey PRIMARY KEY (id);


--
-- Name: calendar_events calendar_events_pkey; Type: CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.calendar_events
    ADD CONSTRAINT calendar_events_pkey PRIMARY KEY (id);


--
-- Name: chats chats_pkey; Type: CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.chats
    ADD CONSTRAINT chats_pkey PRIMARY KEY (id);


--
-- Name: daily_food_analyses daily_food_analyses_pkey; Type: CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.daily_food_analyses
    ADD CONSTRAINT daily_food_analyses_pkey PRIMARY KEY (id);


--
-- Name: diary_entries diary_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.diary_entries
    ADD CONSTRAINT diary_entries_pkey PRIMARY KEY (id);


--
-- Name: diet_plans diet_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.diet_plans
    ADD CONSTRAINT diet_plans_pkey PRIMARY KEY (id);


--
-- Name: diet_plans diet_plans_user_id_key; Type: CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.diet_plans
    ADD CONSTRAINT diet_plans_user_id_key UNIQUE (user_id);


--
-- Name: dream_analyses dream_analyses_pkey; Type: CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.dream_analyses
    ADD CONSTRAINT dream_analyses_pkey PRIMARY KEY (id);


--
-- Name: dream_goals dream_goals_pkey; Type: CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.dream_goals
    ADD CONSTRAINT dream_goals_pkey PRIMARY KEY (id);


--
-- Name: financial_obligations financial_obligations_pkey; Type: CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.financial_obligations
    ADD CONSTRAINT financial_obligations_pkey PRIMARY KEY (id);


--
-- Name: food_consumptions food_consumptions_pkey; Type: CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.food_consumptions
    ADD CONSTRAINT food_consumptions_pkey PRIMARY KEY (id);


--
-- Name: knowledge_events knowledge_events_pkey; Type: CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.knowledge_events
    ADD CONSTRAINT knowledge_events_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: mood_entries mood_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.mood_entries
    ADD CONSTRAINT mood_entries_pkey PRIMARY KEY (id);


--
-- Name: notes notes_pkey; Type: CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT notes_pkey PRIMARY KEY (id);


--
-- Name: otp_challenges otp_challenges_pkey; Type: CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.otp_challenges
    ADD CONSTRAINT otp_challenges_pkey PRIMARY KEY (id);


--
-- Name: portfolio_analyses portfolio_analyses_pkey; Type: CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.portfolio_analyses
    ADD CONSTRAINT portfolio_analyses_pkey PRIMARY KEY (id);


--
-- Name: reminders reminders_pkey; Type: CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.reminders
    ADD CONSTRAINT reminders_pkey PRIMARY KEY (id);


--
-- Name: schedule_analyses schedule_analyses_pkey; Type: CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.schedule_analyses
    ADD CONSTRAINT schedule_analyses_pkey PRIMARY KEY (id);


--
-- Name: therapy_sessions therapy_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.therapy_sessions
    ADD CONSTRAINT therapy_sessions_pkey PRIMARY KEY (id);


--
-- Name: token_transactions token_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.token_transactions
    ADD CONSTRAINT token_transactions_pkey PRIMARY KEY (id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- Name: user_identities uq_provider_identity; Type: CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.user_identities
    ADD CONSTRAINT uq_provider_identity UNIQUE (provider, provider_id);


--
-- Name: user_agent_settings user_agent_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.user_agent_settings
    ADD CONSTRAINT user_agent_settings_pkey PRIMARY KEY (id);


--
-- Name: user_context_profiles user_context_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.user_context_profiles
    ADD CONSTRAINT user_context_profiles_pkey PRIMARY KEY (id);


--
-- Name: user_context_profiles user_context_profiles_user_id_key; Type: CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.user_context_profiles
    ADD CONSTRAINT user_context_profiles_user_id_key UNIQUE (user_id);


--
-- Name: user_diet_profiles user_diet_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.user_diet_profiles
    ADD CONSTRAINT user_diet_profiles_pkey PRIMARY KEY (id);


--
-- Name: user_diet_profiles user_diet_profiles_user_id_key; Type: CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.user_diet_profiles
    ADD CONSTRAINT user_diet_profiles_user_id_key UNIQUE (user_id);


--
-- Name: user_identities user_identities_pkey; Type: CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.user_identities
    ADD CONSTRAINT user_identities_pkey PRIMARY KEY (id);


--
-- Name: user_knowledge_facts user_knowledge_facts_pkey; Type: CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.user_knowledge_facts
    ADD CONSTRAINT user_knowledge_facts_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_google_id_key; Type: CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_google_id_key UNIQUE (google_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_agent_comms_requester; Type: INDEX; Schema: public; Owner: lifeagent
--

CREATE INDEX idx_agent_comms_requester ON public.agent_communications USING btree (requester_agent);


--
-- Name: idx_agent_comms_target; Type: INDEX; Schema: public; Owner: lifeagent
--

CREATE INDEX idx_agent_comms_target ON public.agent_communications USING btree (target_agent);


--
-- Name: idx_agent_comms_user_id; Type: INDEX; Schema: public; Owner: lifeagent
--

CREATE INDEX idx_agent_comms_user_id ON public.agent_communications USING btree (user_id);


--
-- Name: idx_bank_statements_user_id; Type: INDEX; Schema: public; Owner: lifeagent
--

CREATE INDEX idx_bank_statements_user_id ON public.bank_statements USING btree (user_id);


--
-- Name: idx_calendar_events_start_time; Type: INDEX; Schema: public; Owner: lifeagent
--

CREATE INDEX idx_calendar_events_start_time ON public.calendar_events USING btree (start_time);


--
-- Name: idx_calendar_events_user_id; Type: INDEX; Schema: public; Owner: lifeagent
--

CREATE INDEX idx_calendar_events_user_id ON public.calendar_events USING btree (user_id);


--
-- Name: idx_chats_agent_id; Type: INDEX; Schema: public; Owner: lifeagent
--

CREATE INDEX idx_chats_agent_id ON public.chats USING btree (agent_id);


--
-- Name: idx_chats_user_id; Type: INDEX; Schema: public; Owner: lifeagent
--

CREATE INDEX idx_chats_user_id ON public.chats USING btree (user_id);


--
-- Name: idx_context_profiles_user_id; Type: INDEX; Schema: public; Owner: lifeagent
--

CREATE INDEX idx_context_profiles_user_id ON public.user_context_profiles USING btree (user_id);


--
-- Name: idx_events_type; Type: INDEX; Schema: public; Owner: lifeagent
--

CREATE INDEX idx_events_type ON public.knowledge_events USING btree (event_type);


--
-- Name: idx_events_user_status; Type: INDEX; Schema: public; Owner: lifeagent
--

CREATE INDEX idx_events_user_status ON public.knowledge_events USING btree (user_id, status);


--
-- Name: idx_knowledge_agent; Type: INDEX; Schema: public; Owner: lifeagent
--

CREATE INDEX idx_knowledge_agent ON public.user_knowledge_facts USING btree (agent_name);


--
-- Name: idx_knowledge_source; Type: INDEX; Schema: public; Owner: lifeagent
--

CREATE INDEX idx_knowledge_source ON public.user_knowledge_facts USING btree (source_type);


--
-- Name: idx_knowledge_tier; Type: INDEX; Schema: public; Owner: lifeagent
--

CREATE INDEX idx_knowledge_tier ON public.user_knowledge_facts USING btree (memory_tier);


--
-- Name: idx_knowledge_user_id; Type: INDEX; Schema: public; Owner: lifeagent
--

CREATE INDEX idx_knowledge_user_id ON public.user_knowledge_facts USING btree (user_id);


--
-- Name: idx_messages_chat_id; Type: INDEX; Schema: public; Owner: lifeagent
--

CREATE INDEX idx_messages_chat_id ON public.messages USING btree (chat_id);


--
-- Name: idx_messages_created_at; Type: INDEX; Schema: public; Owner: lifeagent
--

CREATE INDEX idx_messages_created_at ON public.messages USING btree (created_at);


--
-- Name: idx_mood_entries_created_at; Type: INDEX; Schema: public; Owner: lifeagent
--

CREATE INDEX idx_mood_entries_created_at ON public.mood_entries USING btree (created_at);


--
-- Name: idx_mood_entries_user_id; Type: INDEX; Schema: public; Owner: lifeagent
--

CREATE INDEX idx_mood_entries_user_id ON public.mood_entries USING btree (user_id);


--
-- Name: idx_portfolio_analyses_created_at; Type: INDEX; Schema: public; Owner: lifeagent
--

CREATE INDEX idx_portfolio_analyses_created_at ON public.portfolio_analyses USING btree (created_at);


--
-- Name: idx_portfolio_analyses_user_id; Type: INDEX; Schema: public; Owner: lifeagent
--

CREATE INDEX idx_portfolio_analyses_user_id ON public.portfolio_analyses USING btree (user_id);


--
-- Name: idx_reminders_date; Type: INDEX; Schema: public; Owner: lifeagent
--

CREATE INDEX idx_reminders_date ON public.reminders USING btree (date);


--
-- Name: idx_reminders_user_id; Type: INDEX; Schema: public; Owner: lifeagent
--

CREATE INDEX idx_reminders_user_id ON public.reminders USING btree (user_id);


--
-- Name: idx_token_transactions_user_id; Type: INDEX; Schema: public; Owner: lifeagent
--

CREATE INDEX idx_token_transactions_user_id ON public.token_transactions USING btree (user_id);


--
-- Name: idx_transactions_category; Type: INDEX; Schema: public; Owner: lifeagent
--

CREATE INDEX idx_transactions_category ON public.transactions USING btree (category);


--
-- Name: idx_transactions_statement_id; Type: INDEX; Schema: public; Owner: lifeagent
--

CREATE INDEX idx_transactions_statement_id ON public.transactions USING btree (statement_id);


--
-- Name: idx_transactions_user_id; Type: INDEX; Schema: public; Owner: lifeagent
--

CREATE INDEX idx_transactions_user_id ON public.transactions USING btree (user_id);


--
-- Name: ix_active_goals_id; Type: INDEX; Schema: public; Owner: lifeagent
--

CREATE INDEX ix_active_goals_id ON public.active_goals USING btree (id);


--
-- Name: ix_daily_food_analyses_analysis_date; Type: INDEX; Schema: public; Owner: lifeagent
--

CREATE INDEX ix_daily_food_analyses_analysis_date ON public.daily_food_analyses USING btree (analysis_date);


--
-- Name: ix_daily_food_analyses_id; Type: INDEX; Schema: public; Owner: lifeagent
--

CREATE INDEX ix_daily_food_analyses_id ON public.daily_food_analyses USING btree (id);


--
-- Name: ix_daily_food_analyses_user_id; Type: INDEX; Schema: public; Owner: lifeagent
--

CREATE INDEX ix_daily_food_analyses_user_id ON public.daily_food_analyses USING btree (user_id);


--
-- Name: ix_diet_plans_id; Type: INDEX; Schema: public; Owner: lifeagent
--

CREATE INDEX ix_diet_plans_id ON public.diet_plans USING btree (id);


--
-- Name: ix_dream_analyses_id; Type: INDEX; Schema: public; Owner: lifeagent
--

CREATE INDEX ix_dream_analyses_id ON public.dream_analyses USING btree (id);


--
-- Name: ix_dream_goals_id; Type: INDEX; Schema: public; Owner: lifeagent
--

CREATE INDEX ix_dream_goals_id ON public.dream_goals USING btree (id);


--
-- Name: ix_financial_obligations_id; Type: INDEX; Schema: public; Owner: lifeagent
--

CREATE INDEX ix_financial_obligations_id ON public.financial_obligations USING btree (id);


--
-- Name: ix_food_consumptions_id; Type: INDEX; Schema: public; Owner: lifeagent
--

CREATE INDEX ix_food_consumptions_id ON public.food_consumptions USING btree (id);


--
-- Name: ix_otp_challenges_email; Type: INDEX; Schema: public; Owner: lifeagent
--

CREATE INDEX ix_otp_challenges_email ON public.otp_challenges USING btree (email);


--
-- Name: ix_otp_challenges_id; Type: INDEX; Schema: public; Owner: lifeagent
--

CREATE INDEX ix_otp_challenges_id ON public.otp_challenges USING btree (id);


--
-- Name: ix_schedule_analyses_id; Type: INDEX; Schema: public; Owner: lifeagent
--

CREATE INDEX ix_schedule_analyses_id ON public.schedule_analyses USING btree (id);


--
-- Name: ix_schedule_analyses_user_id; Type: INDEX; Schema: public; Owner: lifeagent
--

CREATE UNIQUE INDEX ix_schedule_analyses_user_id ON public.schedule_analyses USING btree (user_id);


--
-- Name: ix_user_agent_settings_id; Type: INDEX; Schema: public; Owner: lifeagent
--

CREATE INDEX ix_user_agent_settings_id ON public.user_agent_settings USING btree (id);


--
-- Name: ix_user_identities_id; Type: INDEX; Schema: public; Owner: lifeagent
--

CREATE INDEX ix_user_identities_id ON public.user_identities USING btree (id);


--
-- Name: calendar_events update_calendar_events_updated_at; Type: TRIGGER; Schema: public; Owner: lifeagent
--

CREATE TRIGGER update_calendar_events_updated_at BEFORE UPDATE ON public.calendar_events FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: chats update_chats_updated_at; Type: TRIGGER; Schema: public; Owner: lifeagent
--

CREATE TRIGGER update_chats_updated_at BEFORE UPDATE ON public.chats FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: reminders update_reminders_updated_at; Type: TRIGGER; Schema: public; Owner: lifeagent
--

CREATE TRIGGER update_reminders_updated_at BEFORE UPDATE ON public.reminders FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: users update_users_updated_at; Type: TRIGGER; Schema: public; Owner: lifeagent
--

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: active_goals active_goals_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.active_goals
    ADD CONSTRAINT active_goals_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: agent_communications agent_communications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.agent_communications
    ADD CONSTRAINT agent_communications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: bank_statements bank_statements_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.bank_statements
    ADD CONSTRAINT bank_statements_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: calendar_events calendar_events_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.calendar_events
    ADD CONSTRAINT calendar_events_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: chats chats_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.chats
    ADD CONSTRAINT chats_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON DELETE SET NULL;


--
-- Name: chats chats_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.chats
    ADD CONSTRAINT chats_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: daily_food_analyses daily_food_analyses_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.daily_food_analyses
    ADD CONSTRAINT daily_food_analyses_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: diary_entries diary_entries_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.diary_entries
    ADD CONSTRAINT diary_entries_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: diet_plans diet_plans_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.diet_plans
    ADD CONSTRAINT diet_plans_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: dream_analyses dream_analyses_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.dream_analyses
    ADD CONSTRAINT dream_analyses_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: dream_goals dream_goals_chat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.dream_goals
    ADD CONSTRAINT dream_goals_chat_id_fkey FOREIGN KEY (chat_id) REFERENCES public.chats(id) ON DELETE SET NULL;


--
-- Name: dream_goals dream_goals_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.dream_goals
    ADD CONSTRAINT dream_goals_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: financial_obligations financial_obligations_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.financial_obligations
    ADD CONSTRAINT financial_obligations_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: food_consumptions food_consumptions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.food_consumptions
    ADD CONSTRAINT food_consumptions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: knowledge_events knowledge_events_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.knowledge_events
    ADD CONSTRAINT knowledge_events_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: messages messages_chat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_chat_id_fkey FOREIGN KEY (chat_id) REFERENCES public.chats(id) ON DELETE CASCADE;


--
-- Name: mood_entries mood_entries_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.mood_entries
    ADD CONSTRAINT mood_entries_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: notes notes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT notes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: portfolio_analyses portfolio_analyses_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.portfolio_analyses
    ADD CONSTRAINT portfolio_analyses_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: reminders reminders_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.reminders
    ADD CONSTRAINT reminders_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: schedule_analyses schedule_analyses_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.schedule_analyses
    ADD CONSTRAINT schedule_analyses_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: therapy_sessions therapy_sessions_chat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.therapy_sessions
    ADD CONSTRAINT therapy_sessions_chat_id_fkey FOREIGN KEY (chat_id) REFERENCES public.chats(id) ON DELETE CASCADE;


--
-- Name: therapy_sessions therapy_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.therapy_sessions
    ADD CONSTRAINT therapy_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: token_transactions token_transactions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.token_transactions
    ADD CONSTRAINT token_transactions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: transactions transactions_statement_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_statement_id_fkey FOREIGN KEY (statement_id) REFERENCES public.bank_statements(id) ON DELETE CASCADE;


--
-- Name: transactions transactions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_agent_settings user_agent_settings_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.user_agent_settings
    ADD CONSTRAINT user_agent_settings_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_context_profiles user_context_profiles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.user_context_profiles
    ADD CONSTRAINT user_context_profiles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_diet_profiles user_diet_profiles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.user_diet_profiles
    ADD CONSTRAINT user_diet_profiles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_identities user_identities_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.user_identities
    ADD CONSTRAINT user_identities_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_knowledge_facts user_knowledge_facts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lifeagent
--

ALTER TABLE ONLY public.user_knowledge_facts
    ADD CONSTRAINT user_knowledge_facts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict iDJw9mqb5Jg9xgt1btWzU8zsfGOhcY5RU9JCLG3hNdwLgjfzSxAX271a24hsomK

